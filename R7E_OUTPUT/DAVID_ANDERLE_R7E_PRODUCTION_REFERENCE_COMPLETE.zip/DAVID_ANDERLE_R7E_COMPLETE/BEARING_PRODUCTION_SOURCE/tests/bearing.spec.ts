import { test, expect, chromium, type Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import fs from 'node:fs/promises';
import path from 'node:path';

const ordinary = ['/', '/work/', '/work/research-workspace/', '/work/non-core-real-estate/', '/work/merkle-poseidon/', '/writing/', '/archive/', '/about/', '/about/no-photo/', '/contact/'];
const evidenceDir = path.resolve('evidence/browser');

async function measure(page: Page, route: string, viewport: string) {
  const data = await page.evaluate(() => ({
    href: location.href,
    title: document.title,
    innerWidth: window.innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    bodyTextCharacters: document.body.innerText.length,
    executableScripts: Array.from(document.scripts).filter((node) => !node.type || node.type === 'module' || /javascript/i.test(node.type)).length,
    headings: Array.from(document.querySelectorAll('h1,h2')).map((node) => node.textContent?.trim())
  }));
  await fs.mkdir(path.join(evidenceDir, 'measurements'), { recursive: true });
  const safe = route === '/' ? 'home' : route.replaceAll('/', '-').replace(/^-|-$/g, '');
  await fs.writeFile(path.join(evidenceDir, 'measurements', `${safe}-${viewport}.json`), JSON.stringify(data, null, 2));
  expect(data.scrollWidth).toBeLessThanOrEqual(data.innerWidth);
  expect(data.bodyTextCharacters).toBeGreaterThan(250);
}

for (const config of [
  { name: 'desktop-1440', width: 1440, height: 1000 },
  { name: 'mobile-390', width: 390, height: 844 },
  { name: 'mobile-320', width: 320, height: 568 }
]) {
  test(`homepage composition ${config.name}`, async ({ page }) => {
    await page.setViewportSize({ width: config.width, height: config.height });
    await page.goto('/');
    await expect(page.locator('h1')).toContainText('David');
    await expect(page.locator('#selected-evidence')).toBeVisible();
    await measure(page, '/', config.name);
    await fs.mkdir(path.join(evidenceDir, 'screenshots'), { recursive: true });
    await page.screenshot({ path: path.join(evidenceDir, 'screenshots', `home-${config.name}.png`), fullPage: true });
  });
}

for (const config of [
  { name: 'desktop-1440', width: 1440, height: 1000 },
  { name: 'mobile-390', width: 390, height: 844 },
  { name: 'mobile-320', width: 320, height: 568 }
]) {
  test(`deep project composition ${config.name}`, async ({ page }) => {
    await page.setViewportSize({ width: config.width, height: config.height });
    await page.goto('/work/non-core-real-estate/');
    await expect(page.locator('.record-register')).toBeVisible();
    await measure(page, '/work/non-core-real-estate/', config.name);
    await fs.mkdir(path.join(evidenceDir, 'screenshots'), { recursive: true });
    await page.screenshot({ path: path.join(evidenceDir, 'screenshots', `project-oxide-${config.name}.png`), fullPage: true });
  });
}

test('ordinary routes remain complete with JavaScript disabled', async ({ browser }) => {
  const context = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 390, height: 844 } });
  const page = await context.newPage();
  const rows = [];
  for (const route of ordinary) {
    const response = await page.goto(route);
    expect(response?.status()).toBe(200);
    const h1 = (await page.locator('h1').first().textContent())?.trim();
    const bodyLength = (await page.locator('body').innerText()).length;
    const scripts = await page.locator('script').count();
    expect(h1).toBeTruthy();
    expect(bodyLength).toBeGreaterThan(250);
    expect(scripts).toBe(0);
    rows.push({ route, status: response?.status(), h1, bodyLength, scripts });
  }
  await fs.writeFile(path.join(evidenceDir, 'no-js-routes.json'), JSON.stringify(rows, null, 2));
  await context.close();
});

test('single route-local Web Component is progressive enhancement', async ({ page, browser }) => {
  await page.goto('/visual-comparison/');
  await expect(page.locator('bearing-comparison')).toHaveAttribute('data-ready', 'true');
  await page.getByRole('button', { name: 'Architecture' }).click();
  await expect(page.locator('[data-category="measurement"]').first()).toHaveAttribute('data-deemphasized', '');
  const context = await browser.newContext({ javaScriptEnabled: false });
  const staticPage = await context.newPage();
  await staticPage.goto('/visual-comparison/');
  await expect(staticPage.locator('[data-category]')).toHaveCount(4);
  await context.close();
});

test('axe serious and critical findings are absent on representative routes', async ({ page }) => {
  const routes = ['/', '/work/non-core-real-estate/', '/about/no-photo/', '/visual-comparison/'];
  const reports = [];
  for (const route of routes) {
    await page.goto(route);
    const result = await new AxeBuilder({ page }).analyze();
    const blocking = result.violations.filter((item) => item.impact === 'serious' || item.impact === 'critical');
    reports.push({ route, violations: result.violations, blocking });
    expect(blocking).toEqual([]);
  }
  await fs.writeFile(path.join(evidenceDir, 'axe-representative.json'), JSON.stringify(reports, null, 2));
});

test('compact-photo and no-photo states are both structurally complete', async ({ page }) => {
  await page.goto('/about/');
  await expect(page.locator('.portrait')).toBeVisible();
  await page.screenshot({ path: path.join(evidenceDir, 'screenshots', 'about-compact-photo-or-fallback-390.png'), fullPage: true });
  await page.goto('/about/no-photo/');
  await expect(page.locator('.no-photo')).toBeVisible();
  await page.screenshot({ path: path.join(evidenceDir, 'screenshots', 'about-no-photo-390.png'), fullPage: true });
});

test('custom 404 output contains the Bearing marker', async ({ page }) => {
  const response = await page.goto('/404.html');
  expect(response?.status()).toBe(200);
  await expect(page.locator('[data-custom-404="bearing"]')).toBeVisible();
  await page.screenshot({ path: path.join(evidenceDir, 'screenshots', 'custom-404.png'), fullPage: true });
});
