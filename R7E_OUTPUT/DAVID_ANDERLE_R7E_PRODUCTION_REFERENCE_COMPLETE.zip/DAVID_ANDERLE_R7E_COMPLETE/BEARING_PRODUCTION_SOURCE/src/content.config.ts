import { defineCollection, z } from 'astro:content';
import { file, glob } from 'astro/loaders';

const maturity = z.enum(['working-prototype', 'research-in-progress', 'private-system', 'published-note']);
const authorship = z.enum(['solo', 'contributor', 'collaborative']);
const material = z.enum(['graphite', 'oxide', 'paper']);

const projects = defineCollection({
  loader: glob({ base: './src/content/projects', pattern: '**/*.{md,mdx}' }),
  schema: z.object({
    title: z.string().min(3),
    slug: z.string().regex(/^[a-z0-9-]+$/),
    summary: z.string().min(40),
    publishedAt: z.coerce.date(),
    year: z.number().int().min(2020).max(2035),
    role: z.string().min(5),
    maturity,
    authorship,
    access: z.enum(['public', 'private', 'restricted']),
    material,
    featured: z.boolean(),
    sortOrder: z.number().int(),
    evidence: z.array(z.object({ label: z.string(), value: z.string() })).min(2),
    links: z.array(z.object({ label: z.string(), href: z.string().url() })),
    relatedNotes: z.array(z.string())
  })
});

const notes = defineCollection({
  loader: glob({ base: './src/content/notes', pattern: '**/*.{md,mdx}' }),
  schema: z.object({
    title: z.string().min(3),
    slug: z.string().regex(/^[a-z0-9-]+$/),
    summary: z.string().min(35),
    publishedAt: z.coerce.date(),
    year: z.number().int().min(2020).max(2035),
    status: z.enum(['working-note', 'technical-note']),
    material,
    relatedProjects: z.array(z.string())
  })
});

const experience = defineCollection({
  loader: file('./src/content/data/experience.json'),
  schema: z.object({
    organization: z.string(),
    role: z.string(),
    location: z.string(),
    start: z.string(),
    end: z.string(),
    prominence: z.enum(['primary', 'secondary']),
    summary: z.string()
  })
});

const education = defineCollection({
  loader: file('./src/content/data/education.json'),
  schema: z.object({
    institution: z.string(),
    programme: z.string(),
    startYear: z.number().int(),
    endYear: z.number().int(),
    status: z.enum(['current', 'completed']),
    prominence: z.enum(['primary', 'secondary']),
    summary: z.string()
  })
});

const scale = defineCollection({
  loader: glob({ base: './src/content/scale', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    slug: z.string().regex(/^scale-[0-9]{4}$/),
    year: z.number().int().min(2017).max(2026),
    sequence: z.number().int().min(1).max(500),
    material,
    summary: z.string().min(30)
  })
});

export const collections = { projects, notes, experience, education, scale };
