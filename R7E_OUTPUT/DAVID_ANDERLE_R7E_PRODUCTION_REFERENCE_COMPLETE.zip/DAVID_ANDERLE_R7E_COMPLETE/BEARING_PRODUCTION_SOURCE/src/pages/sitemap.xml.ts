import type { APIRoute } from 'astro';
import { getCollection } from 'astro:content';

export const GET: APIRoute = async () => {
  const projects = await getCollection('projects');
  const notes = await getCollection('notes');
  const paths = ['/', '/work/', '/writing/', '/archive/', '/about/', '/about/no-photo/', '/contact/', '/visual-comparison/'];
  paths.push(...projects.map((x) => `/work/${x.data.slug}/`));
  paths.push(...notes.map((x) => `/writing/${x.data.slug}/`));
  const urls = paths.map((path) => `<url><loc>https://davidanderle.com${path}</loc></url>`).join('');
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
};
