---
title: Risk before optimization
slug: risk-before-optimization
summary: A working note on why drawdown, liquidity, state control and failure modes belong before objective-function tuning.
publishedAt: 2026-07-20
year: 2026
status: working-note
material: graphite
relatedProjects:
  - research-workspace
---

Optimization can improve a model inside its assumptions while leaving the system exposed outside them. The first design questions are therefore about data failure, liquidity, position limits, recovery and observability. Only after those boundaries are explicit does tuning become meaningful.
