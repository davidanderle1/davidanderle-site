---
title: Evidence before conclusion
slug: evidence-before-conclusion
summary: A technical note on separating measured distributions, period effects and composition from a convenient aggregate narrative.
publishedAt: 2026-06-25
year: 2026
status: technical-note
material: oxide
relatedProjects:
  - non-core-real-estate
---

An average difference is a starting observation, not a causal conclusion. A credible extension should expose dispersion, sample composition, time dependence and uncertainty before it compresses the result into a ranking.
