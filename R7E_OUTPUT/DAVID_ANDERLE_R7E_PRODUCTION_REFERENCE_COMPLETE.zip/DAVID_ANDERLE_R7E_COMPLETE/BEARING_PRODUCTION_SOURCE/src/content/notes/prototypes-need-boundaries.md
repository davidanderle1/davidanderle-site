---
title: Prototypes need explicit boundaries
slug: prototypes-need-boundaries
summary: A working note on documenting the missing layer of a technical prototype as prominently as the implemented layer.
publishedAt: 2026-05-12
year: 2026
status: working-note
material: paper
relatedProjects:
  - merkle-poseidon
---

A prototype becomes misleading when the interface looks finished but the security or validation layer is absent. The record should name what runs, what is only sketched and what evidence would be required to move the maturity label.
