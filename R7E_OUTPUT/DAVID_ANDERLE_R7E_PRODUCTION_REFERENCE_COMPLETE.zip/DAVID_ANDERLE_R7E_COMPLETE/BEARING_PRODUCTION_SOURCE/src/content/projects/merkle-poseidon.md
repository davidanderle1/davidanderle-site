---
title: Merkle–Poseidon threshold prototype
slug: merkle-poseidon
summary: A Rust and arkworks prototype for Poseidon commitments, Merkle membership and a bounded threshold-proof research path.
publishedAt: 2026-05-06
year: 2026
role: Prototype implementer
maturity: working-prototype
authorship: solo
access: public
material: paper
featured: true
sortOrder: 3
evidence:
  - label: Implemented
    value: Merkle tree, Poseidon demonstration, commitments and native checks
  - label: Not implemented
    value: Complete circuit and end-to-end zero-knowledge proof layer
  - label: Language
    value: Rust with arkworks
links:
  - label: Public repository
    href: https://github.com/davidanderle1/merkle-poseidon
relatedNotes:
  - prototypes-need-boundaries
---

## Implemented layer

The repository contains the native data-structure and hashing path needed to reason about commitments and membership outside a circuit.

## Missing layer

The circuit implementation and an end-to-end proof that the committed leaf values exceed a public threshold remain incomplete. The page preserves that limitation instead of turning a prototype into a finished cryptographic claim.

## Next technical step

Define circuit constraints against the same Poseidon parameters, verify root consistency and then test the threshold statement with explicit fixtures before discussing performance.
