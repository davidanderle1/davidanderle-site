---
title: Non-core real-estate return research
slug: non-core-real-estate
summary: An empirical research extension examining how acquisition strategy and property lifecycle relate to non-core real-estate returns.
publishedAt: 2026-06-18
year: 2026
role: Research contributor developing property-level follow-up analysis
maturity: research-in-progress
authorship: contributor
access: restricted
material: oxide
featured: true
sortOrder: 2
evidence:
  - label: Research context
    value: Asset-level non-core real-estate data
  - label: Analytical direction
    value: Dispersion, lifecycle and risk-sensitive follow-up
  - label: Boundary
    value: Work in progress; no final independent paper claimed
links: []
relatedNotes:
  - evidence-before-conclusion
---

## Research question

Aggregate return differences can hide wide property-level dispersion. The follow-up work asks where that dispersion comes from, how it changes across lifecycle stages and how conclusions move once risk and composition are treated explicitly.

## Contribution boundary

This record describes a supervised research contribution and intended empirical extension. It does not present the underlying dataset as public, does not claim sole authorship and does not label unfinished analysis as a publication.

## Method direction

The planned structure separates strategy at acquisition from lifecycle state, tests period sensitivity and reports distributions rather than relying on a single average-return ranking.
