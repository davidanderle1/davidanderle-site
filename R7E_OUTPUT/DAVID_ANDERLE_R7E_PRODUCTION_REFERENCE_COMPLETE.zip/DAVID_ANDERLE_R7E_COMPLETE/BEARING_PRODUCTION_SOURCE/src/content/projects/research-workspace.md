---
title: Quantitative research workspace
slug: research-workspace
summary: A private, versioned workspace for market data, portfolio-risk analysis, research experiments and controlled execution interfaces.
publishedAt: 2026-07-31
year: 2026
role: System designer and primary implementer
maturity: private-system
authorship: solo
access: private
material: graphite
featured: true
sortOrder: 1
evidence:
  - label: Recorded version
    value: v0.5.0-rc.1
  - label: Core stack
    value: Python, FastAPI, PostgreSQL, Parquet and DuckDB
  - label: Boundary
    value: Research workspace, not an investment product
links: []
relatedNotes:
  - risk-before-optimization
---

## What exists

The workspace separates research data, portfolio-risk calculations, scheduling and controlled execution interfaces. It is designed around explicit boundaries between exploration, validation and anything capable of touching a brokerage connection.

## Why it matters

The useful evidence is not a claim of profitable trading. It is the engineering discipline: reproducible data paths, clear interfaces, controlled state and a record of what has and has not been validated.

## Current boundary

The repository is private. The recorded release is a release candidate and should not be interpreted as a production trading platform or a verified source of returns.
