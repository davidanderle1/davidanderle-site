# R7E authority requirement matrix

This matrix records the implementation boundary derived from the supplied R4, R5, R6C, R6D, R7 and R7V packages. It is a producer traceability aid, not a substitute for those source packages or for R7F review.

| Authority | Implemented invariant | Evidence location |
|---|---|---|
| R4 | Long-lived identity architecture, typed heterogeneous work records, durable archive, conservative factual claims | `src/content.config.ts`, `src/content/`, `/archive/` |
| R5 | Compact portrait envelope no larger than 256 x 320, no enlargement, complete no-photo state and provenance record | `scripts/process-images.mjs`, `/about/`, `/about/no-photo/`, image reports |
| R6C | Bearing identity, calibrated editorial-industrial composition, concrete evidence as primary material | authored CSS, homepage and deep routes |
| R6D | Design search closed; work appears before trajectory; Madison reduced; defensive metaphor copy reduced; deep pages retain identity | homepage ordering checks, project material modes, content validation |
| R7 | Astro static architecture, typed collections, Markdown and JSON, bounded Web Component, Sharp, GitHub Actions and Cloudflare assets-only target | source repository and workflow files |
| R7V | Previous declarations do not count as proof; native builds, reproducibility, 500-record scale, browser output and raw logs required | `R7E_EVIDENCE_INDEX.json` and `R7E_RAW_EVIDENCE/` |

## Non-negotiable implementation rules

Ordinary launch routes remain complete without JavaScript. Only `/visual-comparison/` contains executable client code, implemented as one standards-based custom element. The 390 px and 320 px layouts have dedicated media-query compositions. The 500-record corpus is generated, validated and built as non-canonical test evidence. No production deploy occurs during R7E.
