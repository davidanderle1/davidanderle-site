# R7E official source log

Retrieval batch: `2026-08-29T12:39:43.952Z`

Only primary official documentation was requested. HTTP status, final URL, response hash and marker observations are preserved. A failed retrieval is not treated as verification.

| Topic | Publisher | Requested source | Retrieved UTC | HTTP | Marker hits | Raw snapshot | SHA-256 |
|---|---|---|---|---:|---:|---|---|
| Astro static output | Astro | https://docs.astro.build/en/reference/configuration-reference/#output | 2026-08-29T12:39:43.952Z | 200 | 2 | `evidence/official-sources/astro-static-output.html.gz` | `b7749a771149b686a801cf6efac689107b83328a7eda8053c5217f5427721b96` |
| Astro content collections and schema validation | Astro | https://docs.astro.build/en/guides/content-collections/ | 2026-08-29T12:39:44.085Z | 200 | 2 | `evidence/official-sources/astro-content-collections.html.gz` | `d0417660b9e7d15eab0fe71856eab70d2f57a4110310955860643439853665b9` |
| Astro routing and static paths | Astro | https://docs.astro.build/en/guides/routing/ | 2026-08-29T12:39:44.167Z | 200 | 2 | `evidence/official-sources/astro-routing.html.gz` | `01738c6d31f453da250887e699702005ae60c3b1d8537c7d39e1066ffcbc248a` |
| Astro client scripts and Web Components | Astro | https://docs.astro.build/en/guides/client-side-scripts/ | 2026-08-29T12:39:44.237Z | 200 | 2 | `evidence/official-sources/astro-client-scripts.html.gz` | `725bac5e359a056d33bec2b31caa6556557ec9844a2a434b9e2d6bb530944fde` |
| Astro local image handling | Astro | https://docs.astro.build/en/guides/images/ | 2026-08-29T12:39:44.325Z | 200 | 2 | `evidence/official-sources/astro-images.html.gz` | `825ebc66469f19634a00c94b248d44321d74ac2a4686e583c8ff77d7c41a9b5e` |
| Astro installation and supported Node versions | Astro | https://docs.astro.build/en/install-and-setup/ | 2026-08-29T12:39:44.395Z | 200 | 2 | `evidence/official-sources/astro-node-support.html.gz` | `d0b956a53fc9cd521afaa96ce396b8343f24e1df72646ee5121db17811d16cf5` |
| Sharp installation and runtime behavior | Sharp | https://sharp.pixelplumbing.com/install | 2026-08-29T12:39:44.454Z | 200 | 2 | `evidence/official-sources/sharp-install.html.gz` | `04a6c075f6ccf6b16060a08482006c3452958c4ec84ce58cadadd0fcd65bfce1` |
| Sharp resize and enlargement controls | Sharp | https://sharp.pixelplumbing.com/api-resize | 2026-08-29T12:39:44.640Z | 200 | 2 | `evidence/official-sources/sharp-resize.html.gz` | `2244dce9f8373626fb4a34b3b68a59607ace415b9d1b33627402776a21759b39` |
| Playwright installation and browser testing | Microsoft Playwright | https://playwright.dev/docs/intro | 2026-08-29T12:39:44.752Z | 200 | 2 | `evidence/official-sources/playwright-intro.html.gz` | `130529d6917c97d989e5cc835e857eb9235de8504dac81980484c02d8ff62e47` |
| Playwright test web server | Microsoft Playwright | https://playwright.dev/docs/test-webserver | 2026-08-29T12:39:44.785Z | 200 | 2 | `evidence/official-sources/playwright-webserver.html.gz` | `86a828fb87c1e118e20e61affb9f2d0b0e5b743a8bfc7c997e7c325c2aaf1de5` |
| axe-core accessibility engine | Deque Systems | https://github.com/dequelabs/axe-core | 2026-08-29T12:39:44.819Z | 200 | 2 | `evidence/official-sources/axe-core.html.gz` | `676e442c291c47e084ef14370102df5d8deb1970a1d2fe657bb6b4ec928f4b32` |
| axe-core Playwright integration | Deque Systems | https://github.com/dequelabs/axe-core-npm/tree/develop/packages/playwright | 2026-08-29T12:39:45.251Z | 200 | 2 | `evidence/official-sources/axe-playwright.html.gz` | `90f484f445fabc9b24be2e2ea470608e453db8413856a090028efc7723eedd05` |
| Lighthouse measurement | Google Chrome | https://developer.chrome.com/docs/lighthouse/overview | 2026-08-29T12:39:45.631Z | 200 | 2 | `evidence/official-sources/lighthouse.html.gz` | `0e05a7bb952d5a76f3f399c4f6670a42397aa475c1eb7893563b4ee2bebe0cea` |
| Cloudflare Workers Static Assets | Cloudflare | https://developers.cloudflare.com/workers/static-assets/ | 2026-08-29T12:39:45.919Z | 200 | 2 | `evidence/official-sources/cloudflare-static-assets.html.gz` | `6da72b6bf7ac74666268e0938cdd6725a0424e9ee41552306db469875b2a16f2` |
| Workers Static Assets assets-only deployment | Cloudflare | https://developers.cloudflare.com/workers/static-assets/get-started/ | 2026-08-29T12:39:46.009Z | 200 | 2 | `evidence/official-sources/cloudflare-static-get-started.html.gz` | `071ad9fde1a52f205e7932178467420add2e07c3d5fc178c37cad2067edb9b89` |
| Static Assets HTML and not-found handling | Cloudflare | https://developers.cloudflare.com/workers/static-assets/routing/advanced/html-handling/ | 2026-08-29T12:39:46.081Z | 200 | 2 | `evidence/official-sources/cloudflare-static-configuration.html.gz` | `b17b44d2aa5cc6b9f6ddf7a8ba61b293940246c7e5496dbc3f24fafe034d1154` |
| Static Assets _headers | Cloudflare | https://developers.cloudflare.com/workers/static-assets/headers/ | 2026-08-29T12:39:46.153Z | 200 | 2 | `evidence/official-sources/cloudflare-static-headers.html.gz` | `c60b2a3647d039a09875a92121e10eeea71bb7ca6d45c82f963237a4b4603e57` |
| Static Assets _redirects | Cloudflare | https://developers.cloudflare.com/workers/static-assets/redirects/ | 2026-08-29T12:39:46.283Z | 200 | 2 | `evidence/official-sources/cloudflare-static-redirects.html.gz` | `a15925e641168e0c9e3bc6176db37f9d223ac83c0832cb8f93cbfc596cd78424` |
| Static Assets routing and HTML handling | Cloudflare | https://developers.cloudflare.com/workers/static-assets/routing/ | 2026-08-29T12:39:46.363Z | 200 | 1 | `evidence/official-sources/cloudflare-static-routing.html.gz` | `fe558c4ec6d88e843f443495a7bfdf9499e90a0a2cbc7c3fc11d95dbda35223c` |
| Wrangler deploy dry run | Cloudflare | https://developers.cloudflare.com/workers/wrangler/commands/#deploy | 2026-08-29T12:39:46.438Z | 200 | 1 | `evidence/official-sources/wrangler-deploy.html.gz` | `22572cae8d4d6cc5eea87053308c376587c43e57e64cebbc039db4689678ac19` |

## Implementation decisions tied to the source set

Astro is configured with explicit static output. Content is loaded through typed collections and build-time static paths. Client code is limited to one route-local custom element. Image derivatives are generated locally with Sharp and reject enlargement. Browser, accessibility and Lighthouse evidence is generated with native tools. Cloudflare is configured with an `assets` directory and no Worker `main` script; `_headers`, `_redirects`, 404-page handling and `wrangler deploy --dry-run` are tested separately.

These statements describe the implemented interpretation. R7F must compare them against the preserved official snapshots and current upstream documentation.
