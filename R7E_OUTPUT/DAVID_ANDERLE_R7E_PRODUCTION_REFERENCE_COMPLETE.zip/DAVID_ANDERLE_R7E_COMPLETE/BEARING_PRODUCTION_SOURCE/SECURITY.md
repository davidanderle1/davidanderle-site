# Security model

The production output is static. No origin application code, database, authentication layer or user-submitted form handler is part of this reference build.

Security headers are defined in `public/_headers`. Cloudflare deployment is configured as Workers Static Assets without a Worker script. Dependency and dry-run observations are evidence inputs, not security certification.
