# Bearing production reference

This directory is a real static Astro repository built for the R7E evidence-production stage of davidanderle.com.

It is not a release certificate. `R7E_EVIDENCE_INDEX.json` records native observations and leaves every final disposition open for independent R7F review.

## Architecture

Astro static output, typed content collections, canonical Markdown and JSON, explicit cross-record validation, authored CSS, no global hydration, no executable JavaScript on ordinary routes, one route-local standards-based Web Component, local Sharp processing, GitHub Actions and Cloudflare Workers Static Assets in assets-only mode.

## Reproduce

Use the exact Node and npm versions recorded in `.node-version`, `package.json` and `R7E_TOOLCHAIN_RESOLUTION.json`.

```sh
npm ci
npm run check
npm run build
npm run verify:dist
```

The complete R7E workflow and raw command records are included in the packaged evidence directory.
