import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://davidanderle.com',
  output: 'static',
  trailingSlash: 'always',
  compressHTML: true,
  outDir: process.env.R7E_OUT_DIR || './dist',
  build: {
    format: 'directory',
    inlineStylesheets: 'never'
  }
});
