import fsp from 'node:fs/promises';
import path from 'node:path';
import { parse } from 'parse5';
import sharp from 'sharp';
import { exists, walk, sha256File, writeJson } from './lib.mjs';

const dist = path.resolve(process.argv[2] || 'dist');
const errors = [];
const ordinaryPaths = ['index.html', 'work/index.html', 'work/research-workspace/index.html', 'work/non-core-real-estate/index.html', 'work/merkle-poseidon/index.html', 'writing/index.html', 'archive/index.html', 'about/index.html', 'about/no-photo/index.html', 'contact/index.html'];

function attrs(node) { return Object.fromEntries((node.attrs || []).map((item) => [item.name, item.value])); }
function scripts(node, rows = []) {
  if (node.nodeName === 'script') rows.push(attrs(node));
  for (const child of node.childNodes || []) scripts(child, rows);
  return rows;
}
function executable(row) { const type = (row.type || '').toLowerCase(); return !type || type === 'module' || type.includes('javascript') || type === 'text/ecmascript'; }

const routeMeasurements = [];
for (const rel of ordinaryPaths) {
  const target = path.join(dist, rel);
  if (!(await exists(target))) { errors.push(`ordinary route output missing: ${rel}`); continue; }
  const html = await fsp.readFile(target, 'utf8');
  const executableCount = scripts(parse(html)).filter(executable).length;
  if (executableCount !== 0) errors.push(`${rel}: executable script count ${executableCount}`);
  routeMeasurements.push({ path: rel, bytes: Buffer.byteLength(html), executableScripts: executableCount, sha256: await sha256File(target) });
}

const comparisonPath = path.join(dist, 'visual-comparison/index.html');
if (!(await exists(comparisonPath))) errors.push('visual comparison output missing');
else {
  const html = await fsp.readFile(comparisonPath, 'utf8');
  const count = scripts(parse(html)).filter(executable).length;
  if (count !== 1) errors.push(`visual comparison expected one executable script, observed ${count}`);
  routeMeasurements.push({ path: 'visual-comparison/index.html', bytes: Buffer.byteLength(html), executableScripts: count, sha256: await sha256File(comparisonPath) });
}

const home = await fsp.readFile(path.join(dist, 'index.html'), 'utf8');
if (home.indexOf('id="selected-evidence"') < 0 || home.indexOf('id="trajectory"') < 0 || home.indexOf('id="selected-evidence"') > home.indexOf('id="trajectory"')) errors.push('generated homepage evidence ordering invariant failed');
for (const [route, marker] of [['work/research-workspace/index.html', 'material-graphite'], ['work/non-core-real-estate/index.html', 'material-oxide'], ['work/merkle-poseidon/index.html', 'material-paper']]) {
  const html = await fsp.readFile(path.join(dist, route), 'utf8');
  if (!html.includes(marker)) errors.push(`${route}: material marker ${marker} missing`);
}
for (const rel of ['404.html', '_headers', '_redirects', 'sitemap.xml', 'robots.txt']) if (!(await exists(path.join(dist, rel)))) errors.push(`deployment artifact missing: ${rel}`);
if (await exists(path.join(dist, '404.html'))) {
  const html = await fsp.readFile(path.join(dist, '404.html'), 'utf8');
  if (!html.includes('data-custom-404="bearing"')) errors.push('custom 404 marker missing');
}
const headers = await fsp.readFile(path.join(dist, '_headers'), 'utf8');
for (const marker of ['Content-Security-Policy:', 'X-Content-Type-Options:', 'Referrer-Policy:', 'Permissions-Policy:']) if (!headers.includes(marker)) errors.push(`_headers missing ${marker}`);

const assetFiles = await walk(path.join(dist, '_astro'));
const jsAssets = assetFiles.filter((x) => x.endsWith('.js'));
const cssAssets = assetFiles.filter((x) => x.endsWith('.css'));
if (jsAssets.length > 1) errors.push(`expected at most one JavaScript asset, observed ${jsAssets.length}`);
if (cssAssets.length === 0) errors.push('no generated CSS asset observed');
const assets = [];
for (const file of [...jsAssets, ...cssAssets]) assets.push({ path: path.relative(dist, file).split(path.sep).join('/'), bytes: (await fsp.stat(file)).size, sha256: await sha256File(file) });

const photoManifestPath = path.join(dist, 'media', 'portrait-manifest.json');
let portrait = null;
if (await exists(photoManifestPath)) portrait = JSON.parse(await fsp.readFile(photoManifestPath, 'utf8'));
for (const rel of ['media/portrait-256x320.webp', 'media/portrait-256x320.avif']) {
  const target = path.join(dist, rel);
  if (await exists(target)) {
    const meta = await sharp(target).metadata();
    if (meta.width > 256 || meta.height > 320) errors.push(`${rel}: exceeds 256 x 320 envelope`);
  }
}

const report = {
  schema: 'davidanderle.r7e.dist-verification.v1',
  dist,
  ordinaryRouteCount: ordinaryPaths.length,
  routeMeasurements,
  assets,
  javascriptAssetCount: jsAssets.length,
  cssAssetCount: cssAssets.length,
  portrait,
  errors
};
await writeJson('evidence/reports/dist-verification.json', report);
if (errors.length) { console.error(errors.join('\n')); process.exit(2); }
console.log(JSON.stringify(report, null, 2));
