import fsp from 'node:fs/promises';
import path from 'node:path';
import { ensureDir, sha256File, writeJson } from './lib.mjs';

const count = Number(process.argv[2] || '500');
if (count !== 500) throw new Error(`R7E scale fixture is fixed at 500 records, received ${count}`);
const evidenceDir = path.resolve('evidence/scale/generated-records');
const contentDir = path.resolve('src/content/scale');
await fsp.rm(evidenceDir, { recursive: true, force: true });
await ensureDir(evidenceDir);
await ensureDir(contentDir);
for (const file of await fsp.readdir(contentDir)) if (file.endsWith('.md')) await fsp.rm(path.join(contentDir, file));
const materials = ['graphite', 'oxide', 'paper'];
const manifest = [];
for (let sequence = 1; sequence <= count; sequence += 1) {
  const slug = `scale-${String(sequence).padStart(4, '0')}`;
  const year = 2017 + ((sequence - 1) % 10);
  const material = materials[(sequence - 1) % materials.length];
  const body = `---\ntitle: Scale record ${String(sequence).padStart(4, '0')}\nslug: ${slug}\nyear: ${year}\nsequence: ${sequence}\nmaterial: ${material}\nsummary: Deterministic generated record ${sequence} used only to measure validated static build scale.\n---\n\nThis fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record ${sequence}.\n`;
  const evidencePath = path.join(evidenceDir, `${slug}.md`);
  const contentPath = path.join(contentDir, `${slug}.md`);
  await fsp.writeFile(evidencePath, body, 'utf8');
  await fsp.copyFile(evidencePath, contentPath);
  manifest.push({ slug, year, sequence, material, sha256: await sha256File(evidencePath) });
}
await writeJson('evidence/scale/generated-records-manifest.json', { schema: 'davidanderle.r7e.scale-fixture.v1', count, years: [...new Set(manifest.map((x) => x.year))], records: manifest });
console.log(`Generated ${count} deterministic scale records.`);
