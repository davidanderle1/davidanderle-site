import fsp from 'node:fs/promises';
import path from 'node:path';
import { exists, sha256File, treeManifest, walk, writeJson } from './lib.mjs';

const root = process.cwd();
const commandRoots = [
  { dir: path.resolve('evidence/commands'), prefix: 'evidence/commands' },
  { dir: path.resolve('evidence/bootstrap-host/commands'), prefix: 'evidence/bootstrap-host/commands' }
];
const commands = new Map();
for (const location of commandRoots) {
  if (!(await exists(location.dir))) continue;
  for (const file of (await walk(location.dir)).filter((x) => x.endsWith('.json'))) {
    const record = JSON.parse(await fsp.readFile(file, 'utf8'));
    commands.set(record.id, { record, metadataPath: `${location.prefix}/${path.basename(file)}` });
  }
}

function observation(id) {
  const item = commands.get(id);
  if (!item) return 'NOT_EXECUTED';
  const record = item.record;
  if (record.expected_exit === 'nonzero' && record.native_exit_code !== 0 && record.expectation_met) return 'EXPECTED_REJECTION_OBSERVED';
  if (record.native_exit_code === 0 && record.expectation_met) return 'NATIVE_SUCCESS';
  if (record.native_exit_code === 127) return 'COMMAND_LAUNCH_FAILURE';
  return 'NATIVE_FAILURE';
}

async function rawFilesFor(ids, reports = []) {
  const raw = [];
  for (const id of ids) {
    const item = commands.get(id);
    if (!item) continue;
    raw.push(item.metadataPath);
    for (const candidate of [item.record.stdout_path, item.record.stderr_path]) {
      if (!candidate) continue;
      const base = path.basename(candidate);
      const host = item.metadataPath.includes('bootstrap-host') ? 'evidence/bootstrap-host/raw' : 'evidence/raw';
      raw.push(`${host}/${base}`);
    }
  }
  raw.push(...reports);
  const unique = [...new Set(raw)];
  const rows = [];
  for (const rel of unique) {
    const target = path.resolve(rel);
    const present = await exists(target);
if (!present) { rows.push({ path: rel, exists: false, sha256: null, bytes: null }); continue; }
const stat = await fsp.stat(target);
if (stat.isDirectory()) {
  const manifest = await treeManifest(target);
  rows.push({ path: rel, exists: true, kind: 'directory', files: manifest.files, bytes: manifest.bytes, treeSha256: manifest.treeSha256 });
} else {
  rows.push({ path: rel, exists: true, kind: 'file', sha256: await sha256File(target), bytes: stat.size });
}
  }
  return rows;
}

const claims = [
  { id: 'R7E-G01-OFFICIAL-SOURCES', claim: 'Current official documentation was retrieved from primary publishers and preserved with timestamps and hashes.', commands: ['040-official-sources'], reports: ['R7E_OFFICIAL_SOURCE_LOG.md', 'evidence/official-sources/index.json', 'evidence/reports/official-source-verification.json'] },
  { id: 'R7E-G02-PINNED-TOOLCHAIN', claim: 'The repository contains an exact pinned Node, npm and package toolchain without dependency ranges or latest tags.', commands: ['000-node-version', '001-npm-upgrade', '030-toolchain-environment', '050-source-verification'], reports: ['R7E_TOOLCHAIN_RESOLUTION.json', 'evidence/reports/toolchain-environment.json', 'evidence/reports/source-verification.json'] },
  { id: 'R7E-G03-CLEAN-INSTALL', claim: 'A native npm lockfile resolution and clean npm ci installation completed.', commands: ['010-lockfile', '020-npm-ci'], reports: ['package-lock.json'] },
  { id: 'R7E-G04-TYPED-CONTENT', claim: 'Astro typed content collections and project-wide static analysis completed against canonical Markdown and JSON.', commands: ['060-astro-check', '070-content-validation'], reports: ['src/content.config.ts', 'evidence/reports/content-validation-canonical.json'] },
  { id: 'R7E-G05-CROSS-RECORD-VALIDATION', claim: 'Explicit project-note, maturity, provenance and prominence invariants were evaluated.', commands: ['070-content-validation'], reports: ['evidence/reports/content-validation-canonical.json'] },
  { id: 'R7E-G06-PHOTOGRAPHY-PIPELINE', claim: 'The available 320 x 320 portrait candidate was processed locally without enlargement and outputs did not exceed 256 x 320.', commands: ['080-portrait-selection', '090-image-processing'], reports: ['evidence/reports/portrait-source-selection.json', 'evidence/reports/image-processing.json', 'public/media/portrait-manifest.json'] },
  { id: 'R7E-G07-NATIVE-ASTRO-BUILD', claim: 'A native Astro static build generated the launch site.', commands: ['100-base-build'], reports: ['evidence/reports/dist-verification.json'] },
  { id: 'R7E-G08-ZERO-ORDINARY-JS', claim: 'Ordinary launch routes emitted no executable script tags and remained complete with JavaScript disabled.', commands: ['110-dist-verification', '130-browser-tests'], reports: ['evidence/reports/dist-verification.json', 'evidence/browser/no-js-routes.json'] },
  { id: 'R7E-G09-BOUNDED-WEB-COMPONENT', claim: 'Exactly one route-local standards-based Web Component enhanced static baseline content.', commands: ['050-source-verification', '110-dist-verification', '130-browser-tests'], reports: ['evidence/reports/source-verification.json', 'evidence/reports/dist-verification.json', 'evidence/browser/playwright-report.json'] },
  { id: 'R7E-G10-BROWSER-OUTPUT', claim: 'Representative launch and deep routes were rendered in Chromium and measured.', commands: ['120-playwright-install', '130-browser-tests'], reports: ['evidence/browser/playwright-report.json', 'evidence/browser/measurements/home-desktop-1440.json', 'evidence/browser/measurements/project-oxide-mobile-390.json'] },
  { id: 'R7E-G11-DEDICATED-MOBILE-COMPOSITIONS', claim: 'Dedicated 390 px and 320 px compositions were present in authored CSS and captured in browser screenshots.', commands: ['050-source-verification', '130-browser-tests'], reports: ['src/styles/global.css', 'evidence/browser/screenshots/home-mobile-390.png', 'evidence/browser/screenshots/home-mobile-320.png', 'evidence/browser/screenshots/project-oxide-mobile-390.png', 'evidence/browser/screenshots/project-oxide-mobile-320.png'] },
  { id: 'R7E-G12-ACCESSIBILITY', claim: 'Representative routes were tested with axe-core and keyboard-accessible static structure.', commands: ['130-browser-tests'], reports: ['evidence/browser/axe-representative.json', 'evidence/browser/playwright-report.json'] },
  { id: 'R7E-G13-LIGHTHOUSE-MEASUREMENTS', claim: 'Lighthouse produced raw reports and measured category and web-vital outputs.', commands: ['140-lighthouse'], reports: ['evidence/lighthouse/summary.json', 'evidence/lighthouse/home-desktop.report.json', 'evidence/lighthouse/project-mobile.report.json'] },
  { id: 'R7E-G14-CLOUDFLARE-DRY-RUN', claim: 'Wrangler validated an assets-only Workers Static Assets deployment using a native dry run.', commands: ['150-wrangler-dry-run'], reports: ['wrangler.jsonc', 'evidence/wrangler-dry-run'] },
  { id: 'R7E-G15-CLOUDFLARE-BEHAVIOR', claim: 'Local Wrangler preview was queried for security headers, legacy redirect behavior and custom 404 handling.', commands: ['160-wrangler-preview'], reports: ['evidence/wrangler-preview/report.json'] },
  { id: 'R7E-G16-FIVE-HUNDRED-RECORD-SCALE', claim: 'Exactly 500 validated fixture records generated exactly 500 static detail pages and year indexes below 200 records.', commands: ['170-scale-generate', '180-scale-content-validation', '190-scale-build', '200-scale-verification'], reports: ['evidence/scale/generated-records-manifest.json', 'evidence/reports/content-validation-scale.json', 'evidence/reports/scale-verification.json'] },
  { id: 'R7E-G17-REPRODUCIBILITY', claim: 'Two fresh npm ci workspaces built byte-identical static output trees from the same source and lockfile.', commands: ['270-reproducibility'], reports: ['evidence/reproducibility/report.json'] },
  { id: 'R7E-G18-NEGATIVE-SCHEMA', claim: 'An invalid Astro content-schema fixture was rejected by a native build.', commands: ['221-neg-schema-astro'], reports: [] },
  { id: 'R7E-G19-NEGATIVE-CROSS-REFERENCE', claim: 'An unknown cross-record reference was rejected by explicit validation.', commands: ['231-neg-crossref-validation'], reports: [] },
  { id: 'R7E-G20-NEGATIVE-DUPLICATE-SLUG', claim: 'A duplicate canonical slug was rejected by explicit validation.', commands: ['241-neg-duplicate-validation'], reports: [] },
  { id: 'R7E-G21-NEGATIVE-PHOTO-UPSCALE', claim: 'A 128 x 128 source was rejected rather than enlarged into the approved portrait envelope.', commands: ['251-neg-photo-process'], reports: [] },
  { id: 'R7E-G22-NEGATIVE-ORDINARY-JS', claim: 'Injected executable JavaScript on an ordinary route was rejected by dist verification.', commands: ['261-neg-js-dist'], reports: [] },
  { id: 'R7E-G23-SUPPLY-CHAIN-OBSERVATION', claim: 'npm audit, dependency tree and CycloneDX SBOM commands were executed and preserved.', commands: ['280-npm-audit', '290-sbom', '300-npm-ls'], reports: ['evidence/supply-chain/sbom.cdx.json'] }
];

const gates = [];
for (const claim of claims) {
  const observations = claim.commands.map((id) => ({ commandId: id, observation: observation(id) }));
  let producerObservation = 'NATIVE_SUCCESS';
  if (observations.some((x) => x.observation === 'NOT_EXECUTED')) producerObservation = 'NOT_VERIFIED';
  else if (observations.some((x) => ['NATIVE_FAILURE', 'COMMAND_LAUNCH_FAILURE'].includes(x.observation))) producerObservation = 'OBSERVED_FAILURE';
  else if (observations.every((x) => x.observation === 'EXPECTED_REJECTION_OBSERVED')) producerObservation = 'EXPECTED_REJECTION_OBSERVED';
  else if (observations.some((x) => x.observation === 'EXPECTED_REJECTION_OBSERVED')) producerObservation = 'MIXED_NATIVE_SUCCESS_AND_EXPECTED_REJECTION';
  if (claim.id === 'R7E-G06-PHOTOGRAPHY-PIPELINE') {
    const reportPath = 'evidence/reports/image-processing.json';
    if (!(await exists(reportPath))) producerObservation = 'NOT_VERIFIED';
    else {
      const imageReport = JSON.parse(await fsp.readFile(reportPath, 'utf8'));
      if (imageReport.result !== 'CROP_WITHOUT_ENLARGEMENT') producerObservation = 'NOT_VERIFIED';
    }
  }
  gates.push({
    id: claim.id,
    claim: claim.claim,
    producerObservation,
    r7fDisposition: 'PENDING_INDEPENDENT_REVIEW',
    commandObservations: observations,
    rawEvidence: await rawFilesFor(claim.commands, claim.reports)
  });
}

const commandSummary = [...commands.values()].map(({ record, metadataPath }) => ({ id: record.id, metadataPath, nativeExitCode: record.native_exit_code, expectedExit: record.expected_exit, expectationMet: record.expectation_met, startTimestampUtc: record.start_timestamp_utc, endTimestampUtc: record.end_timestamp_utc }));
const index = {
  schema: 'davidanderle.r7e.evidence-index.v1',
  generatedAtUtc: new Date().toISOString(),
  certificationStatement: 'R7E is an implementation and raw-evidence production stage. No gate in this index is independently certified. Final PASS, FAIL or release disposition belongs to R7F.',
  statusVocabulary: {
    NATIVE_SUCCESS: 'The recorded native command exited zero under its declared expectation.',
    EXPECTED_REJECTION_OBSERVED: 'A deliberately invalid fixture produced the required non-zero native exit.',
    OBSERVED_FAILURE: 'At least one native command failed or did not meet its declared expectation.',
    NOT_VERIFIED: 'Required raw command evidence was not produced.'
  },
  gates,
  commands: commandSummary
};
await writeJson('R7E_EVIDENCE_INDEX.json', index);
await writeJson('evidence/R7E_EVIDENCE_INDEX.json', index);

const counts = Object.fromEntries(['NATIVE_SUCCESS', 'EXPECTED_REJECTION_OBSERVED', 'MIXED_NATIVE_SUCCESS_AND_EXPECTED_REJECTION', 'OBSERVED_FAILURE', 'NOT_VERIFIED'].map((key) => [key, gates.filter((x) => x.producerObservation === key).length]));
const failed = gates.filter((x) => ['OBSERVED_FAILURE', 'NOT_VERIFIED'].includes(x.producerObservation));
const report = [
  '# R7E producer report',
  '',
  '**Authority boundary:** this report describes observations produced by the implementation workflow. It does not certify release readiness. R7F must inspect the raw files and assign final dispositions.',
  '',
  '## Observation counts',
  '',
  ...Object.entries(counts).map(([key, value]) => `- ${key}: ${value}`),
  '',
  '## Open or failed observations',
  '',
  ...(failed.length ? failed.map((gate) => `- ${gate.id}: ${gate.producerObservation}`) : ['- None recorded by the producer; independent review remains required.']),
  '',
  '## Deliberate limitations',
  '',
  '- The workflow performs no production deployment and uses no Cloudflare production credential.',
  '- Lighthouse values are measurements from one GitHub-hosted runner and are not universal performance guarantees.',
  '- A dimension-matching incumbent portrait candidate may be processed, but exact identity against the R5 authority source remains pending an independent hash comparison unless the supplemental input-authority report proves a match.',
  '- The 500-record corpus is a deterministic non-canonical fixture and is excluded from the public sitemap.',
  '- Security headers and local Wrangler behavior are evidence inputs, not a penetration test or security certification.',
  '',
  '## Independent audit entry point',
  '',
  'Begin with `R7E_EVIDENCE_INDEX.json`, then open each command metadata record, its separate stdout and stderr, and the generated artifact hashes.'
].join('\n') + '\n';
await fsp.writeFile('R7E_PRODUCER_REPORT.md', report, 'utf8');
await fsp.writeFile('R7E_LIMITATIONS.md', report.split('## Deliberate limitations')[1]?.split('## Independent audit entry point')[0]?.trim() + '\n', 'utf8');

const manifests = {};
            const generatedSourceManifest = 'evidence/reports/source-generation-manifest.json';
            if (await exists(generatedSourceManifest)) {
              const sourceManifest = JSON.parse(await fsp.readFile(generatedSourceManifest, 'utf8'));
              manifests.sourceBeforeInstall = { files: sourceManifest.files, bytes: sourceManifest.bytes, treeSha256: sourceManifest.treeSha256 };
            } else manifests.sourceBeforeInstall = null;
            for (const [name, target] of [['dist', 'dist'], ['distScale', 'dist-scale'], ['evidence', 'evidence']]) {
              if (!(await exists(target))) { manifests[name] = null; continue; }
              const manifest = await treeManifest(target);
              manifests[name] = { files: manifest.files, bytes: manifest.bytes, treeSha256: manifest.treeSha256 };
            }
await writeJson('R7E_TREE_SUMMARY.json', manifests);
console.log(JSON.stringify({ counts, failed: failed.map((x) => x.id), manifests }, null, 2));
