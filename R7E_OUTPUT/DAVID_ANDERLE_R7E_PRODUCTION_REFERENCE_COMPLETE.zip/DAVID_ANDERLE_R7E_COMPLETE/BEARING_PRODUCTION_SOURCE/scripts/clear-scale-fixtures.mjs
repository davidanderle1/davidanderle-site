import fsp from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve('src/content/scale');
await fsp.mkdir(root, { recursive: true });
let removed = 0;
for (const file of await fsp.readdir(root)) if (file.endsWith('.md')) { await fsp.rm(path.join(root, file)); removed += 1; }
console.log(`Removed ${removed} generated scale records from the production collection directory.`);
