import fsp from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { walk, sha256File, writeJson } from './lib.mjs';

const sourceDir = path.resolve('src/assets/portrait');
const outputDir = path.resolve('public/media');
await fsp.mkdir(outputDir, { recursive: true });
const sources = (await walk(sourceDir)).filter((file) => path.basename(file).startsWith('approved-source.') && !file.endsWith('.json'));
for (const stale of ['portrait-256x320.webp', 'portrait-256x320.avif']) await fsp.rm(path.join(outputDir, stale), { force: true });

if (sources.length === 0) {
  const report = {
    schema: 'davidanderle.r7e.image-processing.v1',
    result: 'NO_APPROVED_SOURCE_PRESENT',
    compactPhotoEnabled: false,
    noPhotoStateRequired: true
  };
  await writeJson(path.join(outputDir, 'portrait-manifest.json'), report);
  await writeJson('evidence/reports/image-processing.json', report);
  console.log(JSON.stringify(report, null, 2));
  process.exit(0);
}
if (sources.length !== 1) throw new Error(`Expected one approved source, observed ${sources.length}`);
const source = sources[0];
const metadata = await sharp(source).metadata();
if (metadata.width !== 320 || metadata.height !== 320) {
  throw new Error(`R5 source envelope violated: expected exactly 320 x 320, observed ${metadata.width} x ${metadata.height}`);
}
const left = 32;
const crop = { left, top: 0, width: 256, height: 320 };
const webp = path.join(outputDir, 'portrait-256x320.webp');
const avif = path.join(outputDir, 'portrait-256x320.avif');
await sharp(source).extract(crop).webp({ quality: 86, smartSubsample: true }).toFile(webp);
await sharp(source).extract(crop).avif({ quality: 56, effort: 6 }).toFile(avif);
const webpMeta = await sharp(webp).metadata();
const avifMeta = await sharp(avif).metadata();
for (const [label, value] of [['webp', webpMeta], ['avif', avifMeta]]) {
  if (value.width !== 256 || value.height !== 320) throw new Error(`${label} output envelope violated: ${value.width} x ${value.height}`);
  if (value.width > metadata.width || value.height > metadata.height) throw new Error(`${label} output enlarged the source`);
}
const report = {
  schema: 'davidanderle.r7e.image-processing.v1',
  result: 'CROP_WITHOUT_ENLARGEMENT',
  deterministicTimestamp: '2026-08-29T00:00:00.000Z',
  source: { path: path.relative(process.cwd(), source).split(path.sep).join('/'), width: metadata.width, height: metadata.height, format: metadata.format, sha256: await sha256File(source) },
  operation: { type: 'extract', crop, enlargement: false },
  outputs: [
    { path: 'public/media/portrait-256x320.webp', width: webpMeta.width, height: webpMeta.height, format: webpMeta.format, sha256: await sha256File(webp) },
    { path: 'public/media/portrait-256x320.avif', width: avifMeta.width, height: avifMeta.height, format: avifMeta.format, sha256: await sha256File(avif) }
  ],
  r7fAuthorityHashDisposition: 'PENDING_INDEPENDENT_R5_HASH_COMPARISON'
};
await writeJson(path.join(outputDir, 'portrait-manifest.json'), report);
await writeJson('evidence/reports/image-processing.json', report);
console.log(JSON.stringify(report, null, 2));
