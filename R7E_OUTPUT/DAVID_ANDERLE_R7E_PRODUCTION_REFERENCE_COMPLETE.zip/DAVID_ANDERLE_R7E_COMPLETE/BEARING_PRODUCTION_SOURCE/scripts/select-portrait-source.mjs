import fsp from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { walk, sha256File, writeJson } from './lib.mjs';

const searchRoot = path.resolve(process.argv[2] || '..');
const destination = path.resolve('src/assets/portrait');
const evidencePath = path.resolve('evidence/reports/portrait-source-selection.json');
await fsp.mkdir(destination, { recursive: true });
const extensions = new Set(['.png', '.jpg', '.jpeg', '.webp', '.avif']);
const candidates = [];
for (const file of await walk(searchRoot, { excludeNames: ['.git', 'node_modules', 'dist', 'dist-scale', 'evidence', 'R7E_PACKAGE', 'R7E_OUTPUT'] })) {
  if (!extensions.has(path.extname(file).toLowerCase())) continue;
  if (file.startsWith(process.cwd() + path.sep)) continue;
  try {
    const metadata = await sharp(file).metadata();
    if (metadata.width !== 320 || metadata.height !== 320) continue;
    const rel = path.relative(searchRoot, file).split(path.sep).join('/');
    const lower = rel.toLowerCase();
    let score = 0;
    for (const token of ['portrait', 'profile', 'headshot', 'david', 'photo']) if (lower.includes(token)) score += 10;
    if (lower.includes('320')) score += 4;
    if (lower.includes('approved') || lower.includes('final')) score += 6;
    candidates.push({ file, relativePath: rel, width: metadata.width, height: metadata.height, format: metadata.format, score, bytes: (await fsp.stat(file)).size, sha256: await sha256File(file) });
  } catch { /* invalid image candidates are ignored */ }
}
candidates.sort((a, b) => b.score - a.score || a.bytes - b.bytes || a.relativePath.localeCompare(b.relativePath));
for (const existing of await fsp.readdir(destination)) if (existing.startsWith('approved-source.')) await fsp.rm(path.join(destination, existing), { force: true });

const approvedHashes = new Set((process.env.R7E_APPROVED_PORTRAIT_SHA256 || '').split(',').map((value) => value.trim().toLowerCase()).filter(Boolean));
const approvedPath = process.env.R7E_APPROVED_PORTRAIT_PATH ? path.resolve(process.env.R7E_APPROVED_PORTRAIT_PATH) : null;
const selected = candidates.find((candidate) => approvedHashes.has(candidate.sha256.toLowerCase()) || (approvedPath && path.resolve(candidate.file) === approvedPath));
if (!selected) {
  const report = {
    schema: 'davidanderle.r7e.portrait-selection.v2',
    searchRoot,
    result: candidates.length ? 'DIMENSION_CANDIDATES_FOUND_BUT_NOT_R5_AUTHORIZED' : 'NO_320_X_320_CANDIDATE',
    compactPhotoEnabled: false,
    authorizationInputs: { approvedHashes: [...approvedHashes], approvedPath },
    candidateCount: candidates.length,
    candidates,
    r7fAuthorityHashDisposition: 'NOT_VERIFIED_PENDING_R5_AUTHORIZATION'
  };
  await writeJson(path.join(destination, 'provenance.json'), report);
  await writeJson(evidencePath, report);
  console.log(JSON.stringify(report, null, 2));
  process.exit(0);
}

const extension = path.extname(selected.file).toLowerCase() || '.png';
const target = path.join(destination, `approved-source${extension}`);
await fsp.copyFile(selected.file, target);
const report = {
  schema: 'davidanderle.r7e.portrait-selection.v2',
  searchRoot,
  result: 'DIMENSION_MATCH_CANDIDATE_SELECTED',
  compactPhotoEnabled: true,
  selectionBasis: 'Exact 320 x 320 dimensions plus explicit R5 source-path or SHA-256 authorization.',
  selected: { ...selected, copiedTo: path.relative(process.cwd(), target).split(path.sep).join('/') },
  candidateCount: candidates.length,
  candidates,
  r7fAuthorityHashDisposition: 'AUTHORIZED_INPUT_RECORDED_PENDING_INDEPENDENT_REVIEW'
};
await writeJson(path.join(destination, 'provenance.json'), report);
await writeJson(evidencePath, report);
console.log(JSON.stringify(report, null, 2));
