import fsp from 'node:fs/promises';
import path from 'node:path';
import { exists, walk, treeManifest, writeJson } from './lib.mjs';

const errors = [];
const fixtureFiles = (await walk('evidence/scale/generated-records')).filter((x) => x.endsWith('.md'));
const detailFiles = (await walk('dist-scale/scale')).filter((x) => /scale-[0-9]{4}\/index\.html$/.test(x.split(path.sep).join('/')));
if (fixtureFiles.length !== 500) errors.push(`expected 500 generated fixtures, observed ${fixtureFiles.length}`);
if (detailFiles.length !== 500) errors.push(`expected 500 generated detail pages, observed ${detailFiles.length}`);
const yearCounts = {};
for (let year = 2017; year <= 2026; year += 1) {
  const target = path.join('dist-scale', 'scale', 'archive', String(year), 'index.html');
  if (!(await exists(target))) { errors.push(`missing scale archive year ${year}`); continue; }
  const html = await fsp.readFile(target, 'utf8');
  const count = (html.match(/href="\/scale\/scale-[0-9]{4}\//g) || []).length;
  yearCounts[year] = count;
  if (count > 200) errors.push(`year ${year} contains ${count} records, above policy ceiling`);
}
const manifest = await treeManifest('dist-scale');
const report = {
  schema: 'davidanderle.r7e.scale-verification.v1',
  generatedFixtureCount: fixtureFiles.length,
  generatedDetailPageCount: detailFiles.length,
  archiveYearCounts: yearCounts,
  maximumArchivePageRecords: Math.max(...Object.values(yearCounts)),
  distScaleFiles: manifest.files,
  distScaleBytes: manifest.bytes,
  distScaleTreeSha256: manifest.treeSha256,
  errors
};
await writeJson('evidence/reports/scale-verification.json', report);
if (errors.length) { console.error(errors.join('\n')); process.exit(2); }
console.log(JSON.stringify(report, null, 2));
