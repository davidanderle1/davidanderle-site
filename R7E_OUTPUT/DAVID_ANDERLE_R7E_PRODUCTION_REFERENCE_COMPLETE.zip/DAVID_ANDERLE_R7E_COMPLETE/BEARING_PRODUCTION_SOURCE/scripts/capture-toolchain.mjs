import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { readJson, writeJson } from './lib.mjs';

function version(command, args = ['--version']) {
  try { return execFileSync(command, args, { encoding: 'utf8' }).trim(); }
  catch (error) { return { error: String(error) }; }
}
const packageJson = await readJson('package.json');
const report = {
  schema: 'davidanderle.r7e.toolchain-environment.v1',
  timestampUtc: new Date().toISOString(),
  runtime: {
    node: process.version,
    npm: version('npm'),
    astro: version('npx', ['astro', '--version']),
    playwright: version('npx', ['playwright', '--version']),
    wrangler: version('npx', ['wrangler', '--version']),
    lighthouse: packageJson.devDependencies.lighthouse,
    sharp: packageJson.devDependencies.sharp,
    typescript: packageJson.devDependencies.typescript
  },
  pinned: {
    packageManager: packageJson.packageManager,
    engines: packageJson.engines,
    dependencies: packageJson.devDependencies
  },
  host: {
    platform: os.platform(),
    release: os.release(),
    arch: os.arch(),
    cpus: os.cpus().map((cpu) => cpu.model),
    totalMemoryBytes: os.totalmem(),
    githubRunId: process.env.GITHUB_RUN_ID || null,
    githubSha: process.env.GITHUB_SHA || null,
    githubRef: process.env.GITHUB_REF || null
  }
};
await writeJson('evidence/reports/toolchain-environment.json', report);
console.log(JSON.stringify(report, null, 2));
