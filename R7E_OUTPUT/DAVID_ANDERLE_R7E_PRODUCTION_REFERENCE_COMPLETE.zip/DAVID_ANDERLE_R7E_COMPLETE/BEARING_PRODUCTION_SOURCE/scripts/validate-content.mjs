import fsp from 'node:fs/promises';
import path from 'node:path';
import matter from 'gray-matter';
import { walk, writeJson } from './lib.mjs';

const errors = [];
const warnings = [];
const projectDir = path.resolve('src/content/projects');
const noteDir = path.resolve('src/content/notes');
const scaleDir = path.resolve('src/content/scale');

async function loadMarkdown(root) {
  const records = [];
  for (const file of (await walk(root)).filter((x) => /\.mdx?$/.test(x))) {
    const parsed = matter(await fsp.readFile(file, 'utf8'));
    records.push({ file, relative: path.relative(process.cwd(), file), data: parsed.data, body: parsed.content });
  }
  return records;
}

const projects = await loadMarkdown(projectDir);
const notes = await loadMarkdown(noteDir);
const scale = await loadMarkdown(scaleDir);
const projectSlugs = new Set();
const noteSlugs = new Set();
const allowedMaturity = new Set(['working-prototype', 'research-in-progress', 'private-system']);
const allowedMaterials = new Set(['graphite', 'oxide', 'paper']);
const forbiddenInflation = [/world[- ]class/i, /guaranteed/i, /published paper/i];

function requireValue(record, key) {
  if (record.data[key] === undefined || record.data[key] === null || record.data[key] === '') errors.push(`${record.relative}: missing ${key}`);
}

for (const record of projects) {
  for (const key of ['title', 'slug', 'summary', 'publishedAt', 'year', 'role', 'maturity', 'authorship', 'access', 'material', 'featured', 'sortOrder', 'evidence', 'links', 'relatedNotes']) requireValue(record, key);
  if (projectSlugs.has(record.data.slug)) errors.push(`${record.relative}: duplicate project slug ${record.data.slug}`);
  projectSlugs.add(record.data.slug);
  if (!allowedMaturity.has(record.data.maturity)) errors.push(`${record.relative}: invalid maturity ${record.data.maturity}`);
  if (!allowedMaterials.has(record.data.material)) errors.push(`${record.relative}: invalid material ${record.data.material}`);
  if (!Array.isArray(record.data.evidence) || record.data.evidence.length < 2) errors.push(`${record.relative}: fewer than two evidence records`);
  const combined = `${record.data.title || ''} ${record.data.summary || ''} ${record.body}`;
  for (const pattern of forbiddenInflation) if (pattern.test(combined)) errors.push(`${record.relative}: unsupported inflation matched ${pattern}`);
}

for (const record of notes) {
  for (const key of ['title', 'slug', 'summary', 'publishedAt', 'year', 'status', 'material', 'relatedProjects']) requireValue(record, key);
  if (noteSlugs.has(record.data.slug)) errors.push(`${record.relative}: duplicate note slug ${record.data.slug}`);
  noteSlugs.add(record.data.slug);
  if (!allowedMaterials.has(record.data.material)) errors.push(`${record.relative}: invalid material ${record.data.material}`);
}

for (const project of projects) {
  for (const noteSlug of project.data.relatedNotes || []) if (!noteSlugs.has(noteSlug)) errors.push(`${project.relative}: unknown related note ${noteSlug}`);
}
for (const note of notes) {
  for (const projectSlug of note.data.relatedProjects || []) if (!projectSlugs.has(projectSlug)) errors.push(`${note.relative}: unknown related project ${projectSlug}`);
}

const education = JSON.parse(await fsp.readFile('src/content/data/education.json', 'utf8'));
const experience = JSON.parse(await fsp.readFile('src/content/data/experience.json', 'utf8'));
for (const row of education) {
  if (row.startYear > row.endYear) errors.push(`education ${row.id}: startYear after endYear`);
  if (row.id === 'uw-madison-exchange' && row.prominence !== 'secondary') errors.push('UW–Madison must remain secondary context');
}
for (const row of experience) {
  if (row.id === 'uw-context' && row.prominence !== 'secondary') errors.push('UW experience context must remain secondary');
}

if (projects.length !== 3) errors.push(`expected 3 canonical projects, observed ${projects.length}`);
if (notes.length !== 3) errors.push(`expected 3 canonical notes, observed ${notes.length}`);
if (process.env.R7E_SCALE === '1' && scale.length !== 500) errors.push(`scale mode expected 500 records, observed ${scale.length}`);
if (process.env.R7E_SCALE !== '1' && scale.length > 0) warnings.push(`${scale.length} generated scale records present outside scale mode`);

const report = {
  schema: 'davidanderle.r7e.content-validation.v1',
  canonicalProjects: projects.length,
  canonicalNotes: notes.length,
  educationRecords: education.length,
  experienceRecords: experience.length,
  scaleRecords: scale.length,
  errors,
  warnings,
  projectSlugs: [...projectSlugs].sort(),
  noteSlugs: [...noteSlugs].sort()
};
const modePath = process.env.R7E_SCALE === '1' ? 'evidence/reports/content-validation-scale.json' : 'evidence/reports/content-validation-canonical.json';
await writeJson(modePath, report);
await writeJson('evidence/reports/content-validation.json', report);
if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(2);
}
console.log(JSON.stringify(report, null, 2));
