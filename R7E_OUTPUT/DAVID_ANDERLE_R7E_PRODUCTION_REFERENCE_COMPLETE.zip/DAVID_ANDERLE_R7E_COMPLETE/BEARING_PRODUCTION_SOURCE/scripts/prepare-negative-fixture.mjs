import fsp from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';

const kind = process.argv[2];
const destination = path.resolve(process.argv[3] || `../r7e-negative-${kind}`);
if (!kind) throw new Error('fixture kind required');
await fsp.rm(destination, { recursive: true, force: true });
await fsp.cp(process.cwd(), destination, {
  recursive: true,
  filter: (source) => {
    const rel = path.relative(process.cwd(), source);
    const first = rel.split(path.sep)[0];
    return !['node_modules', 'evidence', 'dist', 'dist-scale', 'R7E_PACKAGE', 'R7E_OUTPUT', '.astro'].includes(first);
  }
});
await fsp.symlink(path.resolve('node_modules'), path.join(destination, 'node_modules'), 'dir');
await fsp.mkdir(path.join(destination, 'evidence'), { recursive: true });

if (kind === 'schema') {
  await fsp.writeFile(path.join(destination, 'src/content/projects/invalid-schema.md'), `---\ntitle: Invalid schema fixture\nslug: invalid-schema\nsummary: This intentionally invalid fixture omits required project fields so Astro schema validation must reject it.\npublishedAt: 2026-08-29\nyear: 2026\n---\n\nExpected rejection.\n`);
} else if (kind === 'crossref') {
  const target = path.join(destination, 'src/content/projects/research-workspace.md');
  let body = await fsp.readFile(target, 'utf8');
  body = body.replace('relatedNotes:\n  - risk-before-optimization', 'relatedNotes:\n  - note-that-does-not-exist');
  await fsp.writeFile(target, body);
} else if (kind === 'duplicate') {
  const source = path.join(destination, 'src/content/projects/research-workspace.md');
  await fsp.copyFile(source, path.join(destination, 'src/content/projects/duplicate-slug.md'));
} else if (kind === 'photo-upscale') {
  const portraitDir = path.join(destination, 'src/assets/portrait');
  await fsp.rm(portraitDir, { recursive: true, force: true });
  await fsp.mkdir(portraitDir, { recursive: true });
  await sharp({ create: { width: 128, height: 128, channels: 3, background: '#777777' } }).png().toFile(path.join(portraitDir, 'approved-source.png'));
} else if (kind === 'ordinary-js') {
  await fsp.cp(path.resolve('dist'), path.join(destination, 'dist'), { recursive: true });
  const index = path.join(destination, 'dist/index.html');
  let html = await fsp.readFile(index, 'utf8');
  html = html.replace('</body>', '<script src="/forbidden.js"></script></body>');
  await fsp.writeFile(index, html);
} else {
  throw new Error(`unknown fixture kind ${kind}`);
}
console.log(destination);
