import path from 'node:path';
import { readJson, writeJson } from './lib.mjs';

const sourceIndex = path.resolve('evidence/official-sources/index.json');
const index = await readJson(sourceIndex);
const failures = [];
for (const item of index.sources) {
  if (!(item.httpStatus >= 200 && item.httpStatus < 400)) failures.push(`${item.id}: HTTP ${item.httpStatus}`);
  if (!item.sha256) failures.push(`${item.id}: missing response hash`);
  if (item.expectedMarkers?.length && item.markerHits === 0) failures.push(`${item.id}: no expected marker observed`);
}
const report = {
  schema: 'davidanderle.r7e.official-source-observation.v1',
  retrievalTimestampUtc: index.retrievalTimestampUtc,
  sourceCount: index.sources.length,
  successfulHttpResponses: index.sources.filter((x) => x.httpStatus >= 200 && x.httpStatus < 400).length,
  markerConfirmedSources: index.sources.filter((x) => x.markerHits > 0).length,
  failures
};
await writeJson('evidence/reports/official-source-verification.json', report);
if (failures.length) {
  console.error(failures.join('\n'));
  process.exit(2);
}
console.log(JSON.stringify(report, null, 2));
