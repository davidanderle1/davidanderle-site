#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

UTC = dt.timezone.utc
ROOT = Path.cwd()
PACKAGE = ROOT.parent / 'R7E_PACKAGE_WORK'
OUTPUT = ROOT.parent / 'R7E_OUTPUT'
ZIP_PATH = OUTPUT / 'DAVID_ANDERLE_R7E_PRODUCTION_REFERENCE_COMPLETE.zip'
FIXED_ZIP_TIME = (2026, 8, 29, 0, 0, 0)

def now():
    return dt.datetime.now(UTC).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def copy_tree(source: Path, destination: Path, excluded: set[str] | None = None):
    excluded = excluded or set()
    if not source.exists():
        return
    for item in sorted(source.rglob('*')):
        rel = item.relative_to(source)
        if any(part in excluded for part in rel.parts):
            continue
        target = destination / rel
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif item.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)

def manifest(root: Path):
    rows = []
    for item in sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'R7E_PACKAGE_MANIFEST.json'):
        rows.append({'path': item.relative_to(root).as_posix(), 'bytes': item.stat().st_size, 'sha256': sha256(item)})
    canonical = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return {'files': len(rows), 'bytes': sum(x['bytes'] for x in rows), 'treeSha256': hashlib.sha256(canonical).hexdigest(), 'entries': rows}

def create_zip(source: Path, target: Path):
    temp = target.with_suffix('.tmp.zip')
    temp.unlink(missing_ok=True)
    with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for item in sorted(p for p in source.rglob('*') if p.is_file()):
            rel = Path('DAVID_ANDERLE_R7E_COMPLETE') / item.relative_to(source)
            info = zipfile.ZipInfo(rel.as_posix(), FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o644 & 0xFFFF) << 16
            archive.writestr(info, item.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    temp.replace(target)

started = now()
shutil.rmtree(PACKAGE, ignore_errors=True)
OUTPUT.mkdir(parents=True, exist_ok=True)
PACKAGE.mkdir(parents=True, exist_ok=True)

copy_tree(ROOT, PACKAGE / 'BEARING_PRODUCTION_SOURCE', {'node_modules', '.astro', 'dist', 'dist-scale', 'evidence', 'R7E_PACKAGE', 'R7E_OUTPUT'})
copy_tree(ROOT / 'dist', PACKAGE / 'BEARING_GENERATED_SITE')
copy_tree(ROOT / 'dist', PACKAGE / 'BEARING_VERIFIED_DIST')
copy_tree(ROOT / 'dist-scale', PACKAGE / 'BEARING_SCALE_SITE_500')
copy_tree(ROOT / 'evidence', PACKAGE / 'R7E_RAW_EVIDENCE', {'work'})

root_files = [
    'R7E_EVIDENCE_INDEX.json', 'R7E_OFFICIAL_SOURCE_LOG.md', 'R7E_TOOLCHAIN_RESOLUTION.json',
    'R7E_PRODUCER_REPORT.md', 'R7E_LIMITATIONS.md', 'R7E_TREE_SUMMARY.json',
    'R7E_AUTHORITY_REQUIREMENT_MATRIX.md', 'R7E_INPUT_PACKAGE_DECLARATION.json', 'R7E_FINAL_GATE.json'
]
for name in root_files:
    source = ROOT / name
    if source.exists():
        shutil.copy2(source, PACKAGE / name)

readme = '''# David Anderle R7E complete audit package\n\nThis archive contains the production-reference Astro source, generated launch site, independently named verified dist copy, 500-record scale build, two-clean-run reproducibility evidence and raw evidence. The producer final gate completed successfully before packaging.\n\nR7E does not certify itself. Start with `R7E_EVIDENCE_INDEX.json`; assign final gate dispositions only in an independent R7F review.\n'''
(PACKAGE / 'README_FIRST.md').write_text(readme, encoding='utf-8')
package_manifest = manifest(PACKAGE)
(PACKAGE / 'R7E_PACKAGE_MANIFEST.json').write_text(json.dumps(package_manifest, indent=2) + '\n', encoding='utf-8')

ended = now()
command_record = {
    'schema': 'davidanderle.r7e.command-evidence.v1',
    'id': '320-package',
    'command_argv': [sys.executable, 'scripts/package_r7e.py'],
    'command_shell_escaped': f'{sys.executable} scripts/package_r7e.py',
    'working_directory': str(ROOT),
    'start_timestamp_utc': started,
    'end_timestamp_utc': ended,
    'native_exit_code': 0,
    'expected_exit': 'zero',
    'expectation_met': True,
    'stdout_path': str(ROOT / 'evidence/raw/320-package.stdout.log'),
    'stderr_path': str(ROOT / 'evidence/raw/320-package.stderr.log'),
    'tool_version': {'output': sys.version},
    'artifacts': [{'kind': 'directory', 'path': str(PACKAGE), 'files': package_manifest['files'], 'bytes': package_manifest['bytes'], 'tree_sha256': package_manifest['treeSha256']}]
}
command_dir = ROOT / 'evidence/commands'; raw_dir = ROOT / 'evidence/raw'
command_dir.mkdir(parents=True, exist_ok=True); raw_dir.mkdir(parents=True, exist_ok=True)
(raw_dir / '320-package.stdout.log').write_text(json.dumps({'packageTree': package_manifest['treeSha256']}, indent=2) + '\n', encoding='utf-8')
(raw_dir / '320-package.stderr.log').write_text('', encoding='utf-8')
command_record['stdout_sha256'] = sha256(raw_dir / '320-package.stdout.log')
command_record['stderr_sha256'] = sha256(raw_dir / '320-package.stderr.log')
(command_dir / '320-package.json').write_text(json.dumps(command_record, indent=2) + '\n', encoding='utf-8')
(PACKAGE / 'R7E_RAW_EVIDENCE/commands').mkdir(parents=True, exist_ok=True)
(PACKAGE / 'R7E_RAW_EVIDENCE/raw').mkdir(parents=True, exist_ok=True)
shutil.copy2(command_dir / '320-package.json', PACKAGE / 'R7E_RAW_EVIDENCE/commands/320-package.json')
shutil.copy2(raw_dir / '320-package.stdout.log', PACKAGE / 'R7E_RAW_EVIDENCE/raw/320-package.stdout.log')
shutil.copy2(raw_dir / '320-package.stderr.log', PACKAGE / 'R7E_RAW_EVIDENCE/raw/320-package.stderr.log')
package_manifest = manifest(PACKAGE)
(PACKAGE / 'R7E_PACKAGE_MANIFEST.json').write_text(json.dumps(package_manifest, indent=2) + '\n', encoding='utf-8')

create_zip(PACKAGE, ZIP_PATH)
zip_hash = sha256(ZIP_PATH)
hash_path = ZIP_PATH.with_suffix(ZIP_PATH.suffix + '.sha256')
hash_path.write_text(f'{zip_hash}  {ZIP_PATH.name}\n', encoding='utf-8')
summary = {'zip': str(ZIP_PATH), 'bytes': ZIP_PATH.stat().st_size, 'sha256': zip_hash, 'packageTreeSha256': package_manifest['treeSha256'], 'createdAtUtc': now()}
(OUTPUT / 'R7E_OUTPUT_SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
