import fsp from 'node:fs/promises';
import { exists, readJson, treeManifest, writeJson } from './lib.mjs';

const errors = [];
const index = await readJson('R7E_EVIDENCE_INDEX.json');
const unacceptable = index.gates.filter((gate) => ['OBSERVED_FAILURE', 'NOT_VERIFIED'].includes(gate.producerObservation));
for (const gate of unacceptable) errors.push(`${gate.id}: ${gate.producerObservation}`);

for (const required of ['package-lock.json', 'dist', 'dist-scale', 'evidence/reproducibility/report.json', 'evidence/reports/scale-verification.json', 'evidence/reports/dist-verification.json', 'evidence/reports/official-source-verification.json']) {
  if (!(await exists(required))) errors.push(`missing required artifact: ${required}`);
}

let reproducibility = null;
if (await exists('evidence/reproducibility/report.json')) {
  reproducibility = await readJson('evidence/reproducibility/report.json');
  if (reproducibility.equal !== true) errors.push('reproducibility.equal is not true');
  if (!reproducibility.cleanRun1 || !reproducibility.cleanRun2) errors.push('clean-run-1/clean-run-2 summaries missing');
  if (!Array.isArray(reproducibility.commands) || reproducibility.commands.length !== 4 || reproducibility.commands.some((row) => row.exitCode !== 0)) errors.push('clean-run command set is not four native successes');
  if (reproducibility.cleanRun1?.treeSha256 !== reproducibility.cleanRun2?.treeSha256) errors.push('clean-run output tree hashes differ');
}

let scale = null;
if (await exists('evidence/reports/scale-verification.json')) {
  scale = await readJson('evidence/reports/scale-verification.json');
  if (scale.generatedFixtureCount !== 500) errors.push(`scale fixture count ${scale.generatedFixtureCount}, expected 500`);
  if (scale.generatedDetailPageCount !== 500) errors.push(`scale detail page count ${scale.generatedDetailPageCount}, expected 500`);
  if (Array.isArray(scale.errors) && scale.errors.length) errors.push(`scale verification errors: ${scale.errors.join('; ')}`);
}

let official = null;
if (await exists('evidence/reports/official-source-verification.json')) {
  official = await readJson('evidence/reports/official-source-verification.json');
  if (Array.isArray(official.failures) && official.failures.length) errors.push(`official source failures: ${official.failures.join('; ')}`);
}

let distVerification = null;
if (await exists('evidence/reports/dist-verification.json')) {
  distVerification = await readJson('evidence/reports/dist-verification.json');
  if (Array.isArray(distVerification.errors) && distVerification.errors.length) errors.push(`dist verification errors: ${distVerification.errors.join('; ')}`);
}

const dist = await treeManifest('dist');
const distScale = await treeManifest('dist-scale');
const report = {
  schema: 'davidanderle.r7e.final-producer-gate.v1',
  generatedAtUtc: new Date().toISOString(),
  result: errors.length ? 'FAIL' : 'PASS',
  errors,
  evidenceGateCount: index.gates.length,
  unacceptableEvidenceGates: unacceptable.map((gate) => ({ id: gate.id, producerObservation: gate.producerObservation })),
  packageLockPresent: await exists('package-lock.json'),
  canonicalDist: { files: dist.files, bytes: dist.bytes, treeSha256: dist.treeSha256 },
  scaleDist: { files: distScale.files, bytes: distScale.bytes, treeSha256: distScale.treeSha256 },
  reproducibility,
  scale,
  officialSources: official,
  distVerification,
  authorityBoundary: 'This is the R7E producer completion gate. Independent R7F verification remains required for release certification.'
};
await writeJson('R7E_FINAL_GATE.json', report);
await writeJson('evidence/reports/R7E_FINAL_GATE.json', report);
if (errors.length) {
  console.error(JSON.stringify(report, null, 2));
  process.exit(2);
}
console.log(JSON.stringify(report, null, 2));
