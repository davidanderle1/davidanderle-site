import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { ensureDir, isoNow, writeJson } from './lib.mjs';

const out = path.resolve('evidence/wrangler-preview');
await ensureDir(out);
const stdout = await fsp.open(path.join(out, 'stdout.log'), 'w');
const stderr = await fsp.open(path.join(out, 'stderr.log'), 'w');
const command = [path.resolve('node_modules/.bin/wrangler'), 'dev', '--local', '--port', '8787'];
const started = isoNow();
const child = spawn(command[0], command.slice(1), { stdio: ['ignore', stdout.fd, stderr.fd] });
const observations = [];
const errors = [];
try {
  let ready = false;
  for (let i = 0; i < 120; i += 1) {
    try { const response = await fetch('http://127.0.0.1:8787/'); if (response.status === 200) { ready = true; break; } } catch {}
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  if (!ready) throw new Error('wrangler local preview did not become ready');
  for (const [id, url, redirect] of [
    ['home', 'http://127.0.0.1:8787/', 'follow'],
    ['custom-404', 'http://127.0.0.1:8787/r7e-route-that-does-not-exist', 'manual'],
    ['legacy-redirect', 'http://127.0.0.1:8787/projects', 'manual']
  ]) {
    const response = await fetch(url, { redirect });
    const body = await response.text();
    const row = { id, url, status: response.status, location: response.headers.get('location'), contentSecurityPolicy: response.headers.get('content-security-policy'), xContentTypeOptions: response.headers.get('x-content-type-options'), bodyContainsCustom404: body.includes('data-custom-404="bearing"') };
    observations.push(row);
  }
  const home = observations.find((x) => x.id === 'home');
  const missing = observations.find((x) => x.id === 'custom-404');
  const redirect = observations.find((x) => x.id === 'legacy-redirect');
  if (home?.status !== 200) errors.push(`home status ${home?.status}`);
  if (!home?.contentSecurityPolicy) errors.push('CSP response header absent');
  if (missing?.status !== 404 || !missing.bodyContainsCustom404) errors.push('custom 404 behavior not observed');
  if (![301, 302, 307, 308].includes(redirect?.status)) errors.push(`legacy redirect status ${redirect?.status}`);
} finally {
  child.kill('SIGTERM');
  await stdout.close(); await stderr.close();
}
const report = { schema: 'davidanderle.r7e.wrangler-preview.v1', command, startTimestampUtc: started, endTimestampUtc: isoNow(), observations, errors };
await writeJson(path.join(out, 'report.json'), report);
if (errors.length) { console.error(errors.join('\n')); process.exit(2); }
console.log(JSON.stringify(report, null, 2));
