import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { ensureDir, isoNow, treeManifest, writeJson } from './lib.mjs';

const out = path.resolve('evidence/reproducibility');
const workRoot = path.resolve('../r7e-reproducibility-work');
await fsp.rm(workRoot, { recursive: true, force: true });
await ensureDir(workRoot);

async function copySource(destination) {
  await fsp.cp(process.cwd(), destination, {
    recursive: true,
    filter: (source) => {
      const rel = path.relative(process.cwd(), source);
      const first = rel.split(path.sep)[0];
      return !['node_modules', 'evidence', 'dist', 'dist-scale', 'R7E_PACKAGE', 'R7E_OUTPUT', '.astro'].includes(first);
    }
  });
  await fsp.mkdir(path.join(destination, 'src/content/scale'), { recursive: true });
  for (const file of await fsp.readdir(path.join(destination, 'src/content/scale'))) if (file.endsWith('.md')) await fsp.rm(path.join(destination, 'src/content/scale', file));
}

async function run(id, cwd, command, env = {}) {
  const stdoutPath = path.join(out, `${id}.stdout.log`);
  const stderrPath = path.join(out, `${id}.stderr.log`);
  const stdout = await fsp.open(stdoutPath, 'w');
  const stderr = await fsp.open(stderrPath, 'w');
  const started = isoNow();
  const code = await new Promise((resolve) => {
    const child = spawn(command[0], command.slice(1), { cwd, env: { ...process.env, ...env }, stdio: ['ignore', stdout.fd, stderr.fd] });
    child.on('close', resolve);
  });
  await stdout.close(); await stderr.close();
  return { id, command, cwd, startTimestampUtc: started, endTimestampUtc: isoNow(), exitCode: code, stdoutPath, stderrPath };
}

const a = path.join(workRoot, 'a');
const b = path.join(workRoot, 'b');
await copySource(a); await copySource(b);
const commands = [];
for (const [label, cwd] of [['a', a], ['b', b]]) {
  commands.push(await run(`${label}-npm-ci`, cwd, ['npm', 'ci']));
  if (commands.at(-1).exitCode !== 0) break;
  commands.push(await run(`${label}-build`, cwd, ['npm', 'run', 'build'], { SOURCE_DATE_EPOCH: '1787961600', TZ: 'UTC' }));
  if (commands.at(-1).exitCode !== 0) break;
}
let manifestA = null; let manifestB = null; let equal = false; let differences = [];
if (commands.every((x) => x.exitCode === 0) && commands.length === 4) {
  manifestA = await treeManifest(path.join(a, 'dist'));
  manifestB = await treeManifest(path.join(b, 'dist'));
  equal = manifestA.treeSha256 === manifestB.treeSha256;
  if (!equal) {
    const left = new Map(manifestA.manifest.map((x) => [x.path, x.sha256]));
    const right = new Map(manifestB.manifest.map((x) => [x.path, x.sha256]));
    for (const key of [...new Set([...left.keys(), ...right.keys()])].sort()) if (left.get(key) !== right.get(key)) differences.push({ path: key, a: left.get(key), b: right.get(key) });
  }
}
const report = { schema: 'davidanderle.r7e.reproducibility.v1', commands, buildA: manifestA && { files: manifestA.files, bytes: manifestA.bytes, treeSha256: manifestA.treeSha256 }, buildB: manifestB && { files: manifestB.files, bytes: manifestB.bytes, treeSha256: manifestB.treeSha256 }, equal, differences };
await writeJson(path.join(out, 'report.json'), report);
await fsp.rm(workRoot, { recursive: true, force: true });
if (!equal) { console.error(JSON.stringify(report, null, 2)); process.exit(2); }
console.log(JSON.stringify(report, null, 2));
