import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { chromium } from '@playwright/test';
import { ensureDir, isoNow, writeJson } from './lib.mjs';

const out = path.resolve('evidence/lighthouse');
await ensureDir(out);
const serverOut = await fsp.open(path.join(out, 'server.stdout.log'), 'w');
const serverErr = await fsp.open(path.join(out, 'server.stderr.log'), 'w');
const server = spawn('python3', ['-m', 'http.server', '4321', '--bind', '127.0.0.1', '--directory', 'dist'], { stdio: ['ignore', serverOut.fd, serverErr.fd] });
async function waitForServer() {
  for (let i = 0; i < 80; i += 1) {
    try { const response = await fetch('http://127.0.0.1:4321/'); if (response.ok) return; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error('static server did not become ready');
}
async function runOne(id, url, extra) {
  const reportPath = path.join(out, `${id}.report.json`);
  const stdoutPath = path.join(out, `${id}.stdout.log`);
  const stderrPath = path.join(out, `${id}.stderr.log`);
  const args = [
    'node_modules/lighthouse/cli/index.js', url,
    '--quiet', '--output=json', `--output-path=${reportPath}`,
    '--only-categories=performance,accessibility,best-practices,seo',
    `--chrome-path=${chromium.executablePath()}`,
    '--chrome-flags=--headless=new --no-sandbox --disable-dev-shm-usage',
    ...extra
  ];
  const started = isoNow();
  const stdout = await fsp.open(stdoutPath, 'w');
  const stderr = await fsp.open(stderrPath, 'w');
  const code = await new Promise((resolve) => {
    const child = spawn(process.execPath, args, { stdio: ['ignore', stdout.fd, stderr.fd] });
    child.on('close', resolve);
  });
  await stdout.close(); await stderr.close();
  return { id, url, command: [process.execPath, ...args], startTimestampUtc: started, endTimestampUtc: isoNow(), exitCode: code, reportPath };
}
let commands = [];
try {
  await waitForServer();
  commands.push(await runOne('home-desktop', 'http://127.0.0.1:4321/', ['--form-factor=desktop', '--screenEmulation.mobile=false', '--throttling-method=provided']));
  commands.push(await runOne('project-mobile', 'http://127.0.0.1:4321/work/non-core-real-estate/', []));
} finally {
  server.kill('SIGTERM');
  await serverOut.close(); await serverErr.close();
}
const summaries = [];
for (const command of commands) {
  if (command.exitCode !== 0) continue;
  const report = JSON.parse(await fsp.readFile(command.reportPath, 'utf8'));
  summaries.push({
    id: command.id,
    requestedUrl: report.requestedUrl,
    finalUrl: report.finalUrl,
    fetchTime: report.fetchTime,
    lighthouseVersion: report.lighthouseVersion,
    categories: Object.fromEntries(Object.entries(report.categories).map(([key, value]) => [key, Math.round((value.score || 0) * 100)])),
    metrics: {
      firstContentfulPaintMs: report.audits['first-contentful-paint']?.numericValue,
      largestContentfulPaintMs: report.audits['largest-contentful-paint']?.numericValue,
      totalBlockingTimeMs: report.audits['total-blocking-time']?.numericValue,
      cumulativeLayoutShift: report.audits['cumulative-layout-shift']?.numericValue,
      speedIndexMs: report.audits['speed-index']?.numericValue
    }
  });
}
await writeJson(path.join(out, 'commands.json'), { commands });
await writeJson(path.join(out, 'summary.json'), { schema: 'davidanderle.r7e.lighthouse-measurement.v1', summaries });
const failed = commands.filter((x) => x.exitCode !== 0);
if (failed.length) throw new Error(`Lighthouse command failures: ${failed.map((x) => x.id).join(', ')}`);
console.log(JSON.stringify(summaries, null, 2));
