import fs from 'node:fs';
import fsp from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';

export async function exists(target) {
  try { await fsp.access(target); return true; } catch { return false; }
}

export async function ensureDir(target) { await fsp.mkdir(target, { recursive: true }); }

export async function readJson(target) { return JSON.parse(await fsp.readFile(target, 'utf8')); }

export async function writeJson(target, value) {
  await ensureDir(path.dirname(target));
  await fsp.writeFile(target, JSON.stringify(value, null, 2) + '\n', 'utf8');
}

export function sha256Buffer(buffer) { return crypto.createHash('sha256').update(buffer).digest('hex'); }

export async function sha256File(target) {
  const hash = crypto.createHash('sha256');
  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(target);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', resolve);
  });
  return hash.digest('hex');
}

export async function walk(root, options = {}) {
  const excluded = new Set(options.excludeNames || []);
  const rows = [];
  if (!(await exists(root))) return rows;
  async function visit(current) {
    const entries = await fsp.readdir(current, { withFileTypes: true });
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (excluded.has(entry.name)) continue;
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) await visit(full);
      else if (entry.isFile()) rows.push(full);
    }
  }
  await visit(root);
  return rows;
}

export async function treeManifest(root) {
  const rows = [];
  for (const file of await walk(root, { excludeNames: ['.DS_Store'] })) {
    const stat = await fsp.stat(file);
    rows.push({ path: path.relative(root, file).split(path.sep).join('/'), bytes: stat.size, sha256: await sha256File(file) });
  }
  const canonical = JSON.stringify(rows);
  return { files: rows.length, bytes: rows.reduce((sum, row) => sum + row.bytes, 0), treeSha256: sha256Buffer(Buffer.from(canonical)), manifest: rows };
}

export function isoNow() { return new Date().toISOString(); }

export function toPosix(value) { return value.split(path.sep).join('/'); }
