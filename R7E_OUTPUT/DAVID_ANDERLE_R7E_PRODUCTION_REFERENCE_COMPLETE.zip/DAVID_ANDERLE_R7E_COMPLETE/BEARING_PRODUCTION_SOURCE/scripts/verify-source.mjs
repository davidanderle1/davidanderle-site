import fsp from 'node:fs/promises';
import path from 'node:path';
import { walk, readJson, writeJson } from './lib.mjs';

const errors = [];
const observations = [];
const packageJson = await readJson('package.json');
const dependencies = { ...(packageJson.dependencies || {}), ...(packageJson.devDependencies || {}) };
const exactVersion = /^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$/;
for (const [name, version] of Object.entries(dependencies)) {
  if (version === 'latest' || !exactVersion.test(version)) errors.push(`${name} is not pinned to an exact version: ${version}`);
}
for (const forbidden of ['react', 'react-dom', 'vue', 'svelte', '@astrojs/react', '@astrojs/vue', '@astrojs/svelte']) if (dependencies[forbidden]) errors.push(`forbidden framework dependency present: ${forbidden}`);

const sourceFiles = await walk('src');
const textFiles = sourceFiles.filter((file) => /\.(astro|ts|js|mjs|css|md|json)$/.test(file));
let customElementDefinitions = 0;
let executableScriptBlocks = 0;
for (const file of textFiles) {
  const content = await fsp.readFile(file, 'utf8');
  if (/client:(load|idle|visible|media|only)/.test(content)) errors.push(`${file}: hydration directive present`);
  customElementDefinitions += (content.match(/customElements\.define\s*\(/g) || []).length;
  if (file.endsWith('.astro')) executableScriptBlocks += (content.match(/<script(?:\s|>)/g) || []).length;
}
if (customElementDefinitions !== 1) errors.push(`expected one customElements.define call, observed ${customElementDefinitions}`);
if (executableScriptBlocks !== 1) errors.push(`expected one Astro script block, observed ${executableScriptBlocks}`);

const astroConfig = await fsp.readFile('astro.config.mjs', 'utf8');
if (!/output:\s*['"]static['"]/.test(astroConfig)) errors.push('Astro output is not explicitly static');
const css = await fsp.readFile('src/styles/global.css', 'utf8');
if (!css.includes('@media (max-width: 410px) and (min-width: 351px)')) errors.push('dedicated 390 px composition missing');
if (!css.includes('@media (max-width: 350px)')) errors.push('dedicated 320 px composition missing');
if (/tailwind|bootstrap|bulma/i.test(css)) errors.push('third-party CSS framework marker present');

const wrangler = await fsp.readFile('wrangler.jsonc', 'utf8');
if (!/"assets"\s*:/.test(wrangler)) errors.push('Wrangler assets configuration missing');
if (/"main"\s*:/.test(wrangler)) errors.push('Wrangler Worker main script present in assets-only reference');
if (!/"not_found_handling"\s*:\s*"404-page"/.test(wrangler)) errors.push('custom 404 handling not configured');

const required = ['public/_headers', 'public/_redirects', 'src/pages/404.astro', 'src/pages/about/no-photo.astro', 'src/pages/visual-comparison.astro', 'src/content.config.ts'];
for (const file of required) {
  try { await fsp.access(file); } catch { errors.push(`required source missing: ${file}`); }
}
const home = await fsp.readFile('src/pages/index.astro', 'utf8');
if (home.indexOf('id="selected-evidence"') > home.indexOf('id="trajectory"')) errors.push('homepage puts trajectory before concrete work evidence');
const education = await readJson('src/content/data/education.json');
const madison = education.find((x) => x.id === 'uw-madison-exchange');
if (!madison || madison.prominence !== 'secondary') errors.push('Madison secondary prominence invariant missing');

observations.push({ exactPinnedDependencies: Object.keys(dependencies).length, customElementDefinitions, executableScriptBlocks, sourceFiles: sourceFiles.length });
const report = { schema: 'davidanderle.r7e.source-verification.v1', errors, observations };
await writeJson('evidence/reports/source-verification.json', report);
if (errors.length) { console.error(errors.join('\n')); process.exit(2); }
console.log(JSON.stringify(report, null, 2));
