---
title: Scale record 0281
slug: scale-0281
year: 2017
sequence: 281
material: oxide
summary: Deterministic generated record 281 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 281.
