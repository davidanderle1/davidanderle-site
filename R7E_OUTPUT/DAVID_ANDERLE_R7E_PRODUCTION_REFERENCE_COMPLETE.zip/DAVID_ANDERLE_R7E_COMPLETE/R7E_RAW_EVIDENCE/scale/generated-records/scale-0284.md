---
title: Scale record 0284
slug: scale-0284
year: 2020
sequence: 284
material: oxide
summary: Deterministic generated record 284 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 284.
