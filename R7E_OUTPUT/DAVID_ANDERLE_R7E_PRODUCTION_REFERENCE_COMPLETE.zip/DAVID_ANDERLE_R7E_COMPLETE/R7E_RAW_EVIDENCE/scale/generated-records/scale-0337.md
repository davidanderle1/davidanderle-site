---
title: Scale record 0337
slug: scale-0337
year: 2023
sequence: 337
material: graphite
summary: Deterministic generated record 337 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 337.
