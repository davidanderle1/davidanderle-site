---
title: Scale record 0071
slug: scale-0071
year: 2017
sequence: 71
material: oxide
summary: Deterministic generated record 71 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 71.
