---
title: Scale record 0360
slug: scale-0360
year: 2026
sequence: 360
material: paper
summary: Deterministic generated record 360 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 360.
