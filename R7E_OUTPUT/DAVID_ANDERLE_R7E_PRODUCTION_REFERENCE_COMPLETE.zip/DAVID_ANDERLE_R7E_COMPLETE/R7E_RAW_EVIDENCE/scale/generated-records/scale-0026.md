---
title: Scale record 0026
slug: scale-0026
year: 2022
sequence: 26
material: oxide
summary: Deterministic generated record 26 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 26.
