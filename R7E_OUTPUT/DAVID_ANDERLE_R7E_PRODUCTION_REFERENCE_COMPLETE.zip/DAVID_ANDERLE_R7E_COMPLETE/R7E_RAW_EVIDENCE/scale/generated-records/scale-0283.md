---
title: Scale record 0283
slug: scale-0283
year: 2019
sequence: 283
material: graphite
summary: Deterministic generated record 283 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 283.
