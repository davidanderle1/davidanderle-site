---
title: Scale record 0402
slug: scale-0402
year: 2018
sequence: 402
material: paper
summary: Deterministic generated record 402 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 402.
