---
title: Scale record 0368
slug: scale-0368
year: 2024
sequence: 368
material: oxide
summary: Deterministic generated record 368 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 368.
