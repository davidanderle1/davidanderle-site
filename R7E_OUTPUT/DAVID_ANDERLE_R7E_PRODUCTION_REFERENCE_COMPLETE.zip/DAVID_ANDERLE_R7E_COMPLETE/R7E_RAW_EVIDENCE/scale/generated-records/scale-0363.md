---
title: Scale record 0363
slug: scale-0363
year: 2019
sequence: 363
material: paper
summary: Deterministic generated record 363 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 363.
