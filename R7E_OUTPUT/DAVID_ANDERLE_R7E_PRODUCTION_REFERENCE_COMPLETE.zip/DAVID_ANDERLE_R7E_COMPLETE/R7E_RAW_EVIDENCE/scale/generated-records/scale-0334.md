---
title: Scale record 0334
slug: scale-0334
year: 2020
sequence: 334
material: graphite
summary: Deterministic generated record 334 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 334.
