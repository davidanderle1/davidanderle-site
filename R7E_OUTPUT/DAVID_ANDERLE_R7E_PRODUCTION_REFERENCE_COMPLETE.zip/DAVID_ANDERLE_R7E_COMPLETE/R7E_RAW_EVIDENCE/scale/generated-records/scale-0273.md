---
title: Scale record 0273
slug: scale-0273
year: 2019
sequence: 273
material: paper
summary: Deterministic generated record 273 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 273.
