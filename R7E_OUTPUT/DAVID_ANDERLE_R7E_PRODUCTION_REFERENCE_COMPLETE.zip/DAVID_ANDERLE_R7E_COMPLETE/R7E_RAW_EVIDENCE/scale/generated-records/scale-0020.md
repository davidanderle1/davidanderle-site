---
title: Scale record 0020
slug: scale-0020
year: 2026
sequence: 20
material: oxide
summary: Deterministic generated record 20 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 20.
