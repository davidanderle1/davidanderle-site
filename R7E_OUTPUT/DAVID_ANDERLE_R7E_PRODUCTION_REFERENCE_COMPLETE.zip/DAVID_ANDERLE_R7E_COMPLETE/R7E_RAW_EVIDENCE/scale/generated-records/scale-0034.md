---
title: Scale record 0034
slug: scale-0034
year: 2020
sequence: 34
material: graphite
summary: Deterministic generated record 34 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 34.
