---
title: Scale record 0204
slug: scale-0204
year: 2020
sequence: 204
material: paper
summary: Deterministic generated record 204 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 204.
