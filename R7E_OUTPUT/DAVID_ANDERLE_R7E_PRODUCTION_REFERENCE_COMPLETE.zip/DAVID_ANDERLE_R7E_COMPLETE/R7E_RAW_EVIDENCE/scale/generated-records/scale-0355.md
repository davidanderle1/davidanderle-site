---
title: Scale record 0355
slug: scale-0355
year: 2021
sequence: 355
material: graphite
summary: Deterministic generated record 355 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 355.
