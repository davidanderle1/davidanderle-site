---
title: Scale record 0354
slug: scale-0354
year: 2020
sequence: 354
material: paper
summary: Deterministic generated record 354 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 354.
