---
title: Scale record 0353
slug: scale-0353
year: 2019
sequence: 353
material: oxide
summary: Deterministic generated record 353 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 353.
