---
title: Scale record 0083
slug: scale-0083
year: 2019
sequence: 83
material: oxide
summary: Deterministic generated record 83 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 83.
