---
title: Scale record 0033
slug: scale-0033
year: 2019
sequence: 33
material: paper
summary: Deterministic generated record 33 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 33.
