---
title: Scale record 0433
slug: scale-0433
year: 2019
sequence: 433
material: graphite
summary: Deterministic generated record 433 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 433.
