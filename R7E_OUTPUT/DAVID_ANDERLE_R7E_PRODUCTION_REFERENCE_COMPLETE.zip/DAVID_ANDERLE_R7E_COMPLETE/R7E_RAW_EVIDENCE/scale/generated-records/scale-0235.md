---
title: Scale record 0235
slug: scale-0235
year: 2021
sequence: 235
material: graphite
summary: Deterministic generated record 235 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 235.
