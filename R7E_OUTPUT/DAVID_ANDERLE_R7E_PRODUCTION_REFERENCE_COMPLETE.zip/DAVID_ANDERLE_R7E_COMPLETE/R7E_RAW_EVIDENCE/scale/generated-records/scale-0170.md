---
title: Scale record 0170
slug: scale-0170
year: 2026
sequence: 170
material: oxide
summary: Deterministic generated record 170 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 170.
