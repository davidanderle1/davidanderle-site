---
title: Scale record 0366
slug: scale-0366
year: 2022
sequence: 366
material: paper
summary: Deterministic generated record 366 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 366.
