---
title: Scale record 0237
slug: scale-0237
year: 2023
sequence: 237
material: paper
summary: Deterministic generated record 237 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 237.
