---
title: Scale record 0175
slug: scale-0175
year: 2021
sequence: 175
material: graphite
summary: Deterministic generated record 175 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 175.
