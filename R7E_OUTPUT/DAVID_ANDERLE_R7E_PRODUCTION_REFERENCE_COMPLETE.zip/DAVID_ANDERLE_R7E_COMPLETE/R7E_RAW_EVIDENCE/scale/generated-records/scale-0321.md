---
title: Scale record 0321
slug: scale-0321
year: 2017
sequence: 321
material: paper
summary: Deterministic generated record 321 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 321.
