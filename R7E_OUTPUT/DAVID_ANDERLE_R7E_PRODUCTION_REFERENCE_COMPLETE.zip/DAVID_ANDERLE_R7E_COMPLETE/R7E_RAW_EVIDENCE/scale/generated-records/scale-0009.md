---
title: Scale record 0009
slug: scale-0009
year: 2025
sequence: 9
material: paper
summary: Deterministic generated record 9 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 9.
