---
title: Scale record 0114
slug: scale-0114
year: 2020
sequence: 114
material: paper
summary: Deterministic generated record 114 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 114.
