---
title: Scale record 0025
slug: scale-0025
year: 2021
sequence: 25
material: graphite
summary: Deterministic generated record 25 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 25.
