---
title: Scale record 0301
slug: scale-0301
year: 2017
sequence: 301
material: graphite
summary: Deterministic generated record 301 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 301.
