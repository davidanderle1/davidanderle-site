---
title: Scale record 0327
slug: scale-0327
year: 2023
sequence: 327
material: paper
summary: Deterministic generated record 327 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 327.
