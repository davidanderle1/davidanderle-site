---
title: Scale record 0097
slug: scale-0097
year: 2023
sequence: 97
material: graphite
summary: Deterministic generated record 97 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 97.
