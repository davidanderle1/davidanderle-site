---
title: Scale record 0423
slug: scale-0423
year: 2019
sequence: 423
material: paper
summary: Deterministic generated record 423 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 423.
