---
title: Scale record 0393
slug: scale-0393
year: 2019
sequence: 393
material: paper
summary: Deterministic generated record 393 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 393.
