---
title: Scale record 0264
slug: scale-0264
year: 2020
sequence: 264
material: paper
summary: Deterministic generated record 264 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 264.
