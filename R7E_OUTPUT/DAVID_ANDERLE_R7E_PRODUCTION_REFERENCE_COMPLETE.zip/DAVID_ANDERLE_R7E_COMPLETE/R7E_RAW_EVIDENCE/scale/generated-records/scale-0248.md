---
title: Scale record 0248
slug: scale-0248
year: 2024
sequence: 248
material: oxide
summary: Deterministic generated record 248 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 248.
