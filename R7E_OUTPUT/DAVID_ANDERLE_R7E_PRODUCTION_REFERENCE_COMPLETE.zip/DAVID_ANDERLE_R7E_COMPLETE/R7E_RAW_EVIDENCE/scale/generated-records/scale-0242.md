---
title: Scale record 0242
slug: scale-0242
year: 2018
sequence: 242
material: oxide
summary: Deterministic generated record 242 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 242.
