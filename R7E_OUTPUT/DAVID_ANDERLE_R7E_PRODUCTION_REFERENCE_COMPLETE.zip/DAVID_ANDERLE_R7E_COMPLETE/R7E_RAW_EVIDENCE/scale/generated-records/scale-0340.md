---
title: Scale record 0340
slug: scale-0340
year: 2026
sequence: 340
material: graphite
summary: Deterministic generated record 340 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 340.
