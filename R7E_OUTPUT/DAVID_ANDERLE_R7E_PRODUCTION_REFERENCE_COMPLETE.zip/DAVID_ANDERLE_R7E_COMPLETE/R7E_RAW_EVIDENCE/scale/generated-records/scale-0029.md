---
title: Scale record 0029
slug: scale-0029
year: 2025
sequence: 29
material: oxide
summary: Deterministic generated record 29 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 29.
