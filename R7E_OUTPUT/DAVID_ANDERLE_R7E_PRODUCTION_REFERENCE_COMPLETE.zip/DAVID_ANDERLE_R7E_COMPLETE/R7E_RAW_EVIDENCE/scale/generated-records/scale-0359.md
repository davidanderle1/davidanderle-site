---
title: Scale record 0359
slug: scale-0359
year: 2025
sequence: 359
material: oxide
summary: Deterministic generated record 359 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 359.
