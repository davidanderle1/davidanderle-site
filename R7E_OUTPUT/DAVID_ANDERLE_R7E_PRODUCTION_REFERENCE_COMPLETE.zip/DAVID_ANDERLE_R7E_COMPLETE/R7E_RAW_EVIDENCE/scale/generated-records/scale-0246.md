---
title: Scale record 0246
slug: scale-0246
year: 2022
sequence: 246
material: paper
summary: Deterministic generated record 246 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 246.
