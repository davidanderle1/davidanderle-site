---
title: Scale record 0211
slug: scale-0211
year: 2017
sequence: 211
material: graphite
summary: Deterministic generated record 211 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 211.
