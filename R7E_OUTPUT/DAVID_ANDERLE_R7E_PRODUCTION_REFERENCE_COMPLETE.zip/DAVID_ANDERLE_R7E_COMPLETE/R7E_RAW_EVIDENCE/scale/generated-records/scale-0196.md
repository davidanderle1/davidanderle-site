---
title: Scale record 0196
slug: scale-0196
year: 2022
sequence: 196
material: graphite
summary: Deterministic generated record 196 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 196.
