---
title: Scale record 0203
slug: scale-0203
year: 2019
sequence: 203
material: oxide
summary: Deterministic generated record 203 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 203.
