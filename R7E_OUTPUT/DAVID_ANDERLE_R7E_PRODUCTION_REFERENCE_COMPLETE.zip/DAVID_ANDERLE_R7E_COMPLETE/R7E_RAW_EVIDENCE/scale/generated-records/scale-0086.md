---
title: Scale record 0086
slug: scale-0086
year: 2022
sequence: 86
material: oxide
summary: Deterministic generated record 86 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 86.
