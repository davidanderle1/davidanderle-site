---
title: Scale record 0085
slug: scale-0085
year: 2021
sequence: 85
material: graphite
summary: Deterministic generated record 85 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 85.
