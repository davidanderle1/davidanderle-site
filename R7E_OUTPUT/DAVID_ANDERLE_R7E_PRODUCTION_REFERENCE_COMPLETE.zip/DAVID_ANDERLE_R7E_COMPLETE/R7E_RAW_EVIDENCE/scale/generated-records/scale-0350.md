---
title: Scale record 0350
slug: scale-0350
year: 2026
sequence: 350
material: oxide
summary: Deterministic generated record 350 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 350.
