---
title: Scale record 0429
slug: scale-0429
year: 2025
sequence: 429
material: paper
summary: Deterministic generated record 429 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 429.
