---
title: Scale record 0167
slug: scale-0167
year: 2023
sequence: 167
material: oxide
summary: Deterministic generated record 167 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 167.
