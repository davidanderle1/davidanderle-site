---
title: Scale record 0417
slug: scale-0417
year: 2023
sequence: 417
material: paper
summary: Deterministic generated record 417 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 417.
