---
title: Scale record 0346
slug: scale-0346
year: 2022
sequence: 346
material: graphite
summary: Deterministic generated record 346 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 346.
