---
title: Scale record 0090
slug: scale-0090
year: 2026
sequence: 90
material: paper
summary: Deterministic generated record 90 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 90.
