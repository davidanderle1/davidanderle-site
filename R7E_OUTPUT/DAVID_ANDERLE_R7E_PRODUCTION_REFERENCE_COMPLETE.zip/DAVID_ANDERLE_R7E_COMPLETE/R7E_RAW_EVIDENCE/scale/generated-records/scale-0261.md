---
title: Scale record 0261
slug: scale-0261
year: 2017
sequence: 261
material: paper
summary: Deterministic generated record 261 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 261.
