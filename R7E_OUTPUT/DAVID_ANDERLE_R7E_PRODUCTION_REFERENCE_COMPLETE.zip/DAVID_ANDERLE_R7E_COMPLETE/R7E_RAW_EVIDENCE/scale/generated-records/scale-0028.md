---
title: Scale record 0028
slug: scale-0028
year: 2024
sequence: 28
material: graphite
summary: Deterministic generated record 28 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 28.
