---
title: Scale record 0262
slug: scale-0262
year: 2018
sequence: 262
material: graphite
summary: Deterministic generated record 262 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 262.
