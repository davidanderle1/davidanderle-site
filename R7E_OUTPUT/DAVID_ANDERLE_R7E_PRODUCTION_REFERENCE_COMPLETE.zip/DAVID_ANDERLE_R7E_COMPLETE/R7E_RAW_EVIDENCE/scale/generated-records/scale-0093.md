---
title: Scale record 0093
slug: scale-0093
year: 2019
sequence: 93
material: paper
summary: Deterministic generated record 93 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 93.
