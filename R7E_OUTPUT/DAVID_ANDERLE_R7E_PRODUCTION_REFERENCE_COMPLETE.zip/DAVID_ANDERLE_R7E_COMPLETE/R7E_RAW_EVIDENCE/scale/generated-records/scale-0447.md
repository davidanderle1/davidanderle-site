---
title: Scale record 0447
slug: scale-0447
year: 2023
sequence: 447
material: paper
summary: Deterministic generated record 447 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 447.
