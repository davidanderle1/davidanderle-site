---
title: Scale record 0396
slug: scale-0396
year: 2022
sequence: 396
material: paper
summary: Deterministic generated record 396 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 396.
