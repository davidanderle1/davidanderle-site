---
title: Scale record 0118
slug: scale-0118
year: 2024
sequence: 118
material: graphite
summary: Deterministic generated record 118 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 118.
