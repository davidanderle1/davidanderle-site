---
title: Scale record 0229
slug: scale-0229
year: 2025
sequence: 229
material: graphite
summary: Deterministic generated record 229 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 229.
