---
title: Scale record 0005
slug: scale-0005
year: 2021
sequence: 5
material: oxide
summary: Deterministic generated record 5 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 5.
