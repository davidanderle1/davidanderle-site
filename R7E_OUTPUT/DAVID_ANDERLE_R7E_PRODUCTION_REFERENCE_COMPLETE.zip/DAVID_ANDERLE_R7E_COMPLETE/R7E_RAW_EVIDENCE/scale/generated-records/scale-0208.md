---
title: Scale record 0208
slug: scale-0208
year: 2024
sequence: 208
material: graphite
summary: Deterministic generated record 208 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 208.
