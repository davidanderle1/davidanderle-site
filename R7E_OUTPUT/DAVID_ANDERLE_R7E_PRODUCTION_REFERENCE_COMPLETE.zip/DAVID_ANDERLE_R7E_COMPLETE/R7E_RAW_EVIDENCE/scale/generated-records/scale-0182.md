---
title: Scale record 0182
slug: scale-0182
year: 2018
sequence: 182
material: oxide
summary: Deterministic generated record 182 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 182.
