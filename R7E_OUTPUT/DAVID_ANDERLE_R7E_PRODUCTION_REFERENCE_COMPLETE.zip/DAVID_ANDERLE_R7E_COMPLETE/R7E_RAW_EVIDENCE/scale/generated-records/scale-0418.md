---
title: Scale record 0418
slug: scale-0418
year: 2024
sequence: 418
material: graphite
summary: Deterministic generated record 418 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 418.
