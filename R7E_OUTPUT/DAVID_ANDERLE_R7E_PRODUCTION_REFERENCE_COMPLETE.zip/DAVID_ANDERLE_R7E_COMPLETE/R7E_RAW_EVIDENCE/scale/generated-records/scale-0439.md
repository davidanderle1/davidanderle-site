---
title: Scale record 0439
slug: scale-0439
year: 2025
sequence: 439
material: graphite
summary: Deterministic generated record 439 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 439.
