---
title: Scale record 0105
slug: scale-0105
year: 2021
sequence: 105
material: paper
summary: Deterministic generated record 105 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 105.
