---
title: Scale record 0215
slug: scale-0215
year: 2021
sequence: 215
material: oxide
summary: Deterministic generated record 215 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 215.
