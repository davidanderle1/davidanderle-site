---
title: Scale record 0216
slug: scale-0216
year: 2022
sequence: 216
material: paper
summary: Deterministic generated record 216 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 216.
