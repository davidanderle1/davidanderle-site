---
title: Scale record 0107
slug: scale-0107
year: 2023
sequence: 107
material: oxide
summary: Deterministic generated record 107 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 107.
