---
title: Scale record 0367
slug: scale-0367
year: 2023
sequence: 367
material: graphite
summary: Deterministic generated record 367 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 367.
