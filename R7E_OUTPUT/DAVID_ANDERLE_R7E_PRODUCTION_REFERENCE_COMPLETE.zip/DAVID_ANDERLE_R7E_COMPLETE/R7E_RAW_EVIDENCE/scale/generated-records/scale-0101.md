---
title: Scale record 0101
slug: scale-0101
year: 2017
sequence: 101
material: oxide
summary: Deterministic generated record 101 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 101.
