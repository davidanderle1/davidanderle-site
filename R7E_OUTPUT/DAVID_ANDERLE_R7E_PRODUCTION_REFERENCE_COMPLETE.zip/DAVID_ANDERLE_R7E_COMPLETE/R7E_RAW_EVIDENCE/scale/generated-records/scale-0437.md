---
title: Scale record 0437
slug: scale-0437
year: 2023
sequence: 437
material: oxide
summary: Deterministic generated record 437 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 437.
