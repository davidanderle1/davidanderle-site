---
title: Scale record 0291
slug: scale-0291
year: 2017
sequence: 291
material: paper
summary: Deterministic generated record 291 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 291.
