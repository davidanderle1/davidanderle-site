---
title: Scale record 0405
slug: scale-0405
year: 2021
sequence: 405
material: paper
summary: Deterministic generated record 405 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 405.
