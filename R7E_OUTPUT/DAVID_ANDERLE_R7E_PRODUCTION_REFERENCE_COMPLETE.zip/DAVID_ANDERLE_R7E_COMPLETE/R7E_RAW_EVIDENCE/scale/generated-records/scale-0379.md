---
title: Scale record 0379
slug: scale-0379
year: 2025
sequence: 379
material: graphite
summary: Deterministic generated record 379 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 379.
