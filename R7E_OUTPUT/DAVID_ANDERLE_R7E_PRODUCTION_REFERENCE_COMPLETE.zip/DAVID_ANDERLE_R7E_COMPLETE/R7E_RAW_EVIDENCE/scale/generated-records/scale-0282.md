---
title: Scale record 0282
slug: scale-0282
year: 2018
sequence: 282
material: paper
summary: Deterministic generated record 282 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 282.
