---
title: Scale record 0019
slug: scale-0019
year: 2025
sequence: 19
material: graphite
summary: Deterministic generated record 19 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 19.
