---
title: Scale record 0259
slug: scale-0259
year: 2025
sequence: 259
material: graphite
summary: Deterministic generated record 259 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 259.
