---
title: Scale record 0111
slug: scale-0111
year: 2017
sequence: 111
material: paper
summary: Deterministic generated record 111 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 111.
