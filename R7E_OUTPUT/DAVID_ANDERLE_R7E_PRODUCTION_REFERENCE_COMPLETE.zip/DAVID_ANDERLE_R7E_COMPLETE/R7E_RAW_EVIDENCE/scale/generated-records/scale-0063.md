---
title: Scale record 0063
slug: scale-0063
year: 2019
sequence: 63
material: paper
summary: Deterministic generated record 63 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 63.
