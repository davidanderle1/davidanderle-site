---
title: Scale record 0184
slug: scale-0184
year: 2020
sequence: 184
material: graphite
summary: Deterministic generated record 184 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 184.
