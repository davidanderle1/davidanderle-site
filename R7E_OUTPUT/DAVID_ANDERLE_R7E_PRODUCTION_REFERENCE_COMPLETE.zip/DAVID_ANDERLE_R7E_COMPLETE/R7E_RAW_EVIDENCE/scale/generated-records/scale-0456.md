---
title: Scale record 0456
slug: scale-0456
year: 2022
sequence: 456
material: paper
summary: Deterministic generated record 456 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 456.
