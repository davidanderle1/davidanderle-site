---
title: Scale record 0037
slug: scale-0037
year: 2023
sequence: 37
material: graphite
summary: Deterministic generated record 37 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 37.
