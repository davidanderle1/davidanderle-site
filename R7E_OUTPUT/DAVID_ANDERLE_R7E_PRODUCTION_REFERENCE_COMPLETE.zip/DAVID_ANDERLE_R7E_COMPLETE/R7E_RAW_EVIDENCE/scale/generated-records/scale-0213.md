---
title: Scale record 0213
slug: scale-0213
year: 2019
sequence: 213
material: paper
summary: Deterministic generated record 213 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 213.
