---
title: Scale record 0395
slug: scale-0395
year: 2021
sequence: 395
material: oxide
summary: Deterministic generated record 395 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 395.
