---
title: Scale record 0254
slug: scale-0254
year: 2020
sequence: 254
material: oxide
summary: Deterministic generated record 254 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 254.
