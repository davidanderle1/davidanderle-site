---
title: Scale record 0300
slug: scale-0300
year: 2026
sequence: 300
material: paper
summary: Deterministic generated record 300 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 300.
