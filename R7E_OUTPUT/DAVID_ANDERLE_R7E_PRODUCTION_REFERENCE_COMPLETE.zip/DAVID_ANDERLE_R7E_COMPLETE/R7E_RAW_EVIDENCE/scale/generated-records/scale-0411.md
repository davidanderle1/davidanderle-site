---
title: Scale record 0411
slug: scale-0411
year: 2017
sequence: 411
material: paper
summary: Deterministic generated record 411 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 411.
