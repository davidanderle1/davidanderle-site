---
title: Scale record 0218
slug: scale-0218
year: 2024
sequence: 218
material: oxide
summary: Deterministic generated record 218 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 218.
