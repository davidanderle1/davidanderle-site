---
title: Scale record 0390
slug: scale-0390
year: 2026
sequence: 390
material: paper
summary: Deterministic generated record 390 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 390.
