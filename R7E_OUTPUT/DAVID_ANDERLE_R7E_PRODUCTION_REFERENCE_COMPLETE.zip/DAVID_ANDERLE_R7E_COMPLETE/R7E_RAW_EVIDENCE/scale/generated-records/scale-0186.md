---
title: Scale record 0186
slug: scale-0186
year: 2022
sequence: 186
material: paper
summary: Deterministic generated record 186 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 186.
