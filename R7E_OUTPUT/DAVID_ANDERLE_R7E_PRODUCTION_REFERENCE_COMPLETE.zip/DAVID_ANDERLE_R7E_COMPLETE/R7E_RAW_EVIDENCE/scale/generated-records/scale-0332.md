---
title: Scale record 0332
slug: scale-0332
year: 2018
sequence: 332
material: oxide
summary: Deterministic generated record 332 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 332.
