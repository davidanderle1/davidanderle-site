---
title: Scale record 0195
slug: scale-0195
year: 2021
sequence: 195
material: paper
summary: Deterministic generated record 195 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 195.
