---
title: Scale record 0108
slug: scale-0108
year: 2024
sequence: 108
material: paper
summary: Deterministic generated record 108 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 108.
