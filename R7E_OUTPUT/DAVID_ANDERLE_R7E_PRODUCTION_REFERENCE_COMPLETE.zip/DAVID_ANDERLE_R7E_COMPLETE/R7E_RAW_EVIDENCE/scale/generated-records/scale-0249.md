---
title: Scale record 0249
slug: scale-0249
year: 2025
sequence: 249
material: paper
summary: Deterministic generated record 249 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 249.
