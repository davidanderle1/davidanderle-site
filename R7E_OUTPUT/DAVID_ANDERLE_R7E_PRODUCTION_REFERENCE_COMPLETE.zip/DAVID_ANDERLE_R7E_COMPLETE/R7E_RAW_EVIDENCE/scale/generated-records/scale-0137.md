---
title: Scale record 0137
slug: scale-0137
year: 2023
sequence: 137
material: oxide
summary: Deterministic generated record 137 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 137.
