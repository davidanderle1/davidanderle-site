---
title: Scale record 0006
slug: scale-0006
year: 2022
sequence: 6
material: paper
summary: Deterministic generated record 6 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 6.
