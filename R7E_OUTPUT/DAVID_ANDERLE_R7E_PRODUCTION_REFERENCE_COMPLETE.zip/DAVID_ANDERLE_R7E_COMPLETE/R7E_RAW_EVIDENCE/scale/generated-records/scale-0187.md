---
title: Scale record 0187
slug: scale-0187
year: 2023
sequence: 187
material: graphite
summary: Deterministic generated record 187 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 187.
