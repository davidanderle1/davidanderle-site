---
title: Scale record 0445
slug: scale-0445
year: 2021
sequence: 445
material: graphite
summary: Deterministic generated record 445 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 445.
