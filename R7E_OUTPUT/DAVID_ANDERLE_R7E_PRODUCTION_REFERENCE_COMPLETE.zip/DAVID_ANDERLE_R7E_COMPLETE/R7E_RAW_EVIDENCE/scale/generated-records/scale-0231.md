---
title: Scale record 0231
slug: scale-0231
year: 2017
sequence: 231
material: paper
summary: Deterministic generated record 231 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 231.
