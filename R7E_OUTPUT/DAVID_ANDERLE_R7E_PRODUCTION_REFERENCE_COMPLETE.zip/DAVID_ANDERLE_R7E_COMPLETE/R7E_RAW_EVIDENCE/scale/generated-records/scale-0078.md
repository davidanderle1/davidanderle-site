---
title: Scale record 0078
slug: scale-0078
year: 2024
sequence: 78
material: paper
summary: Deterministic generated record 78 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 78.
