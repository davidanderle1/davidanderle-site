---
title: Scale record 0004
slug: scale-0004
year: 2020
sequence: 4
material: graphite
summary: Deterministic generated record 4 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 4.
