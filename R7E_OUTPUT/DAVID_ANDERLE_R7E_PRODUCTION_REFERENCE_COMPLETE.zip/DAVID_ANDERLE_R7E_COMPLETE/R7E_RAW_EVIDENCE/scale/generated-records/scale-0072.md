---
title: Scale record 0072
slug: scale-0072
year: 2018
sequence: 72
material: paper
summary: Deterministic generated record 72 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 72.
