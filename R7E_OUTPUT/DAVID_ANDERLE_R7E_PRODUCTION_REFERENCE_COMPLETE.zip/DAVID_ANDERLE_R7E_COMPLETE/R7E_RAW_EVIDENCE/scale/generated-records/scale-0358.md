---
title: Scale record 0358
slug: scale-0358
year: 2024
sequence: 358
material: graphite
summary: Deterministic generated record 358 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 358.
