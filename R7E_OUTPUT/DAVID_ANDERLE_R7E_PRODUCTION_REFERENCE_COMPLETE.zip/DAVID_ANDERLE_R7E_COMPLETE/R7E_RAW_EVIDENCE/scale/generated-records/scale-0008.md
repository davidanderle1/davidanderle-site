---
title: Scale record 0008
slug: scale-0008
year: 2024
sequence: 8
material: oxide
summary: Deterministic generated record 8 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 8.
