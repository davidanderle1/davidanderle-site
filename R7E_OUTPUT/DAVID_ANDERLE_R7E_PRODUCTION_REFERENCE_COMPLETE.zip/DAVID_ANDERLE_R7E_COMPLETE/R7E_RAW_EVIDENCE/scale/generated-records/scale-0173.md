---
title: Scale record 0173
slug: scale-0173
year: 2019
sequence: 173
material: oxide
summary: Deterministic generated record 173 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 173.
