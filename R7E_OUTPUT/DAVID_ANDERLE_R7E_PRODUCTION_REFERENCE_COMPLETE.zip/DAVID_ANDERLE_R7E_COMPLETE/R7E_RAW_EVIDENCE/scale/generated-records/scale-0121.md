---
title: Scale record 0121
slug: scale-0121
year: 2017
sequence: 121
material: graphite
summary: Deterministic generated record 121 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 121.
