---
title: Scale record 0221
slug: scale-0221
year: 2017
sequence: 221
material: oxide
summary: Deterministic generated record 221 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 221.
