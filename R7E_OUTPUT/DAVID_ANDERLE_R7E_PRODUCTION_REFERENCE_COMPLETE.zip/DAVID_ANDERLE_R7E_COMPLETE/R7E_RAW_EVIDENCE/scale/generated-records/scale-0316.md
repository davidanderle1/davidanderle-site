---
title: Scale record 0316
slug: scale-0316
year: 2022
sequence: 316
material: graphite
summary: Deterministic generated record 316 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 316.
