---
title: Scale record 0450
slug: scale-0450
year: 2026
sequence: 450
material: paper
summary: Deterministic generated record 450 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 450.
