---
title: Scale record 0165
slug: scale-0165
year: 2021
sequence: 165
material: paper
summary: Deterministic generated record 165 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 165.
