---
title: Scale record 0038
slug: scale-0038
year: 2024
sequence: 38
material: oxide
summary: Deterministic generated record 38 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 38.
