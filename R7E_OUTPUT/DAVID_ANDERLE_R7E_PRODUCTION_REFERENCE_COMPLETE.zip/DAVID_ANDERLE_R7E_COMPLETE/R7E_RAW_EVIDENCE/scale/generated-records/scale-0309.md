---
title: Scale record 0309
slug: scale-0309
year: 2025
sequence: 309
material: paper
summary: Deterministic generated record 309 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 309.
