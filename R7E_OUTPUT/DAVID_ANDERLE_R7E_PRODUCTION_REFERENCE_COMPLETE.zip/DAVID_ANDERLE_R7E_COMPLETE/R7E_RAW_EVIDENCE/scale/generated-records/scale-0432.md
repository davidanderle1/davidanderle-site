---
title: Scale record 0432
slug: scale-0432
year: 2018
sequence: 432
material: paper
summary: Deterministic generated record 432 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 432.
