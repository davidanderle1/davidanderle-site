---
title: Scale record 0451
slug: scale-0451
year: 2017
sequence: 451
material: graphite
summary: Deterministic generated record 451 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 451.
