---
title: Scale record 0342
slug: scale-0342
year: 2018
sequence: 342
material: paper
summary: Deterministic generated record 342 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 342.
