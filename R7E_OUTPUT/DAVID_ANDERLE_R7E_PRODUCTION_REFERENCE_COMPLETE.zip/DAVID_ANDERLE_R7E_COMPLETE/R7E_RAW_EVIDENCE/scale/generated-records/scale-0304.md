---
title: Scale record 0304
slug: scale-0304
year: 2020
sequence: 304
material: graphite
summary: Deterministic generated record 304 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 304.
