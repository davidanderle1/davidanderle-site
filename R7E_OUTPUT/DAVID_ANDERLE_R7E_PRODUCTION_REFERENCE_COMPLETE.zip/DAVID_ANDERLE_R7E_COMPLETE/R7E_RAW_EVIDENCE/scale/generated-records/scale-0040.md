---
title: Scale record 0040
slug: scale-0040
year: 2026
sequence: 40
material: graphite
summary: Deterministic generated record 40 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 40.
