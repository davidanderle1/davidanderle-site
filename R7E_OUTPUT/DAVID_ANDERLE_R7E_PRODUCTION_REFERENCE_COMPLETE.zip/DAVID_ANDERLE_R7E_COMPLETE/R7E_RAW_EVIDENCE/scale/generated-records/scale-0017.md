---
title: Scale record 0017
slug: scale-0017
year: 2023
sequence: 17
material: oxide
summary: Deterministic generated record 17 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 17.
