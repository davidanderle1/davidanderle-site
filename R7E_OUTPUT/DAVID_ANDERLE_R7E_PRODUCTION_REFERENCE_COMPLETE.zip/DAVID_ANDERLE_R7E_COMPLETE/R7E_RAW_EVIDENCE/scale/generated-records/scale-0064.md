---
title: Scale record 0064
slug: scale-0064
year: 2020
sequence: 64
material: graphite
summary: Deterministic generated record 64 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 64.
