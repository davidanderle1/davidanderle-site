---
title: Scale record 0267
slug: scale-0267
year: 2023
sequence: 267
material: paper
summary: Deterministic generated record 267 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 267.
