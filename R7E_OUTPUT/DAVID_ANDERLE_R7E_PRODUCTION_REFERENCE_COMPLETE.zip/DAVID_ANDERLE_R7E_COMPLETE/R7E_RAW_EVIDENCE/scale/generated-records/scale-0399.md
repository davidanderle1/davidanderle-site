---
title: Scale record 0399
slug: scale-0399
year: 2025
sequence: 399
material: paper
summary: Deterministic generated record 399 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 399.
