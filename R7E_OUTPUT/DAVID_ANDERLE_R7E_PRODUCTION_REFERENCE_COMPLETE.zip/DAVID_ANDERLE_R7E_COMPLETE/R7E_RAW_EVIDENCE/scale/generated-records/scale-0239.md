---
title: Scale record 0239
slug: scale-0239
year: 2025
sequence: 239
material: oxide
summary: Deterministic generated record 239 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 239.
