---
title: Scale record 0232
slug: scale-0232
year: 2018
sequence: 232
material: graphite
summary: Deterministic generated record 232 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 232.
