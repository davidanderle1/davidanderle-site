---
title: Scale record 0164
slug: scale-0164
year: 2020
sequence: 164
material: oxide
summary: Deterministic generated record 164 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 164.
