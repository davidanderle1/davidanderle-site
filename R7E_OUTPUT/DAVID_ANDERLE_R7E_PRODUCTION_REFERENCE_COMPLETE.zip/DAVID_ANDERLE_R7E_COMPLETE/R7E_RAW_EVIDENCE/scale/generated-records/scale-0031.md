---
title: Scale record 0031
slug: scale-0031
year: 2017
sequence: 31
material: graphite
summary: Deterministic generated record 31 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 31.
