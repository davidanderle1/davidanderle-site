---
title: Scale record 0197
slug: scale-0197
year: 2023
sequence: 197
material: oxide
summary: Deterministic generated record 197 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 197.
