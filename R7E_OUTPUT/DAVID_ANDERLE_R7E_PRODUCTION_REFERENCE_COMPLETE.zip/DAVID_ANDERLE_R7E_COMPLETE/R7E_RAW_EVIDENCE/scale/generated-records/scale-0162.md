---
title: Scale record 0162
slug: scale-0162
year: 2018
sequence: 162
material: paper
summary: Deterministic generated record 162 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 162.
