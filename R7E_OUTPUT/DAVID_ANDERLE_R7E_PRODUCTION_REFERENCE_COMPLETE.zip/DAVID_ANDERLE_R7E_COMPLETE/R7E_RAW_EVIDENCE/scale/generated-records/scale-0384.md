---
title: Scale record 0384
slug: scale-0384
year: 2020
sequence: 384
material: paper
summary: Deterministic generated record 384 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 384.
