---
title: Scale record 0222
slug: scale-0222
year: 2018
sequence: 222
material: paper
summary: Deterministic generated record 222 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 222.
