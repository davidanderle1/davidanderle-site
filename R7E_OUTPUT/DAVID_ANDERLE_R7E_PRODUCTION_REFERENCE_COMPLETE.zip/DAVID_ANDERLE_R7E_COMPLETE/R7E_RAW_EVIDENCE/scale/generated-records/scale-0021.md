---
title: Scale record 0021
slug: scale-0021
year: 2017
sequence: 21
material: paper
summary: Deterministic generated record 21 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 21.
