---
title: Scale record 0272
slug: scale-0272
year: 2018
sequence: 272
material: oxide
summary: Deterministic generated record 272 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 272.
