---
title: Scale record 0048
slug: scale-0048
year: 2024
sequence: 48
material: paper
summary: Deterministic generated record 48 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 48.
