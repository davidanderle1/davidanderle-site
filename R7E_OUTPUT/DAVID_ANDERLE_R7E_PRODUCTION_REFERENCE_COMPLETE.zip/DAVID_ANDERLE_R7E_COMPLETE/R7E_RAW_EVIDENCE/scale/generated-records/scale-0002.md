---
title: Scale record 0002
slug: scale-0002
year: 2018
sequence: 2
material: oxide
summary: Deterministic generated record 2 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 2.
