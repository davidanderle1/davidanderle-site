---
title: Scale record 0023
slug: scale-0023
year: 2019
sequence: 23
material: oxide
summary: Deterministic generated record 23 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 23.
