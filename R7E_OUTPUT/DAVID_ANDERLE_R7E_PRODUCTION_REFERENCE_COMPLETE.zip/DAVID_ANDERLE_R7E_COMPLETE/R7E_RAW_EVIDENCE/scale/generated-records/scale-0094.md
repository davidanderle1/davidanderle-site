---
title: Scale record 0094
slug: scale-0094
year: 2020
sequence: 94
material: graphite
summary: Deterministic generated record 94 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 94.
