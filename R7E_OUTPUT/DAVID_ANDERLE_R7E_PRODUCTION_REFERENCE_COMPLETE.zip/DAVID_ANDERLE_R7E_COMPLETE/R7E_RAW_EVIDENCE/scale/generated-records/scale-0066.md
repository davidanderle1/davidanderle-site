---
title: Scale record 0066
slug: scale-0066
year: 2022
sequence: 66
material: paper
summary: Deterministic generated record 66 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 66.
