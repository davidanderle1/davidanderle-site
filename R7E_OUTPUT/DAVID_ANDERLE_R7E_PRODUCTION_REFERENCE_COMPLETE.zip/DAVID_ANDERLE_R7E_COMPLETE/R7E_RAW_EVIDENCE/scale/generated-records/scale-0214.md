---
title: Scale record 0214
slug: scale-0214
year: 2020
sequence: 214
material: graphite
summary: Deterministic generated record 214 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 214.
