---
title: Scale record 0302
slug: scale-0302
year: 2018
sequence: 302
material: oxide
summary: Deterministic generated record 302 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 302.
