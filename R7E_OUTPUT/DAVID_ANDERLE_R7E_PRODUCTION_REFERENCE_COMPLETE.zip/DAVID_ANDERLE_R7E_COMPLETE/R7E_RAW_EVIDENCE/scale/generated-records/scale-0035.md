---
title: Scale record 0035
slug: scale-0035
year: 2021
sequence: 35
material: oxide
summary: Deterministic generated record 35 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 35.
