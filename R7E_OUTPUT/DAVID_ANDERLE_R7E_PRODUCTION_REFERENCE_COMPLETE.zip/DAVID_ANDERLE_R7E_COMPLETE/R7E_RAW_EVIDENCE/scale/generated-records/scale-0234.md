---
title: Scale record 0234
slug: scale-0234
year: 2020
sequence: 234
material: paper
summary: Deterministic generated record 234 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 234.
