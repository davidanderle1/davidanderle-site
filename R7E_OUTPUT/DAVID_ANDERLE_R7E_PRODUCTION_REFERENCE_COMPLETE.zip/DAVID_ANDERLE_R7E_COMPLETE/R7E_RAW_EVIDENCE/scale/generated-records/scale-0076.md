---
title: Scale record 0076
slug: scale-0076
year: 2022
sequence: 76
material: graphite
summary: Deterministic generated record 76 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 76.
