---
title: Scale record 0427
slug: scale-0427
year: 2023
sequence: 427
material: graphite
summary: Deterministic generated record 427 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 427.
