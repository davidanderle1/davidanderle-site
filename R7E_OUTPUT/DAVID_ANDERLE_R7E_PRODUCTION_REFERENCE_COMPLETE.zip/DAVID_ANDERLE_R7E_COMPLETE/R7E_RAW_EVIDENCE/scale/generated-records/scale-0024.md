---
title: Scale record 0024
slug: scale-0024
year: 2020
sequence: 24
material: paper
summary: Deterministic generated record 24 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 24.
