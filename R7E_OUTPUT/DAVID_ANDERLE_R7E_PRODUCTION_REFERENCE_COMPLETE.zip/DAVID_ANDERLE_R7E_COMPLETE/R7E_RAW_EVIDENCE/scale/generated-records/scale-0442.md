---
title: Scale record 0442
slug: scale-0442
year: 2018
sequence: 442
material: graphite
summary: Deterministic generated record 442 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 442.
