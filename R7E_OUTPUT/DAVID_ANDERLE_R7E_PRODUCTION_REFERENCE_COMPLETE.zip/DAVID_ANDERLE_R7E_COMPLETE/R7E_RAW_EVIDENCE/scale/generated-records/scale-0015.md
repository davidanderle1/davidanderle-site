---
title: Scale record 0015
slug: scale-0015
year: 2021
sequence: 15
material: paper
summary: Deterministic generated record 15 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 15.
