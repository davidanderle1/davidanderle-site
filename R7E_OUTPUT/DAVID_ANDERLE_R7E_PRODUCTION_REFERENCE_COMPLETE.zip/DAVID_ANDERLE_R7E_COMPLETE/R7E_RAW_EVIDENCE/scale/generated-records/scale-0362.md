---
title: Scale record 0362
slug: scale-0362
year: 2018
sequence: 362
material: oxide
summary: Deterministic generated record 362 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 362.
