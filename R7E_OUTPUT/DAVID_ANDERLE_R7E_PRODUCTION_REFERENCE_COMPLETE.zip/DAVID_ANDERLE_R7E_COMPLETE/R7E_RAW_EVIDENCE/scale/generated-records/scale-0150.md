---
title: Scale record 0150
slug: scale-0150
year: 2026
sequence: 150
material: paper
summary: Deterministic generated record 150 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 150.
