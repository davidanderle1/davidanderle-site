---
title: Scale record 0149
slug: scale-0149
year: 2025
sequence: 149
material: oxide
summary: Deterministic generated record 149 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 149.
