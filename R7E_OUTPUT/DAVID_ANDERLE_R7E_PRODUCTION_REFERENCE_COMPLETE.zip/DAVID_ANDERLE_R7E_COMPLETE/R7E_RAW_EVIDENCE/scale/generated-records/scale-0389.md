---
title: Scale record 0389
slug: scale-0389
year: 2025
sequence: 389
material: oxide
summary: Deterministic generated record 389 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 389.
