---
title: Scale record 0055
slug: scale-0055
year: 2021
sequence: 55
material: graphite
summary: Deterministic generated record 55 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 55.
