---
title: Scale record 0400
slug: scale-0400
year: 2026
sequence: 400
material: graphite
summary: Deterministic generated record 400 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 400.
