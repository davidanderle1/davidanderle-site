---
title: Scale record 0380
slug: scale-0380
year: 2026
sequence: 380
material: oxide
summary: Deterministic generated record 380 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 380.
