---
title: Scale record 0047
slug: scale-0047
year: 2023
sequence: 47
material: oxide
summary: Deterministic generated record 47 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 47.
