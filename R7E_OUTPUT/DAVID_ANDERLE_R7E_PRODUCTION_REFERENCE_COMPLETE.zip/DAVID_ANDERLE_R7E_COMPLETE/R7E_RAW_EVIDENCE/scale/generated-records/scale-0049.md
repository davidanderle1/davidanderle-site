---
title: Scale record 0049
slug: scale-0049
year: 2025
sequence: 49
material: graphite
summary: Deterministic generated record 49 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 49.
