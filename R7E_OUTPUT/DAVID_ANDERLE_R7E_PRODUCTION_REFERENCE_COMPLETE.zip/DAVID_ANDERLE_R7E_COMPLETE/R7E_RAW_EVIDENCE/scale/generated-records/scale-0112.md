---
title: Scale record 0112
slug: scale-0112
year: 2018
sequence: 112
material: graphite
summary: Deterministic generated record 112 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 112.
