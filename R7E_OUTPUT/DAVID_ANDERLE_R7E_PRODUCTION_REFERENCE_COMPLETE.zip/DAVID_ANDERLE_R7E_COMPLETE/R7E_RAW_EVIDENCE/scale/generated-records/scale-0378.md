---
title: Scale record 0378
slug: scale-0378
year: 2024
sequence: 378
material: paper
summary: Deterministic generated record 378 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 378.
