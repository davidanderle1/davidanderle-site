---
title: Scale record 0174
slug: scale-0174
year: 2020
sequence: 174
material: paper
summary: Deterministic generated record 174 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 174.
