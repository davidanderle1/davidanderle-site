---
title: Scale record 0191
slug: scale-0191
year: 2017
sequence: 191
material: oxide
summary: Deterministic generated record 191 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 191.
