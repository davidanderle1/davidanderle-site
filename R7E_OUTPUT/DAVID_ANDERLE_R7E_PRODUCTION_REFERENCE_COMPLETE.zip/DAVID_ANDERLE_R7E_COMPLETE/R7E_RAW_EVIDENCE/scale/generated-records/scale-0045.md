---
title: Scale record 0045
slug: scale-0045
year: 2021
sequence: 45
material: paper
summary: Deterministic generated record 45 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 45.
