---
title: Scale record 0420
slug: scale-0420
year: 2026
sequence: 420
material: paper
summary: Deterministic generated record 420 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 420.
