---
title: Scale record 0387
slug: scale-0387
year: 2023
sequence: 387
material: paper
summary: Deterministic generated record 387 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 387.
