---
title: Scale record 0383
slug: scale-0383
year: 2019
sequence: 383
material: oxide
summary: Deterministic generated record 383 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 383.
