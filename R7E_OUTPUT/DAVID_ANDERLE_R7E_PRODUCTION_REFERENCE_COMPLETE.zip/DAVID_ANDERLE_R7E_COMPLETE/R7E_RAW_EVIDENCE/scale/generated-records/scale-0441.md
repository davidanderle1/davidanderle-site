---
title: Scale record 0441
slug: scale-0441
year: 2017
sequence: 441
material: paper
summary: Deterministic generated record 441 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 441.
