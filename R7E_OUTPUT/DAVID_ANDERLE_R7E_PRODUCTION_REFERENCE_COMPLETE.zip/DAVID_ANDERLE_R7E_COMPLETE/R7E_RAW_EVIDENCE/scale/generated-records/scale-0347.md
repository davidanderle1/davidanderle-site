---
title: Scale record 0347
slug: scale-0347
year: 2023
sequence: 347
material: oxide
summary: Deterministic generated record 347 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 347.
