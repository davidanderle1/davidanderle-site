---
title: Scale record 0010
slug: scale-0010
year: 2026
sequence: 10
material: graphite
summary: Deterministic generated record 10 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 10.
