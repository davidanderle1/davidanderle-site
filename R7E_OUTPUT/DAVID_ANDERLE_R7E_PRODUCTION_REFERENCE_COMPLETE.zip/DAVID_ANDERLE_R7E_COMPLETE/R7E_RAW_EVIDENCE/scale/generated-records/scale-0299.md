---
title: Scale record 0299
slug: scale-0299
year: 2025
sequence: 299
material: oxide
summary: Deterministic generated record 299 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 299.
