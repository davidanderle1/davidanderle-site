---
title: Scale record 0422
slug: scale-0422
year: 2018
sequence: 422
material: oxide
summary: Deterministic generated record 422 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 422.
