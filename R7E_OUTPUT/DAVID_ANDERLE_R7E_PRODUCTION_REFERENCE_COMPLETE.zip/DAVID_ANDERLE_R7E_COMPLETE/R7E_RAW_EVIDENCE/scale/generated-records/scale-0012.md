---
title: Scale record 0012
slug: scale-0012
year: 2018
sequence: 12
material: paper
summary: Deterministic generated record 12 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 12.
