---
title: Scale record 0265
slug: scale-0265
year: 2021
sequence: 265
material: graphite
summary: Deterministic generated record 265 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 265.
