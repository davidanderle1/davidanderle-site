---
title: Scale record 0116
slug: scale-0116
year: 2022
sequence: 116
material: oxide
summary: Deterministic generated record 116 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 116.
