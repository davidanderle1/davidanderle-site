---
title: Scale record 0103
slug: scale-0103
year: 2019
sequence: 103
material: graphite
summary: Deterministic generated record 103 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 103.
