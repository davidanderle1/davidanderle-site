---
title: Scale record 0240
slug: scale-0240
year: 2026
sequence: 240
material: paper
summary: Deterministic generated record 240 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 240.
