---
title: Scale record 0067
slug: scale-0067
year: 2023
sequence: 67
material: graphite
summary: Deterministic generated record 67 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 67.
