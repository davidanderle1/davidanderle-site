---
title: Scale record 0125
slug: scale-0125
year: 2021
sequence: 125
material: oxide
summary: Deterministic generated record 125 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 125.
