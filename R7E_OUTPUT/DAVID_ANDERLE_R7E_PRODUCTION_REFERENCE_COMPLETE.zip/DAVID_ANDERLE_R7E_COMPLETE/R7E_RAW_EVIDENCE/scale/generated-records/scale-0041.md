---
title: Scale record 0041
slug: scale-0041
year: 2017
sequence: 41
material: oxide
summary: Deterministic generated record 41 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 41.
