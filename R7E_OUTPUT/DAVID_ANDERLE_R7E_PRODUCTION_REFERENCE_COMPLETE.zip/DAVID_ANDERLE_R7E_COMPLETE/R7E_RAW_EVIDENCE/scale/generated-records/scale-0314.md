---
title: Scale record 0314
slug: scale-0314
year: 2020
sequence: 314
material: oxide
summary: Deterministic generated record 314 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 314.
