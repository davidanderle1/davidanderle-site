---
title: Scale record 0290
slug: scale-0290
year: 2026
sequence: 290
material: oxide
summary: Deterministic generated record 290 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 290.
