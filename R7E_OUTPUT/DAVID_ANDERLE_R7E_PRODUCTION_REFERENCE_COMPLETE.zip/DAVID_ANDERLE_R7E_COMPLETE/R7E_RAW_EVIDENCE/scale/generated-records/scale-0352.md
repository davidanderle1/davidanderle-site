---
title: Scale record 0352
slug: scale-0352
year: 2018
sequence: 352
material: graphite
summary: Deterministic generated record 352 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 352.
