---
title: Scale record 0449
slug: scale-0449
year: 2025
sequence: 449
material: oxide
summary: Deterministic generated record 449 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 449.
