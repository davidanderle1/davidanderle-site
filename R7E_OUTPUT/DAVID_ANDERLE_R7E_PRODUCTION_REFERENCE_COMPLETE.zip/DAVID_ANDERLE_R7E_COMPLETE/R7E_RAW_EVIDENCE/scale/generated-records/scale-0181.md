---
title: Scale record 0181
slug: scale-0181
year: 2017
sequence: 181
material: graphite
summary: Deterministic generated record 181 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 181.
