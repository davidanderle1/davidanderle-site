---
title: Scale record 0051
slug: scale-0051
year: 2017
sequence: 51
material: paper
summary: Deterministic generated record 51 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 51.
