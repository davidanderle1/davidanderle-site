---
title: Scale record 0343
slug: scale-0343
year: 2019
sequence: 343
material: graphite
summary: Deterministic generated record 343 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 343.
