---
title: Scale record 0205
slug: scale-0205
year: 2021
sequence: 205
material: graphite
summary: Deterministic generated record 205 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 205.
