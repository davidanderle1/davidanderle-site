---
title: Scale record 0091
slug: scale-0091
year: 2017
sequence: 91
material: graphite
summary: Deterministic generated record 91 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 91.
