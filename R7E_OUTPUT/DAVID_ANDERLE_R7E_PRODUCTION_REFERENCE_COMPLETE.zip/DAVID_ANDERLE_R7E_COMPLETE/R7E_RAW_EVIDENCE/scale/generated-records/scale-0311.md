---
title: Scale record 0311
slug: scale-0311
year: 2017
sequence: 311
material: oxide
summary: Deterministic generated record 311 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 311.
