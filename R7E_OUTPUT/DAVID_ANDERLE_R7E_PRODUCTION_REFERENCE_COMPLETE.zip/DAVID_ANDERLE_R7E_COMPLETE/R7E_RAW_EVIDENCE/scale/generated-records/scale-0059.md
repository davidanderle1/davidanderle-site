---
title: Scale record 0059
slug: scale-0059
year: 2025
sequence: 59
material: oxide
summary: Deterministic generated record 59 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 59.
