---
title: Scale record 0145
slug: scale-0145
year: 2021
sequence: 145
material: graphite
summary: Deterministic generated record 145 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 145.
