---
title: Scale record 0274
slug: scale-0274
year: 2020
sequence: 274
material: graphite
summary: Deterministic generated record 274 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 274.
