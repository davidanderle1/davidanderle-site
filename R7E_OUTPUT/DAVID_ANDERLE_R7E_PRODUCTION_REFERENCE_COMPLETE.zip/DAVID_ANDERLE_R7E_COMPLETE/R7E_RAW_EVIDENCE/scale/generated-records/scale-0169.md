---
title: Scale record 0169
slug: scale-0169
year: 2025
sequence: 169
material: graphite
summary: Deterministic generated record 169 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 169.
