---
title: Scale record 0266
slug: scale-0266
year: 2022
sequence: 266
material: oxide
summary: Deterministic generated record 266 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 266.
