---
title: Scale record 0296
slug: scale-0296
year: 2022
sequence: 296
material: oxide
summary: Deterministic generated record 296 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 296.
