---
title: Scale record 0014
slug: scale-0014
year: 2020
sequence: 14
material: oxide
summary: Deterministic generated record 14 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 14.
