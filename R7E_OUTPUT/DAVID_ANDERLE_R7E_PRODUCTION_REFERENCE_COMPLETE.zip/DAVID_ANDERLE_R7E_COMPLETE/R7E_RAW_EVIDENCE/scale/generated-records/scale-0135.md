---
title: Scale record 0135
slug: scale-0135
year: 2021
sequence: 135
material: paper
summary: Deterministic generated record 135 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 135.
