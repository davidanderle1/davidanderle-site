---
title: Scale record 0365
slug: scale-0365
year: 2021
sequence: 365
material: oxide
summary: Deterministic generated record 365 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 365.
