---
title: Scale record 0243
slug: scale-0243
year: 2019
sequence: 243
material: paper
summary: Deterministic generated record 243 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 243.
