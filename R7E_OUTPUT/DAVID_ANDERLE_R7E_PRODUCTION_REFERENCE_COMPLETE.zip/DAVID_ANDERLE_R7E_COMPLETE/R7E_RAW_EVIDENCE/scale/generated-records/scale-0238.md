---
title: Scale record 0238
slug: scale-0238
year: 2024
sequence: 238
material: graphite
summary: Deterministic generated record 238 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 238.
