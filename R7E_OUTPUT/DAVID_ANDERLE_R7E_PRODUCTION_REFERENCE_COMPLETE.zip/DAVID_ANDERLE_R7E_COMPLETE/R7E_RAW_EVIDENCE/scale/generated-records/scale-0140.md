---
title: Scale record 0140
slug: scale-0140
year: 2026
sequence: 140
material: oxide
summary: Deterministic generated record 140 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 140.
