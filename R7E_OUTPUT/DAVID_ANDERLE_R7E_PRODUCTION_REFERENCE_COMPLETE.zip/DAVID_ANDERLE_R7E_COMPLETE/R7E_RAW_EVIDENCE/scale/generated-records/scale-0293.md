---
title: Scale record 0293
slug: scale-0293
year: 2019
sequence: 293
material: oxide
summary: Deterministic generated record 293 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 293.
