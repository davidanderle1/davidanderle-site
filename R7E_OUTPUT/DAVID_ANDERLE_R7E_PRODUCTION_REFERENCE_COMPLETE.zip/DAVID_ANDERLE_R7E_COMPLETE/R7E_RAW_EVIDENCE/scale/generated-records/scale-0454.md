---
title: Scale record 0454
slug: scale-0454
year: 2020
sequence: 454
material: graphite
summary: Deterministic generated record 454 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 454.
