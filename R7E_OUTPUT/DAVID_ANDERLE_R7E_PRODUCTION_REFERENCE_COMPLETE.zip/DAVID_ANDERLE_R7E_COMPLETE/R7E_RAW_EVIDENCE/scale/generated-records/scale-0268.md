---
title: Scale record 0268
slug: scale-0268
year: 2024
sequence: 268
material: graphite
summary: Deterministic generated record 268 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 268.
