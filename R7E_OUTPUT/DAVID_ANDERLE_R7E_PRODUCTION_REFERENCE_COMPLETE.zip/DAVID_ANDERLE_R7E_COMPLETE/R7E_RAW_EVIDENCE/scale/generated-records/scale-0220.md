---
title: Scale record 0220
slug: scale-0220
year: 2026
sequence: 220
material: graphite
summary: Deterministic generated record 220 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 220.
