---
title: Scale record 0077
slug: scale-0077
year: 2023
sequence: 77
material: oxide
summary: Deterministic generated record 77 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 77.
