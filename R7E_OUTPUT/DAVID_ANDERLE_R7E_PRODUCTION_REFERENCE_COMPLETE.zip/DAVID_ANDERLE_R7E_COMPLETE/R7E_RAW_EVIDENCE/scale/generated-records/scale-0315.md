---
title: Scale record 0315
slug: scale-0315
year: 2021
sequence: 315
material: paper
summary: Deterministic generated record 315 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 315.
