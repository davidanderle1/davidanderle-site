---
title: Scale record 0147
slug: scale-0147
year: 2023
sequence: 147
material: paper
summary: Deterministic generated record 147 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 147.
