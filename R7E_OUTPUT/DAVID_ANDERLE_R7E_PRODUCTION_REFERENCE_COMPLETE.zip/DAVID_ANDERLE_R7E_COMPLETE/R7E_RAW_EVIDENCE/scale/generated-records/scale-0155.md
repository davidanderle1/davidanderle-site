---
title: Scale record 0155
slug: scale-0155
year: 2021
sequence: 155
material: oxide
summary: Deterministic generated record 155 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 155.
