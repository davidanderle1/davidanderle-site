---
title: Scale record 0146
slug: scale-0146
year: 2022
sequence: 146
material: oxide
summary: Deterministic generated record 146 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 146.
