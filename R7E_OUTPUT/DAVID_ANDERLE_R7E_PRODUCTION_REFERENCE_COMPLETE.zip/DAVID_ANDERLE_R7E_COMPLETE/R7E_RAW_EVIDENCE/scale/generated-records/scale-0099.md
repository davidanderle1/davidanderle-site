---
title: Scale record 0099
slug: scale-0099
year: 2025
sequence: 99
material: paper
summary: Deterministic generated record 99 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 99.
