---
title: Scale record 0081
slug: scale-0081
year: 2017
sequence: 81
material: paper
summary: Deterministic generated record 81 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 81.
