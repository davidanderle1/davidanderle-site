---
title: Scale record 0079
slug: scale-0079
year: 2025
sequence: 79
material: graphite
summary: Deterministic generated record 79 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 79.
