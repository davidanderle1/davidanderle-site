---
title: Scale record 0312
slug: scale-0312
year: 2018
sequence: 312
material: paper
summary: Deterministic generated record 312 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 312.
