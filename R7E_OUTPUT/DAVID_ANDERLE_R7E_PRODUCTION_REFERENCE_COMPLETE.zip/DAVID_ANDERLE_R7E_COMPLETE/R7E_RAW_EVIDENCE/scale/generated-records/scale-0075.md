---
title: Scale record 0075
slug: scale-0075
year: 2021
sequence: 75
material: paper
summary: Deterministic generated record 75 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 75.
