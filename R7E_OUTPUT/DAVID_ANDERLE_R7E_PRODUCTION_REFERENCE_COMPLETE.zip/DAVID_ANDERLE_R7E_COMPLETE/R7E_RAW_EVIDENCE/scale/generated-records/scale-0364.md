---
title: Scale record 0364
slug: scale-0364
year: 2020
sequence: 364
material: graphite
summary: Deterministic generated record 364 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 364.
