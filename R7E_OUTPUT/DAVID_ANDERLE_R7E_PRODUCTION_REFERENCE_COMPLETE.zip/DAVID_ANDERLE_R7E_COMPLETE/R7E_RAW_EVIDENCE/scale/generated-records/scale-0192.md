---
title: Scale record 0192
slug: scale-0192
year: 2018
sequence: 192
material: paper
summary: Deterministic generated record 192 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 192.
