---
title: Scale record 0209
slug: scale-0209
year: 2025
sequence: 209
material: oxide
summary: Deterministic generated record 209 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 209.
