---
title: Scale record 0176
slug: scale-0176
year: 2022
sequence: 176
material: oxide
summary: Deterministic generated record 176 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 176.
