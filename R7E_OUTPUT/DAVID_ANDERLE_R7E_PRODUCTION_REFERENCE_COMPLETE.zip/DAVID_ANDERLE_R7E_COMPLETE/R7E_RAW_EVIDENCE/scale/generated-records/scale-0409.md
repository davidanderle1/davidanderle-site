---
title: Scale record 0409
slug: scale-0409
year: 2025
sequence: 409
material: graphite
summary: Deterministic generated record 409 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 409.
