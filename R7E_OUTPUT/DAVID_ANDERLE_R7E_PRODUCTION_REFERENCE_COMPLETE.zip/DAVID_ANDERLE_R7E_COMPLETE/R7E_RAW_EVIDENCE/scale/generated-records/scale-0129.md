---
title: Scale record 0129
slug: scale-0129
year: 2025
sequence: 129
material: paper
summary: Deterministic generated record 129 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 129.
