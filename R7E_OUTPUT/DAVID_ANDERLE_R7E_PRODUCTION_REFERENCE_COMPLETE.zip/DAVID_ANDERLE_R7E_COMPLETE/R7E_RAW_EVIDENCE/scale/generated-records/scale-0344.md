---
title: Scale record 0344
slug: scale-0344
year: 2020
sequence: 344
material: oxide
summary: Deterministic generated record 344 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 344.
