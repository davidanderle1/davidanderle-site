---
title: Scale record 0410
slug: scale-0410
year: 2026
sequence: 410
material: oxide
summary: Deterministic generated record 410 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 410.
