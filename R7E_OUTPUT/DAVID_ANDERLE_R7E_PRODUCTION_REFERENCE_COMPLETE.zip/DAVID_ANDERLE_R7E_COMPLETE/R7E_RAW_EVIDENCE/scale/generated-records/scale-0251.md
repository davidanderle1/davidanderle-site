---
title: Scale record 0251
slug: scale-0251
year: 2017
sequence: 251
material: oxide
summary: Deterministic generated record 251 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 251.
