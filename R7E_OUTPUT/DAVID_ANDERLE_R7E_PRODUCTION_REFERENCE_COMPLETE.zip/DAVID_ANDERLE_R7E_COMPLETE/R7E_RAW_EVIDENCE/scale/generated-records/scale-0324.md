---
title: Scale record 0324
slug: scale-0324
year: 2020
sequence: 324
material: paper
summary: Deterministic generated record 324 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 324.
