---
title: Scale record 0193
slug: scale-0193
year: 2019
sequence: 193
material: graphite
summary: Deterministic generated record 193 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 193.
