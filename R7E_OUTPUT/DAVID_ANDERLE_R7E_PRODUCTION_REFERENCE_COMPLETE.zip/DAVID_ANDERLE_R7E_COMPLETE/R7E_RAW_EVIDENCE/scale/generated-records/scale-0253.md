---
title: Scale record 0253
slug: scale-0253
year: 2019
sequence: 253
material: graphite
summary: Deterministic generated record 253 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 253.
