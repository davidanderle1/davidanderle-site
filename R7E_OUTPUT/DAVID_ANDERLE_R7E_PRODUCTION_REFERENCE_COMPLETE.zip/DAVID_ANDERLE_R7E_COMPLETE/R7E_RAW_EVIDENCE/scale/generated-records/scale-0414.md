---
title: Scale record 0414
slug: scale-0414
year: 2020
sequence: 414
material: paper
summary: Deterministic generated record 414 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 414.
