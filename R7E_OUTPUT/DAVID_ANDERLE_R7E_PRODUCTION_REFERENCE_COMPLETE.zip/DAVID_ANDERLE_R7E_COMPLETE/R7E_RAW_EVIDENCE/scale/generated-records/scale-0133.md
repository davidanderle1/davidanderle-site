---
title: Scale record 0133
slug: scale-0133
year: 2019
sequence: 133
material: graphite
summary: Deterministic generated record 133 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 133.
