---
title: Scale record 0241
slug: scale-0241
year: 2017
sequence: 241
material: graphite
summary: Deterministic generated record 241 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 241.
