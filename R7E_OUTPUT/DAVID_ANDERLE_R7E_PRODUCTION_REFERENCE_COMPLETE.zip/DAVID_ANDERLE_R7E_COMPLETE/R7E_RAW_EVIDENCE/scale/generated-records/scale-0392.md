---
title: Scale record 0392
slug: scale-0392
year: 2018
sequence: 392
material: oxide
summary: Deterministic generated record 392 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 392.
