---
title: Scale record 0110
slug: scale-0110
year: 2026
sequence: 110
material: oxide
summary: Deterministic generated record 110 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 110.
