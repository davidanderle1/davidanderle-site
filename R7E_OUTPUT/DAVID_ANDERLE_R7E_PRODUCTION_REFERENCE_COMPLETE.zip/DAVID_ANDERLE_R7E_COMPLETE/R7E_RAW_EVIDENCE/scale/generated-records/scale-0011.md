---
title: Scale record 0011
slug: scale-0011
year: 2017
sequence: 11
material: oxide
summary: Deterministic generated record 11 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 11.
