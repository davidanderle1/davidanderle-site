---
title: Scale record 0226
slug: scale-0226
year: 2022
sequence: 226
material: graphite
summary: Deterministic generated record 226 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 226.
