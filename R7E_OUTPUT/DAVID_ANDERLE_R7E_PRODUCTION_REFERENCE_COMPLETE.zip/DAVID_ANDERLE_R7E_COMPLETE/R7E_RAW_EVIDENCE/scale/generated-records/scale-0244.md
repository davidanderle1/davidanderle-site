---
title: Scale record 0244
slug: scale-0244
year: 2020
sequence: 244
material: graphite
summary: Deterministic generated record 244 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 244.
