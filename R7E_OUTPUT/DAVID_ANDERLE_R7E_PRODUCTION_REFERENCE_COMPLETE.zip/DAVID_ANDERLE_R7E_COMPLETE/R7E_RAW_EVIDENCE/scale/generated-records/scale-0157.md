---
title: Scale record 0157
slug: scale-0157
year: 2023
sequence: 157
material: graphite
summary: Deterministic generated record 157 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 157.
