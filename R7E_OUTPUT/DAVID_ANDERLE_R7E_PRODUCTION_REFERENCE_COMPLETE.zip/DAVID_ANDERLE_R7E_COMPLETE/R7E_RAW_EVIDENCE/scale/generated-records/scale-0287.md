---
title: Scale record 0287
slug: scale-0287
year: 2023
sequence: 287
material: oxide
summary: Deterministic generated record 287 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 287.
