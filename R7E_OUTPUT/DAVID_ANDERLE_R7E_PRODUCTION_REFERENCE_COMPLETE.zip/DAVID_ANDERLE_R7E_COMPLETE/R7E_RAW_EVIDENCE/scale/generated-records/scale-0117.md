---
title: Scale record 0117
slug: scale-0117
year: 2023
sequence: 117
material: paper
summary: Deterministic generated record 117 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 117.
