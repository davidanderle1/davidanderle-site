---
title: Scale record 0430
slug: scale-0430
year: 2026
sequence: 430
material: graphite
summary: Deterministic generated record 430 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 430.
