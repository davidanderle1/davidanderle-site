---
title: Scale record 0388
slug: scale-0388
year: 2024
sequence: 388
material: graphite
summary: Deterministic generated record 388 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 388.
