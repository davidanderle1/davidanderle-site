---
title: Scale record 0084
slug: scale-0084
year: 2020
sequence: 84
material: paper
summary: Deterministic generated record 84 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 84.
