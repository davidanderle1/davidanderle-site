---
title: Scale record 0435
slug: scale-0435
year: 2021
sequence: 435
material: paper
summary: Deterministic generated record 435 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 435.
