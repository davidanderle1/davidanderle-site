---
title: Scale record 0115
slug: scale-0115
year: 2021
sequence: 115
material: graphite
summary: Deterministic generated record 115 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 115.
