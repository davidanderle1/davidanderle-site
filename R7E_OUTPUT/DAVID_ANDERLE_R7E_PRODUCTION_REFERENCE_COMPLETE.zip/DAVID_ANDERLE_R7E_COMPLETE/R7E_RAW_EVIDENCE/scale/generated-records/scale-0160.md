---
title: Scale record 0160
slug: scale-0160
year: 2026
sequence: 160
material: graphite
summary: Deterministic generated record 160 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 160.
