---
title: Scale record 0065
slug: scale-0065
year: 2021
sequence: 65
material: oxide
summary: Deterministic generated record 65 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 65.
