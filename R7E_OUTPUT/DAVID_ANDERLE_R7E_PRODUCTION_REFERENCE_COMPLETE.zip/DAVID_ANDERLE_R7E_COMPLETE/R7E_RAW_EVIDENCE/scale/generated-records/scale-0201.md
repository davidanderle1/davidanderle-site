---
title: Scale record 0201
slug: scale-0201
year: 2017
sequence: 201
material: paper
summary: Deterministic generated record 201 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 201.
