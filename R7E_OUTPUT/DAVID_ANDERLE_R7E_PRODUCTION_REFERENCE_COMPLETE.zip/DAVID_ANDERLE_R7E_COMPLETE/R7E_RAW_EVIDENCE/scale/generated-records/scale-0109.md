---
title: Scale record 0109
slug: scale-0109
year: 2025
sequence: 109
material: graphite
summary: Deterministic generated record 109 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 109.
