---
title: Scale record 0206
slug: scale-0206
year: 2022
sequence: 206
material: oxide
summary: Deterministic generated record 206 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 206.
