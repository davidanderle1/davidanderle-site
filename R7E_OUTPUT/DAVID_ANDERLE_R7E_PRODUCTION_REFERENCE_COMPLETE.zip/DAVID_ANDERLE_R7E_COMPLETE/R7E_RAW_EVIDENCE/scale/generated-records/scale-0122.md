---
title: Scale record 0122
slug: scale-0122
year: 2018
sequence: 122
material: oxide
summary: Deterministic generated record 122 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 122.
