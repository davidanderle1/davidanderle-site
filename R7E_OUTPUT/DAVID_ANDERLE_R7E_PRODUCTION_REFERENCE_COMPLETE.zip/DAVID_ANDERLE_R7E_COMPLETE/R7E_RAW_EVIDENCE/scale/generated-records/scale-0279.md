---
title: Scale record 0279
slug: scale-0279
year: 2025
sequence: 279
material: paper
summary: Deterministic generated record 279 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 279.
