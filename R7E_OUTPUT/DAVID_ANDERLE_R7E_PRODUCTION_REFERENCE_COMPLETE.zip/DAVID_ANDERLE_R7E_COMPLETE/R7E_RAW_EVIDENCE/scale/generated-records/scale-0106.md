---
title: Scale record 0106
slug: scale-0106
year: 2022
sequence: 106
material: graphite
summary: Deterministic generated record 106 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 106.
