---
title: Scale record 0280
slug: scale-0280
year: 2026
sequence: 280
material: graphite
summary: Deterministic generated record 280 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 280.
