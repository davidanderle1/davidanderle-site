---
title: Scale record 0236
slug: scale-0236
year: 2022
sequence: 236
material: oxide
summary: Deterministic generated record 236 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 236.
