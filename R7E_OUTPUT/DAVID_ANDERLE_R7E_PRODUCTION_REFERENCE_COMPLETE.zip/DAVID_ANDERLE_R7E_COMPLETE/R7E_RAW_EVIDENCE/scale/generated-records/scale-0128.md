---
title: Scale record 0128
slug: scale-0128
year: 2024
sequence: 128
material: oxide
summary: Deterministic generated record 128 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 128.
