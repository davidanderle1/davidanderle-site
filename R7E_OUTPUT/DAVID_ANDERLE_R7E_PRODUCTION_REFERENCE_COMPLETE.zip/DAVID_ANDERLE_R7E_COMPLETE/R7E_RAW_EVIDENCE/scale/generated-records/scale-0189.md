---
title: Scale record 0189
slug: scale-0189
year: 2025
sequence: 189
material: paper
summary: Deterministic generated record 189 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 189.
