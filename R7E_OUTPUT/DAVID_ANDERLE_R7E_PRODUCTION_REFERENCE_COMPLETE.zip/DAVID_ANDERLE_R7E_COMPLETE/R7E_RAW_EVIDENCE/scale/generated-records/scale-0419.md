---
title: Scale record 0419
slug: scale-0419
year: 2025
sequence: 419
material: oxide
summary: Deterministic generated record 419 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 419.
