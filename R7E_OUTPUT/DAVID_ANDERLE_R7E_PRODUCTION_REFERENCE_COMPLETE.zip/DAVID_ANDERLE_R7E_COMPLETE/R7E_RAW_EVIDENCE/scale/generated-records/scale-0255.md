---
title: Scale record 0255
slug: scale-0255
year: 2021
sequence: 255
material: paper
summary: Deterministic generated record 255 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 255.
