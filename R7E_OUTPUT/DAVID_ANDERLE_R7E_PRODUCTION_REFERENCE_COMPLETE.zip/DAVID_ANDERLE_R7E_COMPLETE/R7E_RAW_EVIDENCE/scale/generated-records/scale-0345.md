---
title: Scale record 0345
slug: scale-0345
year: 2021
sequence: 345
material: paper
summary: Deterministic generated record 345 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 345.
