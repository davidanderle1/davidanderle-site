---
title: Scale record 0317
slug: scale-0317
year: 2023
sequence: 317
material: oxide
summary: Deterministic generated record 317 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 317.
