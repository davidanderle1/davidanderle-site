---
title: Scale record 0141
slug: scale-0141
year: 2017
sequence: 141
material: paper
summary: Deterministic generated record 141 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 141.
