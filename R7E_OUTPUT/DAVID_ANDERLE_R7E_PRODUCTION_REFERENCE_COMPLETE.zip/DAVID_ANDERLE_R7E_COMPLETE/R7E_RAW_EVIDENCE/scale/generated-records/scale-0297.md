---
title: Scale record 0297
slug: scale-0297
year: 2023
sequence: 297
material: paper
summary: Deterministic generated record 297 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 297.
