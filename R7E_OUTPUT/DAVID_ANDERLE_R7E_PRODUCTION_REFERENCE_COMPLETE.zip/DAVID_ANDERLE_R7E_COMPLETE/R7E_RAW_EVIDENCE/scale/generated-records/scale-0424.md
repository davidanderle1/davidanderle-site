---
title: Scale record 0424
slug: scale-0424
year: 2020
sequence: 424
material: graphite
summary: Deterministic generated record 424 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 424.
