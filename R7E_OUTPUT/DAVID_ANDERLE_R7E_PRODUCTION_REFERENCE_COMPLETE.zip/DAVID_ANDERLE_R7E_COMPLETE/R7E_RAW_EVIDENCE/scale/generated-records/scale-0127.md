---
title: Scale record 0127
slug: scale-0127
year: 2023
sequence: 127
material: graphite
summary: Deterministic generated record 127 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 127.
