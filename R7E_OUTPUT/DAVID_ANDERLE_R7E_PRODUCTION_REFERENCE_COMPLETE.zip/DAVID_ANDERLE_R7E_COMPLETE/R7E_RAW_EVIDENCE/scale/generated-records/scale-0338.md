---
title: Scale record 0338
slug: scale-0338
year: 2024
sequence: 338
material: oxide
summary: Deterministic generated record 338 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 338.
