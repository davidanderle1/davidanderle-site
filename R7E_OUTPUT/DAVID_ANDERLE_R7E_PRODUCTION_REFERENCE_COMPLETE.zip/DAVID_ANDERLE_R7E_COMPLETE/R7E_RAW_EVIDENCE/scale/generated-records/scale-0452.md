---
title: Scale record 0452
slug: scale-0452
year: 2018
sequence: 452
material: oxide
summary: Deterministic generated record 452 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 452.
