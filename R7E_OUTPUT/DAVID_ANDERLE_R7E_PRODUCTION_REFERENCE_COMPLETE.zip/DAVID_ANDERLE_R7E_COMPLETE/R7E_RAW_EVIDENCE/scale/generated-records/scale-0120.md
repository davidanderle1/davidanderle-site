---
title: Scale record 0120
slug: scale-0120
year: 2026
sequence: 120
material: paper
summary: Deterministic generated record 120 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 120.
