---
title: Scale record 0308
slug: scale-0308
year: 2024
sequence: 308
material: oxide
summary: Deterministic generated record 308 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 308.
