---
title: Scale record 0104
slug: scale-0104
year: 2020
sequence: 104
material: oxide
summary: Deterministic generated record 104 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 104.
