---
title: Scale record 0322
slug: scale-0322
year: 2018
sequence: 322
material: graphite
summary: Deterministic generated record 322 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 322.
