---
title: Scale record 0303
slug: scale-0303
year: 2019
sequence: 303
material: paper
summary: Deterministic generated record 303 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 303.
