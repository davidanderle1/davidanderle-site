---
title: Scale record 0288
slug: scale-0288
year: 2024
sequence: 288
material: paper
summary: Deterministic generated record 288 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 288.
