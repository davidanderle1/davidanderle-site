---
title: Scale record 0043
slug: scale-0043
year: 2019
sequence: 43
material: graphite
summary: Deterministic generated record 43 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 43.
