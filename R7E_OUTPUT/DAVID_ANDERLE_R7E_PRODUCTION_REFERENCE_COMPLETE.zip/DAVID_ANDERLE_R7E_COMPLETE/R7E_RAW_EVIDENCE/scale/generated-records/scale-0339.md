---
title: Scale record 0339
slug: scale-0339
year: 2025
sequence: 339
material: paper
summary: Deterministic generated record 339 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 339.
