---
title: Scale record 0126
slug: scale-0126
year: 2022
sequence: 126
material: paper
summary: Deterministic generated record 126 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 126.
