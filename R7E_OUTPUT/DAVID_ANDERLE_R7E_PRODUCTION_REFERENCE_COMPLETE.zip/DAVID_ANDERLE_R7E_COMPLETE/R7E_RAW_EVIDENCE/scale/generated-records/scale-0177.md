---
title: Scale record 0177
slug: scale-0177
year: 2023
sequence: 177
material: paper
summary: Deterministic generated record 177 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 177.
