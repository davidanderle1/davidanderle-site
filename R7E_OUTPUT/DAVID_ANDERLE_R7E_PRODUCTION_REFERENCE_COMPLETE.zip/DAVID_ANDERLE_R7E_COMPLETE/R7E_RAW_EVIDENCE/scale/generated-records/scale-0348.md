---
title: Scale record 0348
slug: scale-0348
year: 2024
sequence: 348
material: paper
summary: Deterministic generated record 348 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 348.
