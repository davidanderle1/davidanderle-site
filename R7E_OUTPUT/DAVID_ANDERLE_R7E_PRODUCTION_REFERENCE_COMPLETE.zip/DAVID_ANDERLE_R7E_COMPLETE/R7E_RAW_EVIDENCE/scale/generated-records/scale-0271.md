---
title: Scale record 0271
slug: scale-0271
year: 2017
sequence: 271
material: graphite
summary: Deterministic generated record 271 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 271.
