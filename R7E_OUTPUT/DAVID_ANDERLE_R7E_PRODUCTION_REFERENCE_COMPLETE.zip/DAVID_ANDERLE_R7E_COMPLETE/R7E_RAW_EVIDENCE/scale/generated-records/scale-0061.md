---
title: Scale record 0061
slug: scale-0061
year: 2017
sequence: 61
material: graphite
summary: Deterministic generated record 61 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 61.
