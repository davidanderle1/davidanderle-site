---
title: Scale record 0219
slug: scale-0219
year: 2025
sequence: 219
material: paper
summary: Deterministic generated record 219 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 219.
