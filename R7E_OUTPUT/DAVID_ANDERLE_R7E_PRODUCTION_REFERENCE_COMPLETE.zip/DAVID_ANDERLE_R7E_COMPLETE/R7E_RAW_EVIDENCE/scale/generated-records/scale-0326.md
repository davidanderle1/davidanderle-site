---
title: Scale record 0326
slug: scale-0326
year: 2022
sequence: 326
material: oxide
summary: Deterministic generated record 326 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 326.
