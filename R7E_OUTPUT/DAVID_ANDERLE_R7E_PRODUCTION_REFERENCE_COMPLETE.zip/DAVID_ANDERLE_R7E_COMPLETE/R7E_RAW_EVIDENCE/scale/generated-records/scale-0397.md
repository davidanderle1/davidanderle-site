---
title: Scale record 0397
slug: scale-0397
year: 2023
sequence: 397
material: graphite
summary: Deterministic generated record 397 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 397.
