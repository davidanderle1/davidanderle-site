---
title: Scale record 0130
slug: scale-0130
year: 2026
sequence: 130
material: graphite
summary: Deterministic generated record 130 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 130.
