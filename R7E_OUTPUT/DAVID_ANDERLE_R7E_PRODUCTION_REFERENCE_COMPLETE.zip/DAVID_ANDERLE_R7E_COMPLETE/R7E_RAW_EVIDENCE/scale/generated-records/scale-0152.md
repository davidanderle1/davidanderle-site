---
title: Scale record 0152
slug: scale-0152
year: 2018
sequence: 152
material: oxide
summary: Deterministic generated record 152 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 152.
