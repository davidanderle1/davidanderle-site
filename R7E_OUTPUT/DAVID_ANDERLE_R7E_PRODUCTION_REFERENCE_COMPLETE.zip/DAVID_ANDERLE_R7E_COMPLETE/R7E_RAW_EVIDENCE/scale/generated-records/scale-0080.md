---
title: Scale record 0080
slug: scale-0080
year: 2026
sequence: 80
material: oxide
summary: Deterministic generated record 80 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 80.
