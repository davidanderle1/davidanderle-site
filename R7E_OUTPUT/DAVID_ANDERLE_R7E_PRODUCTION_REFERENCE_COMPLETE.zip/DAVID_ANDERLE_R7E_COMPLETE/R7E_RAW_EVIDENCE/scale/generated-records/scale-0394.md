---
title: Scale record 0394
slug: scale-0394
year: 2020
sequence: 394
material: graphite
summary: Deterministic generated record 394 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 394.
