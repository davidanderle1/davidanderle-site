---
title: Scale record 0057
slug: scale-0057
year: 2023
sequence: 57
material: paper
summary: Deterministic generated record 57 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 57.
