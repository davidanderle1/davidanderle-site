---
title: Scale record 0436
slug: scale-0436
year: 2022
sequence: 436
material: graphite
summary: Deterministic generated record 436 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 436.
