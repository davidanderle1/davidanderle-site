---
title: Scale record 0148
slug: scale-0148
year: 2024
sequence: 148
material: graphite
summary: Deterministic generated record 148 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 148.
