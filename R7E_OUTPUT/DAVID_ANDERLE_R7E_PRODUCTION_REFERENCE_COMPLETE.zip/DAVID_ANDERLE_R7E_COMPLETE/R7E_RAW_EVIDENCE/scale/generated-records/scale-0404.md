---
title: Scale record 0404
slug: scale-0404
year: 2020
sequence: 404
material: oxide
summary: Deterministic generated record 404 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 404.
