---
title: Scale record 0046
slug: scale-0046
year: 2022
sequence: 46
material: graphite
summary: Deterministic generated record 46 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 46.
