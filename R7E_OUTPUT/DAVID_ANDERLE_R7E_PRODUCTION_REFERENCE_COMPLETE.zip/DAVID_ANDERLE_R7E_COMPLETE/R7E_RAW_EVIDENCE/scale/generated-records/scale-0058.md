---
title: Scale record 0058
slug: scale-0058
year: 2024
sequence: 58
material: graphite
summary: Deterministic generated record 58 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 58.
