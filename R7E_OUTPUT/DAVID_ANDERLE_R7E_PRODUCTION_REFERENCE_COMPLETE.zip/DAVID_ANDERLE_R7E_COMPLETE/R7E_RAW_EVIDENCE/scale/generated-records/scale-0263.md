---
title: Scale record 0263
slug: scale-0263
year: 2019
sequence: 263
material: oxide
summary: Deterministic generated record 263 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 263.
