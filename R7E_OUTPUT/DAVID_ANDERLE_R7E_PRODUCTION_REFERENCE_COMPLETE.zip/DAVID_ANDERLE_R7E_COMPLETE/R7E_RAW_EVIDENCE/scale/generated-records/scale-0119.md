---
title: Scale record 0119
slug: scale-0119
year: 2025
sequence: 119
material: oxide
summary: Deterministic generated record 119 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 119.
