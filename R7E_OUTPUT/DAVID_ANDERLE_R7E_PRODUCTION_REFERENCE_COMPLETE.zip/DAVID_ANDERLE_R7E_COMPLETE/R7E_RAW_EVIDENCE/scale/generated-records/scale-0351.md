---
title: Scale record 0351
slug: scale-0351
year: 2017
sequence: 351
material: paper
summary: Deterministic generated record 351 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 351.
