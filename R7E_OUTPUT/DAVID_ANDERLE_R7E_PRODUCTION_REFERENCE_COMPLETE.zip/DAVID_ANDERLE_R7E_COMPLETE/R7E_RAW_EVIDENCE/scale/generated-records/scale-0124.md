---
title: Scale record 0124
slug: scale-0124
year: 2020
sequence: 124
material: graphite
summary: Deterministic generated record 124 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 124.
