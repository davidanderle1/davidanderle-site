---
title: Scale record 0349
slug: scale-0349
year: 2025
sequence: 349
material: graphite
summary: Deterministic generated record 349 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 349.
