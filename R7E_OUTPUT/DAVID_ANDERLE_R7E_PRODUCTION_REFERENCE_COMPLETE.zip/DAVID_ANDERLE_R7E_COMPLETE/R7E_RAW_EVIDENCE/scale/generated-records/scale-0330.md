---
title: Scale record 0330
slug: scale-0330
year: 2026
sequence: 330
material: paper
summary: Deterministic generated record 330 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 330.
