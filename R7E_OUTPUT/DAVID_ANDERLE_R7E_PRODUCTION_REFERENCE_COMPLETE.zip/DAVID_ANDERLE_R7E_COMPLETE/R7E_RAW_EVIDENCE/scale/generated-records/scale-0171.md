---
title: Scale record 0171
slug: scale-0171
year: 2017
sequence: 171
material: paper
summary: Deterministic generated record 171 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 171.
