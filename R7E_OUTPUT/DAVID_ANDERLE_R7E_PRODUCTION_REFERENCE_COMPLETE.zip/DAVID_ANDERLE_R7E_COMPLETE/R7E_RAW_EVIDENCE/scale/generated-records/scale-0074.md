---
title: Scale record 0074
slug: scale-0074
year: 2020
sequence: 74
material: oxide
summary: Deterministic generated record 74 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 74.
