---
title: Scale record 0166
slug: scale-0166
year: 2022
sequence: 166
material: graphite
summary: Deterministic generated record 166 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 166.
