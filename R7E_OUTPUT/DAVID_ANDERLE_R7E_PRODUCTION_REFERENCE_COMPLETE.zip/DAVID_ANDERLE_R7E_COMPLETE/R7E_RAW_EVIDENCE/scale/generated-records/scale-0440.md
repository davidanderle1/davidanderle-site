---
title: Scale record 0440
slug: scale-0440
year: 2026
sequence: 440
material: oxide
summary: Deterministic generated record 440 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 440.
