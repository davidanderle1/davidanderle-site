---
title: Scale record 0453
slug: scale-0453
year: 2019
sequence: 453
material: paper
summary: Deterministic generated record 453 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 453.
