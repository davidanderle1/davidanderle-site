---
title: Scale record 0310
slug: scale-0310
year: 2026
sequence: 310
material: graphite
summary: Deterministic generated record 310 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 310.
