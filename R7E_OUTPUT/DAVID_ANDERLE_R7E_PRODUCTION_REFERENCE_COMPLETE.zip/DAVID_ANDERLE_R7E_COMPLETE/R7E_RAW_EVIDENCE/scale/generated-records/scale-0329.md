---
title: Scale record 0329
slug: scale-0329
year: 2025
sequence: 329
material: oxide
summary: Deterministic generated record 329 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 329.
