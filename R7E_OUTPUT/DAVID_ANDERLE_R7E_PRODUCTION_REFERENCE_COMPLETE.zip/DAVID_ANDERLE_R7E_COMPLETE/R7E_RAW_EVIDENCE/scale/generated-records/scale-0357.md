---
title: Scale record 0357
slug: scale-0357
year: 2023
sequence: 357
material: paper
summary: Deterministic generated record 357 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 357.
