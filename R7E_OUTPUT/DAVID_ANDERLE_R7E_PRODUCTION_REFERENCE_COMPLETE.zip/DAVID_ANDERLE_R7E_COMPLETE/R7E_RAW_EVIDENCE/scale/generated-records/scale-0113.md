---
title: Scale record 0113
slug: scale-0113
year: 2019
sequence: 113
material: oxide
summary: Deterministic generated record 113 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 113.
