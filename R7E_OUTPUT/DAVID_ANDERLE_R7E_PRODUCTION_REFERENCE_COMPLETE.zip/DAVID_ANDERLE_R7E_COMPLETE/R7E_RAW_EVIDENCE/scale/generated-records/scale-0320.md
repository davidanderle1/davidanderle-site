---
title: Scale record 0320
slug: scale-0320
year: 2026
sequence: 320
material: oxide
summary: Deterministic generated record 320 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 320.
