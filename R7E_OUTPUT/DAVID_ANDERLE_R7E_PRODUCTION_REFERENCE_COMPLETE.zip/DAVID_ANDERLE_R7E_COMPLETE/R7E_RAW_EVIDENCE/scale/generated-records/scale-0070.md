---
title: Scale record 0070
slug: scale-0070
year: 2026
sequence: 70
material: graphite
summary: Deterministic generated record 70 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 70.
