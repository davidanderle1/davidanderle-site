---
title: Scale record 0179
slug: scale-0179
year: 2025
sequence: 179
material: oxide
summary: Deterministic generated record 179 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 179.
