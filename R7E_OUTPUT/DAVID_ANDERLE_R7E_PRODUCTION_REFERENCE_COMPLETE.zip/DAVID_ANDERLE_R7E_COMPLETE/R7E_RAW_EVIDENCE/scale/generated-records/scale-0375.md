---
title: Scale record 0375
slug: scale-0375
year: 2021
sequence: 375
material: paper
summary: Deterministic generated record 375 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 375.
