---
title: Scale record 0356
slug: scale-0356
year: 2022
sequence: 356
material: oxide
summary: Deterministic generated record 356 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 356.
