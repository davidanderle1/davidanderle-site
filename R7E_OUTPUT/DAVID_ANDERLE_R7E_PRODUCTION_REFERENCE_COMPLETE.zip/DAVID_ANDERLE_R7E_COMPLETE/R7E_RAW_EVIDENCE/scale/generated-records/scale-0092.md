---
title: Scale record 0092
slug: scale-0092
year: 2018
sequence: 92
material: oxide
summary: Deterministic generated record 92 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 92.
