---
title: Scale record 0247
slug: scale-0247
year: 2023
sequence: 247
material: graphite
summary: Deterministic generated record 247 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 247.
