---
title: Scale record 0292
slug: scale-0292
year: 2018
sequence: 292
material: graphite
summary: Deterministic generated record 292 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 292.
