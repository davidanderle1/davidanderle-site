---
title: Scale record 0161
slug: scale-0161
year: 2017
sequence: 161
material: oxide
summary: Deterministic generated record 161 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 161.
