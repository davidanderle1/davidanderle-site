---
title: Scale record 0421
slug: scale-0421
year: 2017
sequence: 421
material: graphite
summary: Deterministic generated record 421 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 421.
