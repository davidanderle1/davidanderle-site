---
title: Scale record 0341
slug: scale-0341
year: 2017
sequence: 341
material: oxide
summary: Deterministic generated record 341 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 341.
