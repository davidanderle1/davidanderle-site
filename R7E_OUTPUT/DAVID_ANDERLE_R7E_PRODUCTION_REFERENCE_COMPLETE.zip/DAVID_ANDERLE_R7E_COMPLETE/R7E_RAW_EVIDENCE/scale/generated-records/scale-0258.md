---
title: Scale record 0258
slug: scale-0258
year: 2024
sequence: 258
material: paper
summary: Deterministic generated record 258 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 258.
