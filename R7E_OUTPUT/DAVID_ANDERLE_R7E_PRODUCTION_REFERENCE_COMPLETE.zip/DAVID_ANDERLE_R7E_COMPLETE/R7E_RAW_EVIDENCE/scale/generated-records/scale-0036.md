---
title: Scale record 0036
slug: scale-0036
year: 2022
sequence: 36
material: paper
summary: Deterministic generated record 36 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 36.
