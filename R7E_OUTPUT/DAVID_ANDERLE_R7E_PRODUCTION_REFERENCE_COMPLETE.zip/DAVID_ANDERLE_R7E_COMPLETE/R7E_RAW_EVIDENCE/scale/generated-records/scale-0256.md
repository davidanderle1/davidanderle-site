---
title: Scale record 0256
slug: scale-0256
year: 2022
sequence: 256
material: graphite
summary: Deterministic generated record 256 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 256.
