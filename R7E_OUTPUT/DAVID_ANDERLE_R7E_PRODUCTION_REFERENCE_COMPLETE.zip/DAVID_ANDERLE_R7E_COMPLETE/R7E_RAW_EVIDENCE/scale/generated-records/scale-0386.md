---
title: Scale record 0386
slug: scale-0386
year: 2022
sequence: 386
material: oxide
summary: Deterministic generated record 386 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 386.
