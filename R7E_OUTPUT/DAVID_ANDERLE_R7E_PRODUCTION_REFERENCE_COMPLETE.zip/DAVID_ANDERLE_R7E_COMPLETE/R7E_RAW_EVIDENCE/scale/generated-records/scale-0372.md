---
title: Scale record 0372
slug: scale-0372
year: 2018
sequence: 372
material: paper
summary: Deterministic generated record 372 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 372.
