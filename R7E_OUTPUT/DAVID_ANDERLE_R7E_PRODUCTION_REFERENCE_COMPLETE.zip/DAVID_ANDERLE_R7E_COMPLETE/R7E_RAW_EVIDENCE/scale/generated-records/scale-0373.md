---
title: Scale record 0373
slug: scale-0373
year: 2019
sequence: 373
material: graphite
summary: Deterministic generated record 373 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 373.
