---
title: Scale record 0391
slug: scale-0391
year: 2017
sequence: 391
material: graphite
summary: Deterministic generated record 391 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 391.
