---
title: Scale record 0382
slug: scale-0382
year: 2018
sequence: 382
material: graphite
summary: Deterministic generated record 382 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 382.
