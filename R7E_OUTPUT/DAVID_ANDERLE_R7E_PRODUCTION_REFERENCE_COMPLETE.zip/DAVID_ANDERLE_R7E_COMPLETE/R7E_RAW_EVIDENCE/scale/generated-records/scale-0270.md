---
title: Scale record 0270
slug: scale-0270
year: 2026
sequence: 270
material: paper
summary: Deterministic generated record 270 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 270.
