---
title: Scale record 0095
slug: scale-0095
year: 2021
sequence: 95
material: oxide
summary: Deterministic generated record 95 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 95.
