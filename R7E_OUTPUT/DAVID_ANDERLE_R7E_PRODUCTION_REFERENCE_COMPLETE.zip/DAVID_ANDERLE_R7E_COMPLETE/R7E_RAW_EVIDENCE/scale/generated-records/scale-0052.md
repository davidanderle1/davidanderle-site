---
title: Scale record 0052
slug: scale-0052
year: 2018
sequence: 52
material: graphite
summary: Deterministic generated record 52 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 52.
