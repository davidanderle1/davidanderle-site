---
title: Scale record 0369
slug: scale-0369
year: 2025
sequence: 369
material: paper
summary: Deterministic generated record 369 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 369.
