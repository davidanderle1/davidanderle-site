---
title: Scale record 0276
slug: scale-0276
year: 2022
sequence: 276
material: paper
summary: Deterministic generated record 276 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 276.
