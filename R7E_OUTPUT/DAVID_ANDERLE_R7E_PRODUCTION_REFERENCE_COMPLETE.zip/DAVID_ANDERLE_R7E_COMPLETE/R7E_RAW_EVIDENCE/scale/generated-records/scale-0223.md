---
title: Scale record 0223
slug: scale-0223
year: 2019
sequence: 223
material: graphite
summary: Deterministic generated record 223 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 223.
