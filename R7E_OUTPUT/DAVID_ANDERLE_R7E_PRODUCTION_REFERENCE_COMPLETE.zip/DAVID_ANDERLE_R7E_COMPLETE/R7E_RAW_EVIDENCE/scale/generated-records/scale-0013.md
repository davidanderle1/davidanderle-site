---
title: Scale record 0013
slug: scale-0013
year: 2019
sequence: 13
material: graphite
summary: Deterministic generated record 13 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 13.
