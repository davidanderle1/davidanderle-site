---
title: Scale record 0018
slug: scale-0018
year: 2024
sequence: 18
material: paper
summary: Deterministic generated record 18 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 18.
