---
title: Scale record 0100
slug: scale-0100
year: 2026
sequence: 100
material: graphite
summary: Deterministic generated record 100 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 100.
