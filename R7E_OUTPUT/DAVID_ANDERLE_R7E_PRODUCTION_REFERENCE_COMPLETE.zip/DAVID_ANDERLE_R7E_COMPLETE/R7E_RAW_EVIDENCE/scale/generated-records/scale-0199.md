---
title: Scale record 0199
slug: scale-0199
year: 2025
sequence: 199
material: graphite
summary: Deterministic generated record 199 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 199.
