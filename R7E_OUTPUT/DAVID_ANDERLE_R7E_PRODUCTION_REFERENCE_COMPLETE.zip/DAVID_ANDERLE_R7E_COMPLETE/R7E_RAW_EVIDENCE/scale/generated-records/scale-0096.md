---
title: Scale record 0096
slug: scale-0096
year: 2022
sequence: 96
material: paper
summary: Deterministic generated record 96 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 96.
