---
title: Scale record 0325
slug: scale-0325
year: 2021
sequence: 325
material: graphite
summary: Deterministic generated record 325 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 325.
