---
title: Scale record 0207
slug: scale-0207
year: 2023
sequence: 207
material: paper
summary: Deterministic generated record 207 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 207.
