---
title: Scale record 0412
slug: scale-0412
year: 2018
sequence: 412
material: graphite
summary: Deterministic generated record 412 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 412.
