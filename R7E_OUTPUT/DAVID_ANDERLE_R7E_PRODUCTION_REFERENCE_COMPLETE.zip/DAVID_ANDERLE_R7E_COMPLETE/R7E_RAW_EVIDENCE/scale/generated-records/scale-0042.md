---
title: Scale record 0042
slug: scale-0042
year: 2018
sequence: 42
material: paper
summary: Deterministic generated record 42 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 42.
