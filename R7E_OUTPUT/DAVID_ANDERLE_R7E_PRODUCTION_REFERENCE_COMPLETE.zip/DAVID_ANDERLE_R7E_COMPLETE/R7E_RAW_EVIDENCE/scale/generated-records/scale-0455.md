---
title: Scale record 0455
slug: scale-0455
year: 2021
sequence: 455
material: oxide
summary: Deterministic generated record 455 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 455.
