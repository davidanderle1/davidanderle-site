---
title: Scale record 0336
slug: scale-0336
year: 2022
sequence: 336
material: paper
summary: Deterministic generated record 336 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 336.
