---
title: Scale record 0016
slug: scale-0016
year: 2022
sequence: 16
material: graphite
summary: Deterministic generated record 16 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 16.
