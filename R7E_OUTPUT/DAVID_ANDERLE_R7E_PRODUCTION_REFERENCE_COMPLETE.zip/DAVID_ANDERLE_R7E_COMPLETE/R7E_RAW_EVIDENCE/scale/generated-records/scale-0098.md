---
title: Scale record 0098
slug: scale-0098
year: 2024
sequence: 98
material: oxide
summary: Deterministic generated record 98 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 98.
