---
title: Scale record 0444
slug: scale-0444
year: 2020
sequence: 444
material: paper
summary: Deterministic generated record 444 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 444.
