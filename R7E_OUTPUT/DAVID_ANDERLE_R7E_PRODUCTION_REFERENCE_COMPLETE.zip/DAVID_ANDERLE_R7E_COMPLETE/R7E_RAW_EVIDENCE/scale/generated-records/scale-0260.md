---
title: Scale record 0260
slug: scale-0260
year: 2026
sequence: 260
material: oxide
summary: Deterministic generated record 260 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 260.
