---
title: Scale record 0408
slug: scale-0408
year: 2024
sequence: 408
material: paper
summary: Deterministic generated record 408 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 408.
