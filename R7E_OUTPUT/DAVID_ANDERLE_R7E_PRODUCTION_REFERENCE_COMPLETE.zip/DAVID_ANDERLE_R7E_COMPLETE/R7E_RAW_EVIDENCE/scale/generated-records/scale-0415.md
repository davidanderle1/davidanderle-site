---
title: Scale record 0415
slug: scale-0415
year: 2021
sequence: 415
material: graphite
summary: Deterministic generated record 415 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 415.
