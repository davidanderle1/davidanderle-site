---
title: Scale record 0183
slug: scale-0183
year: 2019
sequence: 183
material: paper
summary: Deterministic generated record 183 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 183.
