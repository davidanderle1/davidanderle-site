---
title: Scale record 0202
slug: scale-0202
year: 2018
sequence: 202
material: graphite
summary: Deterministic generated record 202 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 202.
