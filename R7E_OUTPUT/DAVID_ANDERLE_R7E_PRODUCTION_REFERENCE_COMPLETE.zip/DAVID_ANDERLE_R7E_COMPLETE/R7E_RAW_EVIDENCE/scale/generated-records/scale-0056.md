---
title: Scale record 0056
slug: scale-0056
year: 2022
sequence: 56
material: oxide
summary: Deterministic generated record 56 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 56.
