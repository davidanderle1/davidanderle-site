---
title: Scale record 0151
slug: scale-0151
year: 2017
sequence: 151
material: graphite
summary: Deterministic generated record 151 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 151.
