---
title: Scale record 0190
slug: scale-0190
year: 2026
sequence: 190
material: graphite
summary: Deterministic generated record 190 used only to measure validated static build scale.
---

This fixture is deterministic, non-canonical and excluded from the public sitemap. It exists to force a native Astro detail-page build at record 190.
