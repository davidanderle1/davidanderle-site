# Volatility Cascade Engine

## One-line summary
I built a simulation of how financial systems amplify shocks through leverage, margin pressure, and forced selling.

## Problem
Most people talk about market stress as if losses scale smoothly with the size of the initial shock. In reality, systems with leverage often behave differently. Once enough portfolios breach margin thresholds, forced selling can create a second wave of losses that is much larger than the first.

## Approach
I modeled a small network of leveraged funds with overlapping exposures to a shared set of assets. Each fund has a balance sheet, a leverage profile, and a margin threshold. When prices fall, the model checks which funds breach their constraints and forces them to reduce positions. Those sales create additional price impact, which can trigger further breaches elsewhere.

## Result
The system usually looks stable under small shocks. But after a threshold, total loss rises nonlinearly and the number of distressed funds jumps sharply. The point is not to predict exact market outcomes. The point is to show how fragility can stay hidden until the system crosses a boundary.

## What this proves
- I can turn a vague idea into a working model
- I think in terms of feedback loops, thresholds, and propagation
- I care about systems that fail under pressure, not just systems that look stable in normal conditions

## Suggested website bullets
- Built a network simulation of leveraged portfolios under market stress
- Modeled margin breaches, forced liquidations, and price impact
- Produced shock-to-loss and shock-to-distress curves showing nonlinear system behavior

## Suggested hero line for this project
A model of how losses become cascades.