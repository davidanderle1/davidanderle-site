# Volatility Cascade Engine

A flagship project for David Anderle.

## What it is
This project simulates how a shock in one asset can propagate through a leveraged financial system through:
- mark-to-market losses
- margin breaches
- forced liquidations
- impact-driven secondary declines

The core claim is simple:

> Financial systems often do not fail gradually.  
> They fail when thresholds are crossed.

## Why this project matters
This is designed to signal:
- systems thinking
- market structure intuition
- nonlinear risk analysis
- ability to turn an abstract idea into a working model

## Project structure
- `volatility_cascade_engine.py` — main simulation + chart generation
- `README.md` — overview and usage
- `website_case_study.md` — polished text for your website
- `outputs/` — generated charts

## Model overview
Each fund has:
- equity
- leverage
- asset exposures
- margin threshold
- liquidation sensitivity

Each asset has:
- price
- temporary market impact parameter

### Simulation loop
1. Apply an initial shock to one asset.
2. Revalue every fund.
3. Check for margin breaches.
4. Force liquidations for breached funds.
5. Apply liquidation-driven price impact.
6. Repeat until the system stabilizes.

## Example outputs
The script generates:
1. `system_loss_curve.png`  
   Initial shock on X-axis, final system loss on Y-axis

2. `cascade_count_curve.png`  
   Initial shock on X-axis, number of distressed funds on Y-axis

3. `network_snapshot.png`  
   Fund-asset network with distressed funds highlighted

## Run
```bash
python volatility_cascade_engine.py
```

## What to say on your site
Use this framing:

**Volatility Cascade Engine**  
I built a simulation of how leveraged portfolios can amplify shocks through margin pressure and forced selling. The model shows that system loss is often nonlinear: beyond a threshold, liquidations start to feed on themselves.

## Notes
This is intentionally simplified. It is not a production risk engine.  
Its value is that it demonstrates a clear systems idea with visible outputs.